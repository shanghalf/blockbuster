﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using DiaQ;

namespace DiaQEditor
{
	[plyNodeEd("DiaQ", "Quest Reward", typeof(DiaQNode_QReward))]
	public class DiaQNodeEd_QReward : plyNodeEditorBase
	{
		private string cachedName = "-select-";
		private GUIStyle outStyle;

		public DiaQNodeEd_QReward()
		{
			toolbarButton = new GUIContent(FA.star.ToString(), "Quest Reward");
		}

		public override string NodeWindowLabel(plyNode node)
		{
			return "Quest Reward";
		}

		public override bool RenderNodeWindow(plyNode node)
		{
			EditorGUILayout.Space();
			return false;
		}

		public override GUIContent OutLinkLabel(plyNode node, int idx)
		{
			DiaQNode_QReward Target = node as DiaQNode_QReward;
			GUIContent c = new GUIContent(plyGraphGUI.GC_DefaultNodeLinkIcon);
			if (Target.questId >= 0)
			{
				DiaQuest q = DiaQEdGlobal.QuestsAsset.GetQuestById(Target.questId);
				if (q != null)
				{
					if (q.name.Length < 20) c.text = q.name;
					else c.text = q.name.Substring(0, 20) + " ...";
				}
				else c.text = "Error: Quest Deleted";
			}
			else c.text = "No quest selected";
			return c;
		}

		public override GUIStyle OutLabelStyle(plyNode node, int idx)
		{
			if (outStyle == null) outStyle = new GUIStyle(plyGraphGUI.NodeOutLinkLabelStyle) { wordWrap = false };
			return outStyle;
		}

		// ============================================================================================================

		public override void OnSelected(plyNode node)
		{
			DiaQNode_QReward Target = node as DiaQNode_QReward;
			cachedName = "-select-";
			if (Target.questId >= 0)
			{
				DiaQuest q = DiaQEdGlobal.QuestsAsset.GetQuestById(Target.questId);
				if (q != null) cachedName = q.name;
				else cachedName = null;
			}
		}

		public override bool RenderNodeInspector(plyNode node, BasicCallback repaintCallback, BasicCallback saveCallback)
		{
			DiaQNode_QReward Target = node as DiaQNode_QReward;
			bool dirty = false;

			if (cachedName == null)
			{	// special case where name was set to null cause questId was invalid
				// and dirty needs to be set so that the reset quest id is saved
				cachedName = "-select-";
				Target.questId = -1;
				dirty = true;
			}

			if (plyEdGUI.LabelButton("Quest", cachedName, 100, 0))
			{
				DiaQuest q = DiaQEdGlobal.QuestsAsset.GetQuestById(Target.questId);
				plyListSelectWiz.ShowWiz("Select Quest", DiaQEdGlobal.QuestsAsset.quests.ConvertAll<object>((x) => { return (object)x; }), true, q, Callback, new object[] { Target, repaintCallback, saveCallback});
			}

			return dirty;
		}

		private void Callback(object sender, object[] args)
		{
			DiaQNode_QReward Target = (DiaQNode_QReward)args[0];
			BasicCallback repaintCallback = (BasicCallback)args[1];
			BasicCallback saveCallback = (BasicCallback)args[2];

			plyListSelectWiz wiz = sender as plyListSelectWiz;
			DiaQuest q = wiz.selected as DiaQuest;

			if (q == null)
			{
				Target.questId = -1;
				cachedName = "-select-";
			}
			else
			{
				Target.questId = q.id;
				cachedName = q.name;
			}

			saveCallback();
			wiz.Close();
			repaintCallback();
			graphEd.Repaint();
		}

		// ============================================================================================================
	}
}
