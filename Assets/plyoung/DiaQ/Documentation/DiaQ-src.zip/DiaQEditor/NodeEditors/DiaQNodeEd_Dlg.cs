﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using DiaQ;

namespace DiaQEditor
{
	[plyNodeEd("DiaQ", "Dialogue", typeof(DiaQNode_Dlg))]
	public class DiaQNodeEd_Dlg : plyNodeEditorBase
	{
		private int selectedIdx = -1;
		private string cachedName = "-select-";

		public DiaQNodeEd_Dlg()
		{
			toolbarButton = new GUIContent(FA.comments_o.ToString(), "Dialogue");
		}

		public override string NodeWindowLabel(plyNode node)
		{
			return "Dialogue";
		}

		public override bool RenderNodeWindow(plyNode node)
		{
			DiaQNode_Dlg Target = node as DiaQNode_Dlg;
			GUI.enabled = false;
			if (Target.dialogueText.Length > 50) GUILayout.TextArea(Target.dialogueText.Substring(0, 50) + " ...");
			else GUILayout.TextArea(Target.dialogueText);
			GUI.enabled = true;
			EditorGUILayout.Space();
			return false;
		}

		public override GUIContent OutLinkLabel(plyNode node, int idx)
		{
			DiaQNode_Dlg Target = node as DiaQNode_Dlg;
			GUIContent c = new GUIContent(plyGraphGUI.GC_DefaultNodeLinkIcon);
			if (Target.responses[idx].Length > 20) c.text = Target.responses[idx].Substring(0, 20) + " ...";
			else c.text = Target.responses[idx];
			return c;
		}

		// ============================================================================================================

		public override void OnSelected(plyNode node)
		{
			DiaQNode_Dlg Target = node as DiaQNode_Dlg;
			selectedIdx = -1;
			cachedName = "-select-";
			if (Target.linkedQuestId >= 0)
			{
				DiaQuest q = DiaQEdGlobal.QuestsAsset.GetQuestById(Target.linkedQuestId);
				if (q != null) cachedName = q.name;
				else cachedName = null;
			}
		}

		public override bool RenderNodeInspector(plyNode node, BasicCallback repaintCallback, BasicCallback saveCallback)
		{
			DiaQNode_Dlg Target = node as DiaQNode_Dlg;
			bool dirty = false;

			if (cachedName == null)
			{	// special case where name was set to null cause questId was invalid
				// and dirty needs to be set so that the reset quest id is saved
				cachedName = "-select-";
				Target.linkedQuestId = -1;
				dirty = true;
			}

			EditorGUI.BeginChangeCheck();
			{
				EditorGUILayout.PrefixLabel("Dialogue Text");
				Target.dialogueText = EditorGUILayout.TextArea(Target.dialogueText, plyEdGUI.TextAreaStyle);
			}
			if (EditorGUI.EndChangeCheck()) dirty = true;

			EditorGUILayout.Space();
			int res = plyEdGUI.SimpleItemArray(ref selectedIdx, Target.responses, "Responses", Callback, new object[] { Target });
			if (res == 2)
			{
				dirty = true;
				AddOutLink(Target);
				ArrayUtility.Add<string>(ref Target.responses, "");
			}
			else if (res >= 10)
			{
				dirty = true;
				RemoveOutLink(Target, (res - 10));
				ArrayUtility.RemoveAt<string>(ref Target.responses, (res - 10));
			}
			if (res > 0) repaintCallback();

			EditorGUILayout.Space();
			if (plyEdGUI.LabelButton("Linked Quest", cachedName, 100, 0))
			{
				DiaQuest q = DiaQEdGlobal.QuestsAsset.GetQuestById(Target.linkedQuestId);
				plyListSelectWiz.ShowWiz("Select Quest", DiaQEdGlobal.QuestsAsset.quests.ConvertAll<object>((x) => { return (object)x; }), true, q, QuestLinkCallback, new object[] { Target, repaintCallback, saveCallback });
			}

			return dirty;
		}

		private void Callback(object sender, object[] args)
		{
			int idx = (int)args[0];
			DiaQNode_Dlg Target = (DiaQNode_Dlg)args[1];
			EditorGUIUtility.labelWidth = 20;
			EditorGUI.BeginChangeCheck();
			Target.responses[idx] = EditorGUILayout.TextField((idx + 1).ToString(), Target.responses[idx]);
			if (EditorGUI.EndChangeCheck()) graphEd.SaveGraph();
			EditorGUIUtility.labelWidth = 0;
		}

		private void QuestLinkCallback(object sender, object[] args)
		{
			DiaQNode_Dlg Target = (DiaQNode_Dlg)args[0];
			BasicCallback repaintCallback = (BasicCallback)args[1];
			BasicCallback saveCallback = (BasicCallback)args[2];

			plyListSelectWiz wiz = sender as plyListSelectWiz;
			DiaQuest q = wiz.selected as DiaQuest;

			if (q == null)
			{
				Target.linkedQuestId = -1;
				cachedName = "-select-";
			}
			else
			{
				Target.linkedQuestId = q.id;
				cachedName = q.name;
			}

			saveCallback();
			wiz.Close();
			repaintCallback();
		}

		// ============================================================================================================
	}
}
