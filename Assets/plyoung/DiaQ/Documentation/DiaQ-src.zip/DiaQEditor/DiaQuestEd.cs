﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using DiaQ;

namespace DiaQEditor
{

	public class DiaQuestEd : EditorWindow
	{
		// ============================================================================================================
		#region vars

		[System.NonSerialized] private DiaQuest curr = null;

		private static GUIContent[] extraIcons = null;
		private BasicCallback[] extraCallbacks = new BasicCallback[] { DiaQEdGlobal.ShowDiaGraphWindow, DiaQEdGlobal.ShowDiaSettingsWindow };
		private Vector2[] scroll = { Vector2.zero, Vector2.zero };

		private DiaQuestCondition currC;
		private DiaQuestReward currR;

		private int metaIdx = -1;
		private int cMetaIdx = -1;
		private int rMetaIdx = -1;

		#endregion
		// ============================================================================================================
		#region init

		public static void ShowDiaQuestEditorWindow()
		{
			DiaQuestEd win = EditorWindow.GetWindow<DiaQuestEd>("DiaQuests");
		}

		#endregion
		// ============================================================================================================
		#region system

		protected void OnDestroy()
		{
		}

		protected void OnFocus()
		{
			if (EditorApplication.isPlayingOrWillChangePlaymode)
			{
				curr = null;
				ShowNotification(new GUIContent("Can't edit DiaQ in play mode"));
				return;
			}

			metaIdx = -1;
			cMetaIdx = -1;
			rMetaIdx = -1;
			currC = null;
			currR = null;
		}

		protected void OnLostFocus()
		{
			if (EditorApplication.isPlayingOrWillChangePlaymode)
			{
				curr = null;
				ShowNotification(new GUIContent("Can't edit DiaQ in play mode"));
				return;
			}

			metaIdx = -1;
		}

		protected void Update()
		{
		}

		private void SetSkin()
		{
			plyEdGUI.UseSkin();
			if (extraIcons == null)
			{
				extraIcons = new GUIContent[2];
				extraIcons[0] = new GUIContent(FA.comments_o.ToString(), "DiaGraphs Editor");
				extraIcons[1] = new GUIContent(FA.gear.ToString(), "DiaQ Settings");
			}
		}

		protected void OnGUI()
		{
			if (EditorApplication.isPlayingOrWillChangePlaymode)
			{
				curr = null;
				ShowNotification(new GUIContent("Can't edit DiaQ in play mode"));
				return;
			}

			SetSkin();

			EditorGUILayout.BeginHorizontal();
			{
				RenderMenu();

				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
				EditorGUILayout.BeginVertical();
				RenderEditor();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
			}
		}

		#endregion
		// ============================================================================================================
		#region menu

		private void RenderMenu()
		{
			EditorGUILayout.BeginVertical(GUILayout.Width(220));
			{
				if (plyEdGUI.ItemsList<DiaQuest>(ref curr, DiaQEdGlobal.QuestsAsset.quests, false, true, true, false, MenuCallback, ref scroll[0], DiaQEdGlobal.HLP_URL, "Add a Quest", true, extraIcons, extraCallbacks, GUILayout.Width(220)))
				{
					metaIdx = -1;
					cMetaIdx = -1;
					rMetaIdx = -1;
					currC = null;
					currR = null;
					plyEdGUI.ClearFocus();
				}
			}
			EditorGUILayout.EndVertical();
		}

		private object MenuCallback(object sender, object[] args)
		{
			// 1:add, 2:copied, 3:deleted, 4:called after delete, 5:position changed, 6:rename
			int act = (int)args[0];
			if (act == 1)
			{
				curr = new DiaQuest();
				curr.name = "Quest " + DiaQEdGlobal.QuestsAsset.quests.Count;
				curr.id = DiaQEdGlobal.QuestsAsset.__next_quest_id;
				DiaQEdGlobal.QuestsAsset.__next_quest_id++;
				DiaQEdGlobal.QuestsAsset.quests.Add(curr);
				EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
				return curr;
			}
			else if (act == 3)
			{
				return null;
			}
			else if (act == 6)
			{
				plyTextInputWiz.ShowWiz("Rename Quest", "Enter a unique name", curr.name, OnRenameQuest, new object[] { this, curr });
				return null;
			}

			EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
			return null;
		}

		private void OnRenameQuest(object sender, object[] args)
		{
			EditorWindow ed = args[0] as EditorWindow;
			DiaQuest quest = args[1] as DiaQuest;
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(s) && quest != null)
			{
				quest.name = s;
				EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
			}

			if (ed != null) ed.Repaint();
		}

		#endregion
		// ============================================================================================================
		#region editor

		private void RenderEditor()
		{
			if (curr == null)
			{
				GUILayout.FlexibleSpace();
				return;
			}

			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Quest: " + curr.name);

			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				EditorGUILayout.LabelField("Id", curr.id.ToString());
				curr.customIdent = EditorGUILayout.TextField("Custom Ident", curr.customIdent);

				EditorGUILayout.Space();
				plyEdGUI.SectionHeading("Quest Text", false);
				curr.text = EditorGUILayout.TextArea(curr.text, plyEdGUI.TextAreaStyle);

				EditorGUILayout.Space();
				plyEdGUI.SectionHeading("Quest MetaData", false);
				plyEdGUI.MetaDataEditor(ref metaIdx, ref curr.metaData, this.Repaint, MetaDataSaveCallback, null);
			}
			EditorGUILayout.EndVertical();

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				plyEdGUI.SectionHeading("Conditions", false);
				EditorGUILayout.Space();
				if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.FlatIconButtonStyle))
				{
					GUI.changed = false;
					curr.conditions.Add(new DiaQuestCondition());
					EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.HLine(5);
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				if (curr.conditions.Count == 0)
				{
					GUILayout.Label("No conditions defined.");
				}
				else
				{
					int del = -1;
					for (int i = 0; i < curr.conditions.Count; i++)
					{
						if (DrawQuestCondition((i + 1), curr.conditions[i])) del = i;
					}
					if (del >= 0)
					{
						GUI.changed = false;
						curr.conditions.RemoveAt(del);
						EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
					}
				}
			}
			EditorGUILayout.EndVertical();

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				plyEdGUI.SectionHeading("Rewards", false);
				EditorGUILayout.Space();
				if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.FlatIconButtonStyle))
				{
					GUI.changed = false;
					curr.rewards.Add(new DiaQuestReward());
					EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.HLine(5);
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				if (curr.rewards.Count == 0)
				{
					GUILayout.Label("No rewards defined.");
				}
				else
				{
					int del = -1;
					for (int i = 0; i < curr.rewards.Count; i++)
					{
						if (DrawQuestReward((i + 1), curr.rewards[i])) del = i;
					}
					if (del >= 0)
					{
						GUI.changed = false;
						curr.rewards.RemoveAt(del);
						EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
					}
				}
				EditorGUILayout.Space();
			}
			EditorGUILayout.EndVertical();
			plyEdGUI.HLine(20);
		}

		private void MetaDataSaveCallback(object sender, object[] args)
		{
			EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
		}

		private void SimpleSaveCallback()
		{
			EditorUtility.SetDirty(DiaQEdGlobal.QuestsAsset);
		}

		private bool DrawQuestCondition(int cnum, DiaQuestCondition con)
		{
			bool ret = false;
			EditorGUILayout.BeginVertical(GUI.skin.box);
			{
				EditorGUILayout.BeginHorizontal();
				{
					if (GUILayout.Button(plyEdGUI.GC_Remove, plyEdGUI.FlatIconButtonStyle)) ret = true;
					EditorGUILayout.Space();
					GUILayout.Label("Condition " + cnum);
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				{
					EditorGUIUtility.labelWidth = 50;
					con.key = EditorGUILayout.TextField("Key", con.key);
					EditorGUIUtility.labelWidth = 100;
					con.targetValue = EditorGUILayout.IntField("Target Value", con.targetValue);
				}
				EditorGUILayout.EndHorizontal();

				EditorGUIUtility.labelWidth = 50;
				con.text = EditorGUILayout.TextField("Text", con.text);
				EditorGUIUtility.labelWidth = 0;

				int sel = (con == currC ? cMetaIdx : -1);
				if (plyEdGUI.MetaDataEditor(ref sel, ref con.metaData, this.Repaint, MetaDataSaveCallback, null))
				{
					currC = con;
					cMetaIdx = sel;
				}
			}
			EditorGUILayout.EndVertical();
			return ret;
		}

		private bool DrawQuestReward(int rnum, DiaQuestReward reward)
		{
			bool ret = false;
			EditorGUILayout.BeginVertical(GUI.skin.box);
			{
				EditorGUILayout.BeginHorizontal();
				{
					if (GUILayout.Button(plyEdGUI.GC_Remove, plyEdGUI.FlatIconButtonStyle)) ret = true;
					EditorGUILayout.Space();
					GUILayout.Label("Reward " + rnum);
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				{
					EditorGUIUtility.labelWidth = 50;
					if (plyDataObjectEditor.DrawField("Key", ref reward.keyObject, "DiaQReward", this.Repaint, SimpleSaveCallback, plyEdGUI.ButtonLeftStyle))
					{
						GUI.changed = true;
					}

					if (GUILayout.Button("X", plyEdGUI.ButtonRightStyle, GUILayout.Width(25)))
					{
						reward.keyObject.dataProviderName = "";
						GUI.changed = true;
					}
					EditorGUIUtility.labelWidth = 30;
					reward.keyString = EditorGUILayout.TextField(" or", reward.keyString, GUILayout.Width(170));
				}
				EditorGUILayout.EndHorizontal();

				EditorGUIUtility.labelWidth = 50;
				reward.value = EditorGUILayout.IntField("Value", reward.value);
				EditorGUIUtility.labelWidth = 0;

				int sel = (reward == currR ? rMetaIdx : -1);
				if (plyEdGUI.MetaDataEditor(ref sel, ref reward.metaData, this.Repaint, MetaDataSaveCallback, null))
				{
					currR = reward;
					rMetaIdx = sel;
				}
			}
			EditorGUILayout.EndVertical();
			return ret;
		}

		#endregion
		// ============================================================================================================
	}
}
