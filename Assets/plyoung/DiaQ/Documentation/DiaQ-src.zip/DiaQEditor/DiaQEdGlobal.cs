﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using DiaQ;

namespace DiaQEditor
{
	[InitializeOnLoad]
	public class DiaQEdGlobal
	{
		public const string HLP_URL = "http://plyoung.com/docs/diaq.html";

		public static string MAIN_DATA_PATH { get { return plyEdUtil.DataPath + "/"; } }
		public static string DIAQ_DATA_PATH { get { return plyEdUtil.DataPath + "/DiaQ/"; } }

		private static GameObject _prefab = null;
		public static GameObject Prefab
		{
			get
			{
				if (_prefab == null) LoadOrCreatePrefab();
				return _prefab;
			}
		}

		private static plyGraphManager _graphAsset = null;
		public static plyGraphManager GraphsAsset
		{
			get
			{
				if (_graphAsset == null) _graphAsset = Prefab.GetComponent<plyGraphManager>();
				return _graphAsset;
			}
		}

		private static DiaQuestManager _questAsset = null;
		public static DiaQuestManager QuestsAsset
		{
			get
			{
				if (_questAsset == null) _questAsset = Prefab.GetComponent<DiaQuestManager>();
				return _questAsset;
			}
		}

		private static DiaQEngine _engineAsset = null;
		public static DiaQEngine EngineAsset
		{
			get
			{
				if (_engineAsset == null) _engineAsset = Prefab.GetComponent<DiaQEngine>();
				return _engineAsset;
			}
		}

		// ============================================================================================================

		static DiaQEdGlobal()
		{
			LanguageEditor.RegisterStringsProvider(StringsProvider);
		}

		private static object StringsProvider(object sender, object[] args)
		{
			List<LanguageString> strings = new List<LanguageString>();

			foreach (plyGraph g in GraphsAsset.graphs)
			{
				foreach (plyNode n in g.nodes)
				{
					List<LanguageString> s = n.GetStrings(LanguageEditor.LanguagesAsset);
					if (s != null) strings.AddRange(s);
				}
				g.Serialize();
			}

			foreach (DiaQuest q in QuestsAsset.quests)
			{
				List<LanguageString> s = q.GetStrings(LanguageEditor.LanguagesAsset);
				if (s != null) strings.AddRange(s);
			}

			// save assets since string IDs might have been generated
			EditorUtility.SetDirty(GraphsAsset);
			EditorUtility.SetDirty(QuestsAsset);

			return strings;
		}

		// ============================================================================================================

		[MenuItem("Tools/PL Young/DiaQ/Graph Editor", priority = 40)]
		[MenuItem("Window/DiaQ/Graph Editor", priority = 3)]
		public static void ShowDiaGraphWindow()
		{
			DiaQEd.ShowDiaQEditorWindow();
		}

		[MenuItem("Tools/PL Young/DiaQ/Quest Editor", priority = 41)]
		[MenuItem("Window/DiaQ/Quest Editor", priority = 4)]
		public static void ShowDiaQuestWindow()
		{
			DiaQuestEd.ShowDiaQuestEditorWindow();
		}

		[MenuItem("Tools/PL Young/DiaQ/Settings", priority = 42)]
		[MenuItem("Window/DiaQ/Settings", priority = 5)]
		public static void ShowDiaSettingsWindow()
		{
			DiaQSettingsEd.Show_DiaQSettingsEd();
		}

		[MenuItem("Tools/PL Young/DiaQ/Help", priority = 43)]
		public static void Show_Help()
		{
			Application.OpenURL(DiaQEdGlobal.HLP_URL);
		}

		[MenuItem("Tools/PL Young/DiaQ/About", priority = 44)]
		public static void Show_About()
		{
			Texture2D logo = plyEdGUI.LoadTextureResource("DiaQEditor.edRes.logo.png", typeof(DiaQEd).Assembly);
			plyAbout.Show_plyAbout("DiaQ", "content/11182", logo, (plyEdUtil.PackagesPathStart() + "/DiaQ/Documentation/version.txt"));
		}

		// ============================================================================================================

		public static void CheckDataPaths()
		{
			plyEdUtil.CheckDataPath("Assets/", MAIN_DATA_PATH);
			plyEdUtil.CheckDataPath(MAIN_DATA_PATH, DIAQ_DATA_PATH);
		}

		public static void LoadOrCreatePrefab()
		{
			CheckDataPaths();
			_prefab = plyEdUtil.LoadOrCreatePrefab<plyGraphManager>("DiaQ", DiaQEdGlobal.DIAQ_DATA_PATH + "DiaQ.prefab");
			_graphAsset = _prefab.GetComponent<plyGraphManager>();

			if (null == _prefab.GetComponent<DiaQEngine>())
			{
				_prefab.AddComponent<DiaQEngine>();
				EditorUtility.SetDirty(_prefab);
			}

			if (null == _prefab.GetComponent<DiaQuestManager>())
			{
				_prefab.AddComponent<DiaQuestManager>();
				EditorUtility.SetDirty(_prefab);
			}

		}

		public static bool GraphAssetValid()
		{
			return _graphAsset != null;
		}

		// ============================================================================================================
	}
}
