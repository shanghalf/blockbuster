﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	/// <summary>
	/// A dialogue/ conversation node. Shows text and wait for an option to be chosen.
	/// Use plyGraphManager.SendDataToNode(a_number_strating_at_0) to send a response
	/// to this node when it is waiting. So, the first response is (0), the seconds 
	/// response is (1), the 3rd (2), etc.
	/// </summary>
	public class DiaQNode_Dlg: plyNode
	{
		// ============================================================================================================
		#region properties

		/// <summary> The raw dialogue text to show </summary>
		public string dialogueText = "";
		public int dialogueText_StringId = 0;

		/// <summary> The quest that is linked to this dialogue. Useful when info of
		/// a quest will be shown to the player and then wait for him to accept 
		/// or reject the quest. </summary>
		public int linkedQuestId = -1;

		/// <summary> The possible responses/ choices. These are tied
		/// to the outLinks. </summary>
		public string[] responses = { "" };
		public int[] responses_StringId = { 0 };

		#endregion
		// ============================================================================================================
		#region vars

		private int responseChosen = -1;
		private DiaQuest _cachedQuest = null;

		#endregion
		// ============================================================================================================
		#region pub

		public override string PrettyName()
		{
			return "Dialogue";
		}

		public override void OnAddedToGraph()
		{
			base.OnAddedToGraph();
			__rect.width = 200;
		}

		public override void CopyTo(plyNode n)
		{
			base.CopyTo(n);
			DiaQNode_Dlg o = n as DiaQNode_Dlg;

			o.dialogueText = this.dialogueText;
			o.dialogueText_StringId = 0;
			o.responses = new string[this.responses.Length];
			o.responses_StringId = new int[this.responses.Length];
			for (int i = 0; i < this.responses.Length; i++)
			{
				o.responses[i] = this.responses[i];
				o.responses_StringId[i] = 0;
			}
		}

		public override int Enter()
		{
			// stop graph now if there are no choices
			if (outLinks.Length < 1) return (int)ReturnCode.Stop;

			// walking of graph stops and this node continues getting update calls till it is ready to continue
			responseChosen = -1;
			return (int)ReturnCode.WaitingForData;
		}

		public override int Update()
		{
			// wait till a response chosen
			if (responseChosen >= 0) return responseChosen;
			return (int)ReturnCode.WaitingForData;
		}

		public override void ReceiveData(object data)
		{
			int i = -1;
			if (plyReflectionUtil.TryGetInt(data, out i))
			{
				if (i >= 0 && i < outLinks.Length)
				{
					responseChosen = i;
				}
			}
		}

		public override List<LanguageString> GetStrings(LanguagesAsset languagesAsset)
		{
			List<LanguageString> strings = new List<LanguageString>();

			if (!string.IsNullOrEmpty(dialogueText))
			{
				dialogueText_StringId = languagesAsset.GetStringId(dialogueText_StringId);
				strings.Add(new LanguageString() { id = dialogueText_StringId, str = dialogueText });
			}

			// make sure there are enough entries in the response string IDs array
			if (responses_StringId.Length < responses.Length)
			{
				System.Array.Resize<int>(ref responses_StringId, responses.Length);
			}

			for (int i = 0; i < responses.Length; i++)
			{
				if (!string.IsNullOrEmpty(responses[i]))
				{
					responses_StringId[i] = languagesAsset.GetStringId(responses_StringId[i]);
					strings.Add(new LanguageString() { id = responses_StringId[i], str = responses[i] });
				}
			}

			return strings;
		}

		public override void UpdateStrings()
		{
			dialogueText = Languages.Instance.GetString(dialogueText_StringId);

			for (int i = 0; i < responses.Length; i++)
			{
				responses[i] = Languages.Instance.GetString(responses_StringId[i]);
			}
		}

		/// <summary> Returns the quest linked to this dialogue node. 
		/// Null if no quest is linked or the quest could not be found. </summary>
		public DiaQuest LinkedQuest()
		{
			if (_cachedQuest == null) _cachedQuest = DiaQEngine.Instance.questManager.GetQuestById(linkedQuestId);
			return _cachedQuest;
		}

		/// <summary>
		/// Return parsed text. The inline values will be inserted if any present in text.
		/// </summary>
		public string ParsedDialogueText(bool inludeLinkedQuestText)
		{
			string s = dialogueText;
			if (inludeLinkedQuestText && linkedQuestId >= 0)
			{
				if (_cachedQuest == null) _cachedQuest = DiaQEngine.Instance.questManager.GetQuestById(linkedQuestId);
				if (_cachedQuest != null) s += _cachedQuest.text;
			}
			return plyInlineValue.ParseText(s, DiaQEngine.Instance.inlineValues);
		}

		/// <summary>
		/// Return parsed response text. The inline values will be inserted if any present in text.
		/// </summary>
		public string ParsedResponseText(int idx)
		{
			return plyInlineValue.ParseText(responses[idx], DiaQEngine.Instance.inlineValues);
		}

		#endregion
		// ============================================================================================================	
	}
}
