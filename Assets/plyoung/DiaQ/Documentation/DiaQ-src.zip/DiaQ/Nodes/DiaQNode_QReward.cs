﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using plyCommon;

namespace DiaQ
{
	/// <summary>
	/// Give quest rewards by running the reward givers.
	/// Not of use when reward keyStrings are used.
	/// </summary>
	public class DiaQNode_QReward : plyNode
	{
		// ============================================================================================================
		#region properties

		/// <summary> The quest that rewards comes from </summary>
		public int questId = -1;

		#endregion
		// ============================================================================================================
		#region pub

		public override string PrettyName()
		{
			return "Quest Reward";
		}

		public override void OnAddedToGraph()
		{
			base.OnAddedToGraph();
			__rect.width = 130;
		}

		public override void CopyTo(plyNode n)
		{
			base.CopyTo(n);
			DiaQNode_QReward o = n as DiaQNode_QReward;

			o.questId = this.questId;
		}

		public override int Enter()
		{
			DiaQuest q = DiaQEngine.Instance.questManager.GetQuestById(questId);
			if (q == null)
			{
				LogError("The Quest could not be found. It might have been removed.");
				return (int)ReturnCode.Stop;
			}

			q.RunRewardGivers();
			return 0;
		}

		#endregion
		// ============================================================================================================	
	}
}
