﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using plyCommon;

namespace DiaQ
{
	/// <summary>
	/// Accept a quest
	/// </summary>
	public class DiaQNode_QAccept : plyNode
	{
		// ============================================================================================================
		#region properties

		/// <summary> The quest to accept </summary>
		public int questId = -1;

		#endregion
		// ============================================================================================================
		#region pub

		public override string PrettyName()
		{
			return "Accept Quest";
		}

		public override void OnAddedToGraph()
		{
			base.OnAddedToGraph();
			__rect.width = 130;
		}

		public override void CopyTo(plyNode n)
		{
			base.CopyTo(n);
			DiaQNode_QAccept o = n as DiaQNode_QAccept;

			o.questId = this.questId;
		}

		public override int Enter()
		{
			DiaQuest q = DiaQEngine.Instance.questManager.GetQuestById(questId);
			if (q == null)
			{
				LogError("The Quest could not be found. It might have been removed.");
				return (int)ReturnCode.Stop;
			}

			q.accepted = true;
			return 0; // go to next node
		}

		#endregion
		// ============================================================================================================	
	}
}
