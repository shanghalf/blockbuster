﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	/// <summary> DiaQ runtime provide the interface with the graph manager </summary>
	[AddComponentMenu("")]
	public class DiaQEngine: MonoBehaviour, plyDataProviderInterface
	{
		/// <summary> Values that can be in-lined in text used in Graphs and Quests </summary>
		[HideInInspector] public List<plyInlineValue> inlineValues = new List<plyInlineValue>();

		// ============================================================================================================	

		public static DiaQEngine Instance { get; set; }
		public plyGraphManager graphManager { get; set; }
		public DiaQuestManager questManager { get; set; }

		/// <summary> Called whenever a quest is accepted. </summary>
		public static System.Action<DiaQuest> onQuestAccepted { get; set; }

		/// <summary> Called whenever a quest is completed. </summary>
		public static System.Action<DiaQuest> onQuestCompleted { get; set; }

		/// <summary> Called whenever a quest is rewarded. </summary>
		public static System.Action<DiaQuest> onQuestRewarded { get; set; }

		// ============================================================================================================	
		#region system

		protected void Awake()
		{
			Instance = this;
			gameObject.name = "DiaQ";
			graphManager = gameObject.GetComponent<plyGraphManager>();
			questManager = gameObject.GetComponent<DiaQuestManager>();
		}

		protected void Start()
		{
			UpdateFromLanguageStrings();
			Languages.Instance.RegisterLanguageChangeListener(UpdateFromLanguageStrings);
		}

		private void UpdateFromLanguageStrings()
		{
			if (Languages.Instance.HasLanguagesDefined)
			{
				for (int i = 0; i < graphManager.graphs.Count; i++)
				{
					for (int j = 0; j < graphManager.graphs[i].nodes.Count; j++)
					{
						graphManager.graphs[i].nodes[j].UpdateStrings();
					}
				}

				for (int i = 0; i < questManager.quests.Count; i++)
				{
					questManager.quests[i].UpdateStrings();
				}
			}
		}

		#endregion
		// ============================================================================================================	
		#region Loading and Saving

		/// <summary> Returns a string that can be saved and later be fed to RestoreFromSaveData() to restore
		/// the state of DiaQ's graphs and quests to what it was when GetSaveData() was called. The status
		/// of quests and the Meta Data of DiaQ, Graphs, Quests, Conditions and Rewards will be saved.
		/// Note that GameObject and UnityObect types in meta data can't be saved and restored.
		/// Do not call this in Awake()
		/// </summary>
		public string GetSaveData()
		{
			string data = "";

			// Encode Status of Quests
			for (int i = 0; i < questManager.quests.Count; i++)
			{
				data += questManager.quests[i].id.ToString() + (char)31;
				if (questManager.quests[i].rewarded) data += "1";
				else if (questManager.quests[i].completed) data += "2";
				else if (questManager.quests[i].accepted)
				{
					data += "3";
					for (int j = 0; j < questManager.quests[i].conditions.Count; j++)
					{
						data += (char)31 + questManager.quests[i].conditions[j].performedTimes.ToString();
					}
				}
				else data += "0";
				data += (char)30;
			}
			data += (char)28;

			// Encode the metaData
			// - DiaQ's Global metaData
			string collectedData = "";
			foreach (plyMetaData md in graphManager.runtimeMetaData.Values)
			{
				string d = plyMetaData.Encode(md);
				if (d != null) collectedData += d + (char)30;
			}

			if (collectedData.Length > 0)
			{	// the D as first character will identify this as DiaQ global meta data
				data += "D#" + collectedData + (char)29;
			}

			// - metaData from Graphs
			for (int i = 0; i < graphManager.graphs.Count; i++)
			{
				collectedData = "";
				foreach (plyMetaData md in graphManager.graphs[i].runtimeMetaData.Values)
				{
					string d = plyMetaData.Encode(md);
					if (d != null) collectedData += d + (char)30;
				}

				if (collectedData.Length > 0)
				{	// only add an entry and separator if there are encoded metaData
					// The G as 1st character identifies this as Graph data to follow
					data += "G" + graphManager.graphs[i].id.ToString() + "#" + collectedData + (char)29;
				}
			}

			// - metaData from Quests
			for (int i = 0; i < questManager.quests.Count; i++)
			{
				string questData = "";

				// check the quest conditions
				for (int j = 0; j < questManager.quests[i].conditions.Count; j++)
				{
					collectedData = "";
					foreach (plyMetaData md in questManager.quests[i].conditions[j].runtimeMetaData.Values)
					{
						string d = plyMetaData.Encode(md);
						if (d != null) collectedData += d + (char)30;
					}

					if (collectedData.Length > 0)
					{	// only add an entry and separator if there are encoded metaData
						// The C as 1st character identifies this as Condition data to follow
						questData += "C" + j.ToString() + "#" + collectedData + (char)29;
					}
				}

				// check the quest rewards
				for (int j = 0; j < questManager.quests[i].rewards.Count; j++)
				{
					collectedData = "";
					foreach (plyMetaData md in questManager.quests[i].rewards[j].runtimeMetaData.Values)
					{
						string d = plyMetaData.Encode(md);
						if (d != null) collectedData += d + (char)30;
					}

					if (collectedData.Length > 0)
					{	// only add an entry and separator if there are encoded metaData
						// The R as 1st character identifies this as Rewards data to follow
						questData += "R" + j.ToString() + "#" + collectedData + (char)29;
					}
				}

				// collect the quest's own metaData
				collectedData = "";
				foreach (plyMetaData md in questManager.quests[i].runtimeMetaData.Values)
				{
					string d = plyMetaData.Encode(md);
					if (d != null) collectedData += d + (char)30;
				}

				if (collectedData.Length > 0 || questData.Length > 0)
				{	// only add an entry and separator if there are encoded metaData
					// The Q as 1st character identifies this as Quest data to follow
					data += "Q" + questManager.quests[i].id.ToString() + "#" + collectedData + (char)29 + questData;
				}
			}

			return data;
		}

		/// <summary> Restore the state of DiaQ from the data. This data must be a string
		/// that was previously provided by GetSaveData(). Do not call this in Awake() 
		/// Note, restoring a quest to the state of of "rewarded" will not actually 
		/// cause anything that gives the reward, to run. That you need to handle somewhere
		/// else. Besides, you probably save the player's state too and then running the reward
		/// logic again would give him double the rewards each time he restores the game. </summary>
		public void RestoreFromSaveData(string data_s)
		{
			if (string.IsNullOrEmpty(data_s)) 
			{
				//Debug.LogError("Data string is invalid (null)");
				return;
			}

			string[] data = data_s.Split((char)28);
			if (data.Length != 2)
			{
				Debug.LogError("Data string is invalid");
				return;
			}

			// Decode Quests' status data
			string[] quests_s = data[0].Split((char)30);
			for (int i = 0; i < quests_s.Length; i++)
			{
				if (string.IsNullOrEmpty(quests_s[i])) continue;
				string[] qs = quests_s[i].Split((char)31);
				int qid = int.Parse(qs[0]);
				DiaQuest q = questManager.GetQuestById(qid);
				if (q != null)
				{
					q.accepted = false; // first reset it
					if (qs[1] == "1") q.rewarded = true;
					else if (qs[1] == "2") q.completed = true;
					else if (qs[1] == "3")
					{
						q.accepted = true;
						for (int j = 0; j < q.conditions.Count; j++)
						{
							if (j + 2 >= qs.Length)
							{
								Debug.LogError("The Quest has more conditions that there is data saved for it. You might have modified the quest after creating save data. Do not use the old data to restore it as it is now invalid data.");
								return;
							}
							q.conditions[j].performedTimes = int.Parse(qs[j + 2]);
						}
					}
				}
				else
				{
					Debug.LogError("The Quest could not be found. You might be trying to restore data saved before you removed a quest in the editor. Do not use the old data to restore it as it is now invalid data.");
					return;
				}
			}

			// Decode metaData

			string[] md_strings = data[1].Split((char)29);
			DiaQuest quest = null;

			for (int i = 0; i < md_strings.Length; i++)
			{
				if (string.IsNullOrEmpty(md_strings[i])) continue;

				string ident = md_strings[i].Substring(0, md_strings[i].IndexOf("#") + 1);
				md_strings[i] = md_strings[i].Replace(ident, "");	// get rid of ident part
				ident = ident.Substring(0, ident.Length - 1);		// get rid of # at end of ident

				if (ident.StartsWith("D"))
				{	// Decode DiaQ Global metaData
					string[] metaDatas = md_strings[i].Split((char)30);
					for (int j = 0; j < metaDatas.Length; j++)
					{
						plyMetaData md = plyMetaData.Decode(metaDatas[j]);
						if (md != null) graphManager.SetMetaDataValue(md.name, md.GetValue());
					}
				}

				else if (ident.StartsWith("Q"))
				{	// Decode Quest metaData
					ident = ident.Substring(1); // get rid of "Q" at start
					quest = questManager.GetQuestById(int.Parse(ident));
					if (quest == null) { Debug.LogError("Quest not found. You might have deleted it after creating this save data. Do not use old save data after having modified the Graphs and Quests."); return; }
					string[] metaDatas = md_strings[i].Split((char)30);
					for (int j = 0; j < metaDatas.Length; j++)
					{
						plyMetaData md = plyMetaData.Decode(metaDatas[j]);
						if (md != null) quest.SetMetaDataValue(md.name, md.GetValue());
					}
				}

				else if (ident.StartsWith("C"))
				{	// Decode Quest Condition metaData
					if (quest == null) { Debug.LogError("Quest expected to be set"); return; }
					ident = ident.Substring(1); // get rid of "C" at start
					int idx = int.Parse(ident);
					if (idx < 0 || idx >= quest.conditions.Count) { Debug.LogError("Quest Condition not found. You might have deleted it after creating this save data. Do not use old save data after having modified the Graphs and Quests."); return; }
					string[] metaDatas = md_strings[i].Split((char)30);
					for (int j = 0; j < metaDatas.Length; j++)
					{
						plyMetaData md = plyMetaData.Decode(metaDatas[j]);
						if (md != null) quest.conditions[idx].SetMetaDataValue(md.name, md.GetValue());
					}
				}

				else if (ident.StartsWith("R"))
				{	// Decode Quest Reward metaData
					if (quest == null) { Debug.LogError("Quest expected to be set"); return; }
					ident = ident.Substring(1); // get rid of "R" at start
					int idx = int.Parse(ident);
					if (idx < 0 || idx >= quest.rewards.Count) { Debug.LogError("Quest Reward not found. You might have deleted it after creating this save data. Do not use old save data after having modified the Graphs and Quests."); return; }
					string[] metaDatas = md_strings[i].Split((char)30);
					for (int j = 0; j < metaDatas.Length; j++)
					{
						plyMetaData md = plyMetaData.Decode(metaDatas[j]);
						if (md != null) quest.rewards[idx].SetMetaDataValue(md.name, md.GetValue());
					}
				}

			}
		}

		#endregion
		// ============================================================================================================	
		#region plyDataProviderInterface

		public object DataProvider_GetValue(string[] nfo)
		{
			// nfo[0]: kind of metaData (0=DiaQ, 1:Graph, 2:Node, 3: Quest)
			// nfo[1]: Graph id or Quest id
			// nfo[2]: Node id
			// nfo[3]: metaData name
			// nfo[4]: a pretty name helper for 'Graph.Node' path
			// nfo[5]: what kind of data (0:metaData, 1:Graph Object, 2:Quest Object)

			if (nfo[5] == "0")
			{
				if (nfo[0] == "0")
				{
					return graphManager.GetMetaDataValue(nfo[3]);
				}
				else if (nfo[0] == "1" || nfo[0] == "2")
				{
					plyGraph graph = graphManager.GetGraph(new UniqueID(nfo[1]));
					if (graph != null)
					{
						if (nfo[0] == "1")
						{
							return graph.GetMetaDataValue(nfo[3]);
						}
						else if (nfo[0] == "2")
						{
							int id = -1;
							if (int.TryParse(nfo[2], out id))
							{
								plyNode node = graph.GetNodeById(id);
								if (node != null) return node.GetMetaDataValue(nfo[3]);
							}
						}
					}
				}
				else if (nfo[0] == "3")
				{
					int id = -1;
					if (int.TryParse(nfo[1], out id))
					{
						DiaQuest quest = questManager.GetQuestById(id);
						if (quest != null) return quest.GetMetaDataValue(nfo[3]);
					}
				}
			}
			else if (nfo[5] == "1")
			{
				return graphManager.GetGraph(new UniqueID(nfo[1]));
			}
			else if (nfo[5] == "2")
			{
				int id = -1;
				if (int.TryParse(nfo[1], out id))
				{
					return questManager.GetQuestById(id);
				}
			}

			return null;
		}

		public void DataProvider_SetValue(string[] nfo, object value)
		{
			// nfo[0]: kind of metaData (0=DiaQ, 1:Graph, 2:Node, 3:Quest)
			// nfo[1]: Graph id or Quest id
			// nfo[2]: Node id
			// nfo[3]: metaData name
			// nfo[4]: a pretty name helper for 'Graph.Node' path
			// nfo[5]: what kind of data (0:metaData, 1:Graph Object, 2:Quest Object)
			// note: only setting metadata is supported, not graph or quest objects

			if (nfo[5] == "0")
			{
				if (nfo[0] == "0")
				{
					graphManager.SetMetaDataValue(nfo[3], value);
				}
				else if (nfo[0] == "1" || nfo[0] == "2")
				{
					plyGraph graph = graphManager.GetGraph(new UniqueID(nfo[1]));
					if (graph != null)
					{
						if (nfo[0] == "1")
						{
							graph.SetMetaDataValue(nfo[3], value);
						}
						else if (nfo[0] == "2")
						{
							int id = -1;
							if (int.TryParse(nfo[2], out id))
							{
								plyNode node = graph.GetNodeById(id);
								if (node != null) node.SetMetaDataValue(nfo[3], value);
							}
						}
					}
				}
				else if (nfo[0] == "3")
				{
					int id = -1;
					if (int.TryParse(nfo[1], out id))
					{
						DiaQuest quest = questManager.GetQuestById(id);
						if (quest != null) quest.SetMetaDataValue(nfo[3], value);
					}
				}
			}
		}

		public void DataProvider_Callback(string[] nfo)
		{
		}

		#endregion
		// ============================================================================================================	
	}
}
