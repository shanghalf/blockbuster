﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	/// <summary> A DiaQ Quest </summary>
	[System.Serializable]
	public class DiaQuest: plyMetaDataInterface
	{
		// ============================================================================================================
		#region properties

		/// <summary> Unique id of the quest </summary>
		public int id = -1;

		/// <summary> Name of quest </summary>
		public string name = "";
		public int name_StringId = 0;

		/// <summary> Optional way to identify quest by </summary>
		public string customIdent = "";

		/// <summary> Text associated with quest, for example a description of what the player must do. </summary>
		public string text = "";
		public int text_StringId = 0;

		/// <summary> List of conditions that must be completed before the quest is considered completed.
		/// Do not update the conditions directly, except if you know what you are doing. In most cases you
		/// want to use the provided functions to update the conditions. </summary>
		public List<DiaQuestCondition> conditions = new List<DiaQuestCondition>();

		/// <summary> List of rewards for completing the quest. </summary>
		public List<DiaQuestReward> rewards = new List<DiaQuestReward>();

		/// <summary> Extra data that can be associated with the quest. Do not access at runtime, use provided functions. </summary>
		public plyMetaData[] metaData = new plyMetaData[0];

		#endregion
		// ============================================================================================================
		#region runtime

		/// <summary> Has this quest been accepted yet? setting this false will set completed = false and
		/// rewarded = false </summary>
		public bool accepted 
		{ 
			get { return _accepted; }
			set
			{
				_accepted = value;
				if (_accepted == false)
				{
					SetCompleted(false);
					_rewarded = false;
				}

				if (_accepted && DiaQEngine.onQuestAccepted != null)
				{
					DiaQEngine.onQuestAccepted(this);
				}
			}
		}
		private bool _accepted = false;

		/// <summary> Has this quest been completed? setting this true will set accepted = true and will 
		/// set all condition progress as completed. setting this false will set rewarded = false and 
		/// will reset conditions's progress. </summary>
		public bool completed 
		{
			get { return _completed; }
			set
			{
				SetCompleted(value);
				if (_completed == false) _rewarded = false;
			}
		}
		public bool _completed = false;

		/// <summary> Has the player receive the quest rewards yet or not? setting this true will set 
		/// accepted = true and completed = true. Setting rewarded = true will not cause any game
		/// logic that gives the reward, to run. You handle that separately. </summary>
		public bool rewarded
		{
			get { return _rewarded; }
			set
			{
				_rewarded = value;
				if (_rewarded)
				{
					_accepted = true;
					SetCompleted(true);
				}

				if (_rewarded && DiaQEngine.onQuestRewarded != null)
				{
					DiaQEngine.onQuestRewarded(this);
				}
			}
		}
		public bool _rewarded = false;

		public Dictionary<string, plyMetaData> runtimeMetaData { get; private set; }

		#endregion
		// ============================================================================================================
		#region system

		public override string ToString()
		{
			return name;
		}

		/// <summary> called by DiaQuestManager's Awake at runtime </summary>
		public void Awake()
		{
			runtimeMetaData = new Dictionary<string, plyMetaData>(0);
			for (int i = 0; i < metaData.Length; i++)
			{
				if (metaData == null) continue;
				runtimeMetaData.Add(metaData[i].name, metaData[i]);
			}
			if (false == Application.isEditor) metaData = null;

			for (int i = 0; i < conditions.Count; i++)
			{
				conditions[i].Awake();
			}

			for (int i = 0; i < rewards.Count; i++)
			{
				rewards[i].Awake();
			}
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> This will update the condition and note that it has been performed. The condition will be
		/// considered completed once it has been performed the target number of times DiaQuestCondition.targetValue.
		/// Will update DiaQuest.completed when quest is completed. Return false if condition key not found,
		/// quest not yet accepted by player or if player already completed the quest. </summary>
		public bool ConditionPerformed(string key, bool ignoreIfNotFound)
		{
			if (!accepted)
			{
				Debug.LogWarning(string.Format("Quest [{0}] has not yet been accepted", name));
				return false;
			}

			if (completed)
			{
				Debug.LogWarning(string.Format("Quest [{0}] has already been completed", name));
				return false;
			}

			bool allDone = true;
			bool found = false;

			for (int i = 0; i < conditions.Count; i++)
			{
				if (conditions[i].key.Equals(key))
				{
					conditions[i].performedTimes++;
					found = true;
				}
				if (!conditions[i].completed) allDone = false;
			}

			if (allDone) completed = true;

			if (!found && !ignoreIfNotFound)
			{
				Debug.LogError(string.Format("Condition Key [{0}] not found in Quest [{1}]", key, name));
				return false;
			}

			return true;
		}

		/// <summary> This will update the condition performedTimes. The condition will be considered completed 
		/// once it has been performed the target number of times DiaQuestCondition.targetValue.
		/// The value can be negative to decrease the performedTimes. </summary>
		public bool ConditionPerformed(string key, int val, bool ignoreIfNotFound)
		{
			if (!accepted)
			{
				Debug.LogWarning(string.Format("Quest [{0}] has not yet been accepted", name));
				return false;
			}

			if (completed)
			{
				Debug.LogWarning(string.Format("Quest [{0}] has already been completed", name));
				return false;
			}

			bool allDone = true;
			bool found = false;

			for (int i = 0; i < conditions.Count; i++)
			{
				if (conditions[i].key.Equals(key))
				{
					conditions[i].performedTimes+=val;
					found = true;
				}
				if (!conditions[i].completed) allDone = false;
			}

			if (allDone) completed = true;

			if (!found && !ignoreIfNotFound)
			{
				Debug.LogError(string.Format("Condition Key [{0}] not found in Quest [{1}]", key, name));
				return false;
			}

			return true;
		}

		/// <summary> Passing true will also update the condition progress as completed while false
		/// will reset all conditions' progress to 0 </summary>
		public void SetCompleted(bool completed)
		{
			bool wasCompleted = _completed;

			_completed = completed;
			for (int i = 0; i < conditions.Count; i++)
			{
				conditions[i].performedTimes = completed ? conditions[i].targetValue : 0;
			}

			if (!wasCompleted && _completed && DiaQEngine.onQuestCompleted != null)
			{
				DiaQEngine.onQuestCompleted(this);
			}
		}

		/// <summary> This will run through the rewards and execute any that makes use of
		/// DiaQuestReward.keyObject. If the execute fails then it is assumed that you want
		/// to make use of DiaQuestReward.keyString and will have to run through all rewards 
		/// and check which of them are set (false == string.IsNullOrEmpty()) and then 
		/// react according to your game's design. </summary>
		public void RunRewardGivers()
		{
			if (!rewarded) rewarded = true; // so that callbacks are triggered if not was rewarded

			for (int i = 0; i < rewards.Count; i++)
			{
				rewards[i].keyObject.Callback(new string[] { rewards[i].value.ToString() });
			}
		}

		/// <summary>
		/// Return parsed text. The inline values will be inserted if any present in text.
		/// </summary>
		public string ParsedQuestText()
		{
			return plyInlineValue.ParseText(text, DiaQEngine.Instance.inlineValues);
		}

		/// <summary>
		/// This will set the quest as accepted but no progress in conditions and no rewards given
		/// </summary>
		public void ResetQuestToAccepted()
		{
			accepted = true;
			rewarded = false;
			SetCompleted(false);
		}

		/// <summary>
		/// This will set the quest as not accepted, no rewards given, no progress in conditions
		/// </summary>
		public void ResetQuest()
		{
			SetCompleted(false);
			rewarded = false;
			accepted = false;
		}

		public List<LanguageString> GetStrings(LanguagesAsset languagesAsset)
		{
			List<LanguageString> strings = new List<LanguageString>();

			if (!string.IsNullOrEmpty(name))
			{
				name_StringId = languagesAsset.GetStringId(name_StringId);
				strings.Add(new LanguageString() { id = name_StringId, str = name });
			}

			if (!string.IsNullOrEmpty(text))
			{
				text_StringId = languagesAsset.GetStringId(text_StringId);
				strings.Add(new LanguageString() { id = text_StringId, str = text });
			}

			for (int i = 0; i < conditions.Count; i++)
			{
				if (!string.IsNullOrEmpty(conditions[i].text))
				{
					conditions[i].text_StringId = languagesAsset.GetStringId(conditions[i].text_StringId);
					strings.Add(new LanguageString() { id = conditions[i].text_StringId, str = conditions[i].text });
				}
			}

			return strings;
		}

		public void UpdateStrings()
		{
			name = Languages.Instance.GetString(name_StringId);
			text = Languages.Instance.GetString(text_StringId);

			for (int i = 0; i < conditions.Count; i++)
			{
				conditions[i].text = Languages.Instance.GetString(conditions[i].text_StringId);
			}
		}

		#endregion
		// ============================================================================================================
		#region runtime meta data interaction

		public Dictionary<string, plyMetaData> AllMetaData()
		{
			return runtimeMetaData;
		}

		public List<plyMetaData> AllMetaDataList()
		{
			List<plyMetaData> r = new List<plyMetaData>();
			foreach (plyMetaData md in runtimeMetaData.Values) r.Add(md);
			return r;
		}

		/// <summary> Return reference to meta data object. Null if not found. </summary>
		public plyMetaData GetMetaData(string name)
		{
			if (runtimeMetaData.ContainsKey(name)) return runtimeMetaData[name];
			return null;
		}

		/// <summary> Return meta data value. Null if named meta data not found. </summary>
		public object GetMetaDataValue(string name)
		{
			plyMetaData md = GetMetaData(name);
			if (md == null) return null;
			return md.GetValue();
		}

		/// <summary> Set meta data value. Will create the named meta data if not found and then set value. </summary>
		public void SetMetaDataValue(string name, object val)
		{
			plyMetaData md = GetMetaData(name);
			if (md == null)
			{
				md = new plyMetaData();
				md.name = name;
				runtimeMetaData.Add(name, md);
			}
			md.SetValue(val);
		}

		#endregion
		// ============================================================================================================	
	}
}
