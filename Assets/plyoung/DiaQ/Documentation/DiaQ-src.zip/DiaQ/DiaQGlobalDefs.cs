﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	public enum DiaQIdentType
	{
		Name, CutomIdent
	}

	// ================================================================================================================
}
