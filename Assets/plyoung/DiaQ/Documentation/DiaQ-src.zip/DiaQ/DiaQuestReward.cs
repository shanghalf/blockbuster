﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	/// <summary> A DiaQ Quest Reward for quest completion. 
	/// You should  use the functions in DiaQuest and not 
	/// interact with the reward directly, except when 
	/// you want to interact with the metaData. </summary>
	[System.Serializable]
	public class DiaQuestReward: plyMetaDataInterface
	{
		/// <summary> alternative way of providing a reward key. If set then this will cause
		/// the DataProvider_Callback to be triggered. Also provides a cleaner way for the 
		/// designer to select quest reward. The context of the Provider should be set to
		/// "DiaQReward". (plyDataProviderInfo.ProviderContext) </summary>
		public plyDataObject keyObject = new plyDataObject();

		/// <summary> identifies the reward </summary>
		public string keyString = "";

		/// <summary> can be used to set how many copies of the reward to give </summary>
		public int value = 1;
	
		/// <summary> Extra data that can be associated with the reward. Do not access at runtime, use provided functions. </summary>
		public plyMetaData[] metaData = new plyMetaData[0];

		// ============================================================================================================

		public Dictionary<string, plyMetaData> runtimeMetaData { get; private set; }

		// ============================================================================================================

		/// <summary> called by Quest's Awake at runtime </summary>
		public void Awake()
		{
			runtimeMetaData = new Dictionary<string, plyMetaData>(0);
			for (int i = 0; i < metaData.Length; i++)
			{
				if (metaData == null) continue;
				runtimeMetaData.Add(metaData[i].name, metaData[i]);
			}
			if (false == Application.isEditor) metaData = null;
		}

		public Dictionary<string, plyMetaData> AllMetaData()
		{
			return runtimeMetaData;
		}

		public List<plyMetaData> AllMetaDataList()
		{
			List<plyMetaData> r = new List<plyMetaData>();
			foreach(plyMetaData md in runtimeMetaData.Values) r.Add(md);
			return r;
		}

		/// <summary> Return reference to meta data object. Null if not found. </summary>
		public plyMetaData GetMetaData(string name)
		{
			if (runtimeMetaData.ContainsKey(name)) return runtimeMetaData[name];
			return null;
		}

		/// <summary> Return meta data value. Null if named meta data not found. </summary>
		public object GetMetaDataValue(string name)
		{
			plyMetaData md = GetMetaData(name);
			if (md == null) return null;
			return md.GetValue();
		}

		/// <summary> Set meta data value. Will create the named meta data if not found and then set value. </summary>
		public void SetMetaDataValue(string name, object val)
		{
			plyMetaData md = GetMetaData(name);
			if (md == null)
			{
				md = new plyMetaData();
				md.name = name;
				runtimeMetaData.Add(name, md);
			}
			md.SetValue(val);
		}

		// ============================================================================================================
	}
}
