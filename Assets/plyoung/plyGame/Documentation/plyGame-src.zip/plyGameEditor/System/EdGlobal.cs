﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.IO;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyBloxKitEditor;

namespace plyGameEditor
{
	/// <summary> The plyGame Editor Global. </summary>
	[InitializeOnLoad]
	public class EdGlobal
	{
		#region defines and vars

		public const string HLP_URL				= "http://www.plyoung.com/docs/";
		public const string HLP_Main			= HLP_URL + "index.html";
		public const string HLP_SplashScreenEd	= HLP_URL + "screens.html";
		public const string HLP_LangScreenEd	= HLP_URL + "screens.html";
		public const string HLP_LoadScreenEd	= HLP_URL + "screens.html";
		public const string HLP_CustomScreenEd	= HLP_URL + "screens.html";
		public const string HLP_MainEd			= HLP_URL + "main-editor.html";
		public const string HLP_InputManager	= HLP_URL + "input-settings.html";
		public const string HLP_LoadSaveEd		= HLP_URL + "loadsave.html";
		public const string HLP_ProjectEd		= HLP_URL + "project-settings.html";
		public const string HLP_SystemEd		= HLP_URL + "system-settings.html";
		public const string HLP_SoundSettings	= HLP_URL + "sound-settings.html";
		public const string HLP_AutoObjects		= HLP_URL + "auto-instantiate.html";

		/// <summary> Path to the plyGame package root. Default is 'Assets/plyoung/plyGame/'</summary>
		public static string PACKAGE_PATH { get { if (_packagePath == null) _packagePath = plyEdUtil.PackagesRelativePathStart() + "plyGame/"; return _packagePath; }}

		public static EdDataAsset edData;				//!< The serialised plyGame editor data and settings
		public static LayerMask floorLayer = 0;			//!< What is considered the Floor layer
		public static LoadSaveEdInfo[] loadSaveEditors;	// LoadSave Provider editors
		public static MainEdInfo[] mainEditors;			// Main Editor window editors
		public static List<plyGamePluginInfo> plugins = new List<plyGamePluginInfo>(); // list of plyGame plugins
		
		// ============================================================================================================

		private static int playTestingMode = 0;		// 0:not inited, 1:inited, 2:game started by plyGame
		private static string _packagePath = null;
		private static DataAsset _dataAsset = null;	// Do not use this directly. Use GetDataAsset()

		#endregion
		// ============================================================================================================
		#region Init/ Load

		static EdGlobal()
		{
			// find definitions and editors
			Assembly[] asms = System.AppDomain.CurrentDomain.GetAssemblies();
			Load_MainEditors(asms);
			Load_LoadSaveEditors(asms);

			// hook some callbacks
			EditorApplication.update += RunOnce;
			EditorApplication.update += OnUpdate;
			//EditorApplication.hierarchyWindowChanged += OnHierarchyChanged;

			plyEdUtil.RegisterDataPathChangeListener(OnDataPathChanged);

			RegisterUniqueIDChecker(PersistableObjectUniqueIdChecker);

			// Load data
			LoadEdPrefs();
			LoadData();
		}

		private static void RunOnce()
		{
			EditorApplication.update -= RunOnce;

			// init things here that should be loaded once the editor is up 
			// and would/ might cause errors if it executed in Constructor

			RegisterDefaultToolButtons();
		}

		private static void LoadEdPrefs()
		{
			floorLayer = (LayerMask)EditorPrefs.GetInt("plyGame.Ed.FloorLayer", -1);
		}

		private static void RegisterDefaultToolButtons()
		{
			EdToolbar.AddToolbarButtons(new System.Collections.Generic.List<EdToolbar.ToolbarButton>()
			{
				new EdToolbar.ToolbarButton() { order = 1, callback = RunGame, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.play" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Run Game") },
				new EdToolbar.ToolbarButton() { order = 2, callback = RefreshBuild, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.refresh" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Refresh and Update Settings") },
				new EdToolbar.ToolbarButton() { order = 100, callback = null, gui = null },
				new EdToolbar.ToolbarButton() { order = 101, callback = ShowSystemEditorWindow, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.settings" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Main Editor") },
				new EdToolbar.ToolbarButton() { order = 102, callback = ShowScreensEditorWindow, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.screens" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Screens Editor") },
				//new EdToolbar.ToolbarButton() { order = 130, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.systems" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Add System"), 
				//	popup = new List<EdToolbar.ToolbarButton>()
				//	{
				//		new EdToolbar.ToolbarButton() { order = 1, callback = Create_SpawnPoint, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_spawn" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Spawn Point") },
				//		new EdToolbar.ToolbarButton() { order = 2, callback = Create_GameTrigger, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_trigger" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Area Trigger") },
				//		new EdToolbar.ToolbarButton() { order = 3, callback = Create_WaypointPath, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_path" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Waypoint Path") },
				//		new EdToolbar.ToolbarButton() { order = 4, callback = Create_LocationMarker, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_marker" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Location Marker") },
				//	},
				//},
			});

			//EdToolbar.AddToolbarButtons(new System.Collections.Generic.List<EdToolbar.ToolbarButton>()
			//{
			//	new EdToolbar.ToolbarButton() { order = 1, callback = RunGame, gui = new GUIContent(null, null, "Run Game"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/play" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//	new EdToolbar.ToolbarButton() { order = 2, callback = RefreshBuild, gui = new GUIContent(null, null, "Update Build Settings"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/refresh" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//	new EdToolbar.ToolbarButton() { order = 100, callback = null, gui = null },
			//	new EdToolbar.ToolbarButton() { order = 101, callback = ShowSystemEditorWindow, gui = new GUIContent(null, null, "Main Editor"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/settings" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//	new EdToolbar.ToolbarButton() { order = 102, callback = ShowScreensEditorWindow, gui = new GUIContent(null, null, "Screens Editor"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/screens" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//	new EdToolbar.ToolbarButton() { order = 130, gui = new GUIContent(null, null, "Add System"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/systems" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", 
			//		popup = new List<EdToolbar.ToolbarButton>()
			//		{
			//			new EdToolbar.ToolbarButton() { order = 1, callback = Create_SpawnPoint, gui = new GUIContent(null, null, "Spawn Point"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/add_spawn" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//			new EdToolbar.ToolbarButton() { order = 2, callback = Create_GameTrigger, gui = new GUIContent(null, null, "Area Trigger"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/add_trigger" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//			new EdToolbar.ToolbarButton() { order = 3, callback = Create_WaypointPath, gui = new GUIContent(null, null, "Waypoint Path"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/add_path" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//			new EdToolbar.ToolbarButton() { order = 4, callback = Create_LocationMarker, gui = new GUIContent(null, null, "Location Marker"), iconPath = plyEdGUI.ResPath + "Toolbar/icons/add_marker" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png" },
			//		},
			//	},
			//});		
		}
		
		private static void Load_MainEditors(Assembly[] asms)
		{
			// find all the classes that inherit from ChildEditorBase
			List<System.Type> foundEdTypes = new List<System.Type>();
			for (int i = 0; i < asms.Length; i++)
			{
				System.Type[] types = asms[i].GetExportedTypes();
				for (int j = 0; j < types.Length; j++)
				{
					if (types[j].IsClass && typeof(ChildEditorBase).IsAssignableFrom(types[j]) && types[j].Name != "ChildEditorBase")
					{
						foundEdTypes.Add(types[j]);
					}
				}
			}

			// extract some def.meta data and create the editor instances
			List<MainEdInfo> eds = new List<MainEdInfo>();
			for (int i = 0; i < foundEdTypes.Count; i++)
			{
				ChildEditorAttribute att = null;
				System.Object[] attribs = foundEdTypes[i].GetCustomAttributes(typeof(ChildEditorAttribute), false);
				if (attribs.Length > 0)
				{
					att = attribs[0] as ChildEditorAttribute;
					if (att != null)
					{
						MainEdInfo nfo = new MainEdInfo();
						nfo.order = att.Order;
						nfo.name = att.Name;
						nfo.icon = att.Icon;
						nfo.editor = (ChildEditorBase)System.Activator.CreateInstance(foundEdTypes[i]);
						eds.Add(nfo);

						nfo.editor.OnCreated(asms);
					}
				}
			}

			// sort the editors according to priority/ name
			eds.Sort(delegate(MainEdInfo a, MainEdInfo b) { return a.order.CompareTo(b.order); });

			// update the caches
			mainEditors = eds.ToArray();
		}

		private static void Load_LoadSaveEditors(Assembly[] asms)
		{
			// find all the classes that inherit from LoadSaveProviderEdBase
			List<System.Type> foundEdTypes = new List<System.Type>();
			for (int i = 0; i < asms.Length; i++)
			{
				System.Type[] types = asms[i].GetExportedTypes();
				for (int j = 0; j < types.Length; j++)
				{
					if (types[j].IsClass && typeof(LoadSaveProviderEdBase).IsAssignableFrom(types[j]) && types[j].Name != "LoadSaveProviderEdBase")
					{
						foundEdTypes.Add(types[j]);
					}
				}
			}

			// extract some def.meta data and create the editor instances
			List<LoadSaveEdInfo> eds = new List<LoadSaveEdInfo>();
			for (int i = 0; i < foundEdTypes.Count; i++)
			{
				bool err = true;
				LoadSaveProviderAttribute att = null;
				System.Object[] attribs = foundEdTypes[i].GetCustomAttributes(typeof(LoadSaveProviderAttribute), false);
				if (attribs.Length > 0)
				{
					att = attribs[0] as LoadSaveProviderAttribute;
					if (att != null)
					{
						err = false;
						LoadSaveEdInfo nfo = new LoadSaveEdInfo();
						nfo.name = att.Name;
						nfo.providerType = att.ProviderType;
						nfo.editor = (LoadSaveProviderEdBase)System.Activator.CreateInstance(foundEdTypes[i]);
						eds.Add(nfo);
					}
				}

				if (err)
				{
					Debug.LogError("Invalid LoadSave Provider Editor [" + foundEdTypes[i].ToString() + "] encountered. Please check the documentation on how to create custom LoadSave Provider and Editor.");
				}
			}

			// sort the editors according to priority/ name
			eds.Sort(delegate(LoadSaveEdInfo a, LoadSaveEdInfo b) { return a.name.CompareTo(b.name); });

			// update the caches
			loadSaveEditors = eds.ToArray();
		}

		//private static void CheckPlugins()
		//{
		//	string fn = plyEdUtil.FullProjectPath + "Library/plygame.plugins";
		//	string data = "";
		//	try
		//	{
		//		if (File.Exists(fn))
		//		{
		//			using (StreamReader sr = new StreamReader(fn))
		//			{
		//				data = sr.ReadToEnd();
		//				sr.Close();
		//			}
		//		}
		//	}
		//	catch { }

		//	if (false == string.IsNullOrEmpty(data))
		//	{
		//		Dictionary<string, string> pluginStats = new Dictionary<string, string>();
		//		string[] vals = data.Split((char)31);
		//		for (int i = 0; i < vals.Length; i++)
		//		{
		//			string[] v = vals[i].Split((char)30);
		//			if (v.Length == 2)
		//			{
		//				if (false == pluginStats.ContainsKey(v[0]))
		//				{
		//					pluginStats.Add(v[0], v[1]);
		//				}
		//			}
		//		}

		//		bool showMessage = false;
		//		for (int i = 0; i < plugins.Count; i++)
		//		{
		//			if (pluginStats.ContainsKey(plugins[i].name))
		//			{
		//				if (plugins[i]._isActive == true && pluginStats[plugins[i].name] == "0")
		//				{	// plugin is supposed to be disabled (but is on)
		//					showMessage = true;
		//					EdGlobal.EnDisablePlugin(plugins[i], false, ref pluginStats);
		//					plugins[i]._isActive = false;
		//				}
		//				if (plugins[i]._isActive == false && pluginStats[plugins[i].name] == "1")
		//				{	// plugin is supposed to be enabled (but is off)
		//					showMessage = true;
		//					EdGlobal.EnDisablePlugin(plugins[i], true, ref pluginStats);
		//					plugins[i]._isActive = true;
		//				}
		//			}
		//		}

		//		if (showMessage)
		//		{
		//			EditorUtility.DisplayDialog("Restart Unity", "Please restart Unity. Updates where made to plugins, needing a restart for the changes to take affect.", "Ok");
		//		}
		//	}
		//}

		#endregion
		// ============================================================================================================
		#region System

		//private static void OnHierarchyChanged()
		//{
		//	//// Detect scene change so that old editor objects can be cleaned up
		//	//if (currentScene != EditorApplication.currentScene)
		//	//{
		//	//	currentScene = EditorApplication.currentScene;
		//	//	// todo: cleanup the old editor objects in scene, if any
		//	//}
		//}

		private static void OnUpdate()
		{
			if (playTestingMode != 1)
			{
				// When unity start (or play mode starts) then playTestingMode will be 0
				// because Unity 'recompiles' the scripts and init to defaults.
				// I use the EditorPrefs to carry the correct state of playTestingMode around
				// I need playTestingMode to see when play mode is ended and to then reload
				// the scene the dev was working on since I changed it to the plyGame boot
				// scene for the play test was started 

				if (playTestingMode == 0)
				{
					playTestingMode = EditorPrefs.GetInt("plyGame.CurrentPlayTestingMode", 1);
					if (!EditorApplication.isPlayingOrWillChangePlaymode && playTestingMode != 1)
					{
						playTestingMode = 1;
						EditorPrefs.SetInt("plyGame.CurrentPlayTestingMode", 1);
					}
				}
				else if (playTestingMode == 2)
				{
					if (!EditorApplication.isPlayingOrWillChangePlaymode)
					{
						playTestingMode = 1;
						EditorPrefs.SetInt("plyGame.CurrentPlayTestingMode", 1);
						string prevScene = EditorPrefs.GetString("plyGame.PlayTestingModeScene", "");
						if (!string.IsNullOrEmpty(prevScene)) EditorApplication.OpenScene(prevScene);
					}
				}
			}
		}

		#endregion
		// ============================================================================================================
		#region Menus

		[MenuItem("Tools/PL Young/plyGame/Run Game", priority = 20)]
		public static void RunGame()
		{
			if (EdGlobal.CheckDataExist())
			{
				RefreshAndRunGame();
			}
		}

		[MenuItem("Tools/PL Young/plyGame/Refresh and Update", priority = 21)]
		public static void RefreshBuild()
		{
			if (EdGlobal.CheckDataExist())
			{
				UpdateBuildSettings(true);
			}
		}

		//[MenuItem("Tools/PL Young/plyGame/Update Build Settings", priority = 22)]
		//public static void FullUpdateBuild()
		//{
		//	if (EdGlobal.CheckDataExist())
		//	{
		//		UpdateBuildSettings(true);
		//	}
		//}

		// ----------

		[MenuItem("Tools/PL Young/plyGame/Main Editor", priority = 30)]
		[MenuItem("Window/plyGame/Main Editor", priority = 1)]
		public static void ShowSystemEditorWindow()
		{
			MainEditorWindow.Show_SystemEditorWindow();
		}

		[MenuItem("Tools/PL Young/plyGame/Screens Editor", priority = 31)]
		[MenuItem("Window/plyGame/Screens Editor", priority = 2)]
		public static void ShowScreensEditorWindow()
		{
			ScreensEditor.Show_OnGUIScreensEditor();
		}

		// ----------

		[MenuItem("Tools/PL Young/plyGame/Show Toolbar", priority = 40)]
		public static void ShowToolbar()
		{
			EdToolbar.Show_EdToolbar();
		}

		[MenuItem("Tools/PL Young/plyGame/Help/About", priority = 41)]
		public static void ShowAboutWindow()
		{
			//Texture2D logo = plyEdGUI.LoadEditorTexture(plyEdGUI.ResPath + "plyGame/logo.png");
			Texture2D logo = plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.logo.png", typeof(EdGlobal).Assembly);
			plyAbout.Show_plyAbout("plyGame", "publisher/380", logo, (plyEdUtil.PackagesPathStart() + "/plyGame/Documentation/version.txt"));
		}

		[MenuItem("Tools/PL Young/plyGame/Help/Documentation", priority = 42)]
		public static void ShowDocumentation()
		{
			Application.OpenURL(EdGlobal.HLP_Main);
		}

		// ----------

		#endregion
		// ============================================================================================================
		#region Data folder and default data

		/// <summary> Will check if plyGame data folder and data files exist. If not, it will ask user if
		///  can create. If not allowed it will return false. </summary>
		public static bool CheckDataExist()
		{
			// Check if data path exist
			if (plyEdUtil.RelativeFileExist(plyEdUtil.DATA_PATH_SYSTEM + "plygame_ed.asset"))
			{
				if (LoadData())
				{
					// ...
				}
				else
				{
					Debug.LogError("Failed to load the plyGame data. You might have to delete the plyGame Data folder and try again. It might be best to first ask for help on the support forum.");
					EditorUtility.DisplayDialog("Data Corrupt", "Failed to load the plyGame data. You might have to delete the plyGame Data folder and try again.", "Ok");
					return false;
				}
				return true;
			}

			// Data path not found, need to create default data
			if (EditorUtility.DisplayDialog("Data Missing", "The plyGame Data was not found. Initialise plyGame now?", "Yes", "No"))
			{
				if (!EditorApplication.SaveCurrentSceneIfUserWantsTo()) return false;
				CreateData();
				return true;
			}

			return false;
		}

		private static bool LoadData()
		{
			if (edData == null)
			{
				edData = (EdDataAsset)AssetDatabase.LoadAssetAtPath(plyEdUtil.DATA_PATH_SYSTEM + "plygame_ed.asset", typeof(EdDataAsset));
			}
			return (edData != null);
		}

		private static void CreateData()
		{
			CheckLayersAndTags();

			// Create folders. Must be created in specific order
			// with parent folder coming before child folder(s)
			CheckDataPaths();

			// Copy the System Scenes to Data Folder
			if (false == plyEdUtil.RelativeFileExist(plyEdUtil.DATA_PATH_SYSTEM + "00-bootstrap.unity"))
			{
				AssetDatabase.CopyAsset(PACKAGE_PATH + "System/00-bootstrap.unity", plyEdUtil.DATA_PATH_SYSTEM + "00-bootstrap.unity");
			}

			if (false == plyEdUtil.RelativeFileExist(plyEdUtil.DATA_PATH_SYSTEM + "ongui.prefab"))
			{
				//AssetDatabase.CopyAsset(PACKAGE_PATH + "System/ongui.prefab", DATA_PATH_SYSTEM + "ongui.prefab");
				plyEdUtil.CreatePrefab<GUIManager>("ongui", plyEdUtil.DATA_PATH_SYSTEM + "ongui.prefab");
			}

			AssetDatabase.Refresh();

			// Create the Editor Asset
			ScriptableObject asset = ScriptableObject.CreateInstance(typeof(EdDataAsset));
			AssetDatabase.CreateAsset(asset, plyEdUtil.DATA_PATH_SYSTEM + "plygame_ed.asset");
			edData = (EdDataAsset)asset;

			edData.bootstrapScene = plyEdUtil.DATA_PATH_SYSTEM + "00-bootstrap.unity";
			EditorUtility.SetDirty(edData);

			// Get reference to prefabs
			GameObject uiManagerFab = (GameObject)AssetDatabase.LoadAssetAtPath(plyEdUtil.DATA_PATH_SYSTEM + "ongui.prefab", typeof(GameObject));

			// Create the Assets
			StringsAsset stringsAsset = (StringsAsset)LoadOrCreateAsset<StringsAsset>(plyEdUtil.DATA_PATH_RESOURCES + "strings.asset", null);
			SplashScreenAsset splashAsset = (SplashScreenAsset)LoadOrCreateAsset<SplashScreenAsset>(plyEdUtil.DATA_PATH_SYSTEM + "splash.asset", null);
			LangScreenAsset langScrAsset = (LangScreenAsset)LoadOrCreateAsset<LangScreenAsset>(plyEdUtil.DATA_PATH_SYSTEM + "langscr.asset", null);
			LoadScreensAsset loadScrAsset = (LoadScreensAsset)LoadOrCreateAsset<LoadScreensAsset>(plyEdUtil.DATA_PATH_SYSTEM + "loadscr.asset", null);
			CustomScreensAsset custScrAsset = (CustomScreensAsset)LoadOrCreateAsset<CustomScreensAsset>(plyEdUtil.DATA_PATH_SYSTEM + "custscr.asset", null);

			InputDefAsset inputAsset = (InputDefAsset)LoadOrCreateAsset<InputDefAsset>(plyEdUtil.DATA_PATH_SYSTEM + "input.asset", null);
			System_Ed.SetupInputManager();
			System_Ed.DefineDefaultInputBinds(inputAsset);
			System_Ed.CreateDefaultLoadSaveProvider(GetDataAsset());

			// Setup BOOTSTRAP scene
			bool err = true;
			if (EditorApplication.OpenScene(plyEdUtil.DATA_PATH_SYSTEM + "00-bootstrap.unity"))
			{
				GameObject go = GameObject.Find("plyGame");
				if (go)
				{
					GameGlobal b = go.GetComponent<GameGlobal>();
					if (b)
					{
						err = false;

						b.bloxGlobalFab = plyBloxEd.GetBloxGlobalPrefab();
						b.uiManagerFab = uiManagerFab;
						b.inputAsset = inputAsset;
						b.splashAsset = splashAsset;
						b.langScrAsset = langScrAsset;
						b.custScrAsset = custScrAsset;
						b.loadScrAsset = loadScrAsset;
						b.dataAsset = GetDataAsset();
						EditorApplication.SaveScene();
					}
				}
			}

			if (err)
			{
				Debug.LogError("An error occurred while trying to configure the Startup data. Your plyGame install might be corrupt.");
				EditorUtility.DisplayDialog("Error!", "An error occurred while trying to configure the Startup data. Your plyGame install might be corrupt.", "Close");
			}

			// Done
			AssetDatabase.SaveAssets();
			AssetDatabase.Refresh();
			EditorApplication.NewScene();
			UpdateBuildSettings(false);
		}

		private static void CheckLayersAndTags()
		{
			// Make a list of all the tags to be defined
			List<string> tagNames = new List<string>();
			System.Reflection.FieldInfo[] fields = typeof(plyGame.GameGlobal.Tag).GetFields();
			foreach (System.Reflection.FieldInfo f in fields)
			{
				string s = f.GetRawConstantValue().ToString();

				// these are skipped as unity define them by default
				if (s.Equals("Untagged")) continue;
				if (s.Equals("MainCamera")) continue;

				// add the tag name
				tagNames.Add(s);
			}

			// Make a list of all the layers to be defined <laye_name, layer_index>
			fields = typeof(plyGame.GameGlobal.LayerMapping).GetFields();
			Dictionary<string, int> layers = new Dictionary<string, int>();
			foreach (System.Reflection.FieldInfo f in fields) layers.Add(f.Name, (int)f.GetRawConstantValue());

			// Open tag manager
			SerializedObject tagManager = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
			SerializedProperty tagsProp = tagManager.FindProperty("tags");
#if UNITY5
			SerializedProperty layersProp = tagManager.FindProperty("layers");
#endif

			// *** Check the Tags
			foreach (string s in tagNames)
			{
				// check if the tag is defined
				bool found = false;
				for (int i = 0; i < tagsProp.arraySize; i++)
				{
					SerializedProperty t = tagsProp.GetArrayElementAtIndex(i);
					if (t.stringValue.Equals(s)) { found = true; break; }
				}

				// if not found, add it
				if (!found)
				{
					tagsProp.InsertArrayElementAtIndex(0);
					SerializedProperty n = tagsProp.GetArrayElementAtIndex(0);
					n.stringValue = s;
				}
			}

			// *** Check the Layers
			// first remove all names that are the same as ones I want to define
			for (int i = 8; i <= 31; i++)
			{
#if UNITY5
				SerializedProperty sp = layersProp.GetArrayElementAtIndex(i);
#else
				string nm = "User Layer " + i;			
				SerializedProperty sp = tagManager.FindProperty(nm);
#endif
				if (sp != null && layers.ContainsKey(sp.stringValue)) sp.stringValue = "";
			}

			// now add layer names used by plyGame
			foreach (KeyValuePair<string, int> kv in layers)
			{
#if UNITY5
				SerializedProperty sp = layersProp.GetArrayElementAtIndex(kv.Value);
#else
				string nm = "User Layer " + kv.Value;
				SerializedProperty sp = tagManager.FindProperty(nm);
#endif
				if (sp != null) sp.stringValue = kv.Key;
			}

			// *** save changes
			tagManager.ApplyModifiedProperties();
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> Used to tell plyGame about a plugin. </summary>
		public static void RegisterPlugin(plyGamePluginInfo plugin)
		{
			for (int i = 0; i < plugins.Count; i++)
			{
				if (plugins[i].name.Equals(plugin.name)) return;
			}

			UpdatePluginVersion(plugin);
			plugins.Add(plugin);
		}

		///// <summary> A plugin must call this to inform plyGame that it has just loaded. Do it in the constructor of 
		///// a [InitializeOnLoad] class in the plugin Editor DLL </summary>
		//public static void PluginMessage_JustLoaded(plyGamePluginInfo plugin)
		//{
		//	for (int i = 0; i < plugins.Count; i++)
		//	{
		//		if (plugins[i].name.Equals(plugin.name))
		//		{
		//			plugins[i]._isActive = true;
		//			return;
		//		}
		//	}

		//	UpdatePluginVersion(plugin);
		//	plugin._isActive = true;
		//	plugins.Add(plugin);
		//}

		private static void UpdatePluginVersion(plyGamePluginInfo plugin)
		{
			if (string.IsNullOrEmpty(plugin.versionFile)) return;

			try
			{
				string fn = plyEdUtil.FullPathFromPattern(plugin.versionFile);
				if (fn == null)
				{
					Debug.LogError("Could not resolve full path to: " + plugin.versionFile);
					return;
				}
				using (StreamReader s = File.OpenText(fn))
				{
					plugin.version = s.ReadLine();
					s.Close();
				}
			}
			catch (System.Exception e)
			{
				Debug.LogException(e);
			}
		}

		//public static void EnDisablePlugin(plyGamePluginInfo plugin, bool enable, ref Dictionary<string, string> pluginStats)
		//{
		//	string fn = plyEdUtil.FullProjectPath + "Library/plygame.plugins";
		//	//Debug.Log(fn);

		//	try
		//	{
		//		if (pluginStats.ContainsKey(plugin.name))
		//		{
		//			pluginStats[plugin.name] = (enable ? "1" : "0");
		//		}
		//		else
		//		{
		//			pluginStats.Add(plugin.name, (enable ? "1" : "0"));
		//		}

		//		string data = "";
		//		foreach (KeyValuePair<string, string> kv in pluginStats)
		//		{
		//			data += kv.Key + (char)30 + kv.Value + (char)31;
		//		}

		//		using (StreamWriter sw = new StreamWriter(fn))
		//		{
		//			sw.Write(data);
		//			sw.Close();
		//		}
		//	}
		//	catch (System.Exception e) { Debug.LogError("Error while updating plyGame plugins file\n" + e.Message); }

		//	string newFile = "";
		//	string oldFile = "";

		//	//List<string> touchedFolders = new List<string>();

		//	for (int i = 0; i < plugin.files.Count; i++)
		//	{
		//		if (string.IsNullOrEmpty(plugin.files[i])) continue;

		//		newFile = plugin.files[i] + (enable ? "" : ".disabled");
		//		oldFile = plugin.files[i] + (enable ? ".disabled" : "");

		//		string newPath = null;
		//		string oldPath = null;

		//		FileInfo[] files = new DirectoryInfo(plyEdUtil.FullProjectAssetsPath).GetFiles(oldFile, SearchOption.AllDirectories);
		//		if (files.Length > 0)
		//		{
		//			oldPath = files[0].FullName;
		//			newPath = files[0].DirectoryName + "/" + newFile;
		//			oldPath = oldPath.Replace("\\", "/");
		//			newPath = newPath.Replace("\\", "/");
		//		}

		//		if (oldPath == null)
		//		{
		//			if (enable) Debug.LogWarning(string.Format("The file [{0}] was not found. No way to restore [{1}]. You need to re-import the plugin to get this file back.", oldFile, newFile));
		//			else Debug.LogWarning(string.Format("The file [{0}] was not found. No way to disable the file of this plugin. You need to re-import the plugin to get this file back.", oldFile));
		//			continue;
		//		}

		//		if (File.Exists(newPath))
		//		{
		//			if (enable)
		//			{
		//				Debug.LogWarning(string.Format("The file [{0}] already exist. It could be that you imported a new version of the plugin and plyGame did not pick up on this and auto-disable this file. Enable will skip this file but it might be better if you re-import this plugin after this process is complete.", newFile));
		//				continue;
		//			}
		//			else
		//			{	// simply delete the file to make space
		//				AssetDatabase.DeleteAsset(plyEdUtil.ToRelativePath(newPath));
		//			}
		//		}

		//		newPath = plyEdUtil.ToRelativePath(newPath);
		//		oldPath = plyEdUtil.ToRelativePath(oldPath);
		//		//Debug.Log(string.Format("[{0}] => [{1}]", oldPath, newPath));
		//		AssetDatabase.MoveAsset(oldPath, newPath);

		//		//newPath = plyEdUtil.GetFolder(newPath);
		//		//oldPath = plyEdUtil.GetFolder(oldPath);
		//		//if (!touchedFolders.Contains(newPath)) touchedFolders.Add(newPath);
		//		//if (!touchedFolders.Contains(oldPath)) touchedFolders.Add(oldPath);
		//	}

		//	//AssetDatabase.Refresh();
		//	//for (int i = 0; i < touchedFolders.Count; i++)
		//	//{
		//	//	AssetDatabase.ImportAsset(touchedFolders[i], ImportAssetOptions.ForceUpdate);
		//	//}

		//}

		/// <summary> Register a prefab that should be instantiated when GameGlobal is created.
		/// Thus, automatically created when the game starts. </summary>
		public static void RegisterAutoCreate(GameObject prefab)
		{
			DataAsset d = GetDataAsset();
			if (d.autoCreate == null) d.autoCreate = new List<GameObject>(0);
			if (false == d.autoCreate.Contains(prefab))
			{
				d.autoCreate.Add(prefab);
				EditorUtility.SetDirty(d);
			}
		}

		/// <summary> Remove a prefab that where registered with RegisterAutoCreate() </summary>
		public static void RemoveAutoCreate(GameObject prefab)
		{
			DataAsset d = GetDataAsset();
			if (d.autoCreate == null) d.autoCreate = new List<GameObject>(0);
			if (d.autoCreate.Contains(prefab))
			{
				d.autoCreate.Remove(prefab);
				EditorUtility.SetDirty(d);
			}
		}

		/// <summary> Register a component that should be added to a target object. This is done at startup so do not use
		/// this to add components to objects in your game scenes. The objects on those scenes will not be available in 
		/// time. This is mostly used to add components to objects registered with RegisterAutoCreate() </summary>
		public static void RegisterAutoComponent(string targetObjectName, string componentName)
		{
			string s = targetObjectName + ";" + componentName;
			DataAsset d = GetDataAsset();
			if (d.autoComponents == null) d.autoComponents = new List<string>(0);
			if (false == d.autoComponents.Contains(s))
			{
				d.autoComponents.Add(s);
				EditorUtility.SetDirty(d);
			}
		}

		/// <summary> Remove a component that where registered with RegisterAutoComponent() </summary>
		public static void RemoveAutoComponent(string targetObjectName, string componentName)
		{
			string s = targetObjectName + ";" + componentName;
			DataAsset d = GetDataAsset();
			if (d.autoComponents == null) d.autoComponents = new List<string>(0);
			if (d.autoComponents.Contains(s))
			{
				d.autoComponents.Remove(s);
				EditorUtility.SetDirty(d);
			}
		}

		/// <summary> Get a reference to the data asset. Error if not exist. </summary>
		public static DataAsset GetDataAsset()
		{
			if (_dataAsset == null) _dataAsset = (DataAsset)LoadOrCreateAsset<DataAsset>(plyEdUtil.DATA_PATH_SYSTEM + "data.asset", null);
			return _dataAsset;
		}

		/// <summary> Check that all data related paths are created  </summary>
		public static void CheckDataPaths()
		{
			plyEdUtil.CheckDataPath("Assets/", plyEdUtil.DATA_PATH);
			plyEdUtil.CheckDataPath(plyEdUtil.DATA_PATH, plyEdUtil.DATA_PATH_SYSTEM);
			plyEdUtil.CheckDataPath(plyEdUtil.DATA_PATH, plyEdUtil.DATA_PATH_RESOURCES);
		}

		/// <summary> Loads asset at given path and filename (fn), else create it. Pretty name will be
		///  shown to the user in a popup when asking if the asset may be created. Set prettyName = null
		///  to have it silently create the asset. </summary>
		public static ScriptableObject LoadOrCreateAsset<T>(string fn, string prettyName)
		{
			CheckDataPaths();
			return plyEdUtil.LoadOrCreateAsset<T>(fn, prettyName);
		}

		#endregion
		// ============================================================================================================
		#region unique ID checkers

		private static event GeneralCallback uniqueIdCheckers = null;

		public static void RegisterUniqueIDChecker(GeneralCallback callback)
		{
			uniqueIdCheckers += callback;
		}

		private static void CheckUniqueIDs()
		{
			List<UniqueID> usedIds = new List<UniqueID>();
			uniqueIdCheckers(null, new object[] { usedIds });
			usedIds = null;
		}

		private static void PersistableObjectUniqueIdChecker(object sender, object[] args)
		{
			List<UniqueID> usedIds = (List<UniqueID>)args[0];

			// check prefabs
			List<PersistableObject> fabs = plyEdUtil.FindPrefabsOfTypeAll<PersistableObject>("Please Wait", "Checking PersistableObject Prefabs ...");
			for (int i = 0; i < fabs.Count; i++)
			{
				if (usedIds.Contains(fabs[i].id))
				{
					Debug.Log("Found duplicate ID in " + fabs[i].name + ". Generating new one.");
					fabs[i].id = UniqueID.Create();
					EditorUtility.SetDirty(fabs[i]);
				}
				
				usedIds.Add(fabs[i].id);
			}

			// check scenes
			bool stopped = false;
			float progress = 0f;
			float step = 1f;
			EditorUtility.DisplayProgressBar("Please wait", "Checking PersistableObject in scenes ...", progress);

			// Find Blox used in scenes
			for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
			{
				EditorUtility.DisplayProgressBar("Please wait", "Checking PersistableObject in scenes ...", 0f);
				if (EditorApplication.OpenScene(EditorBuildSettings.scenes[i].path))
				{
					PersistableObject[] objs = Object.FindObjectsOfType<PersistableObject>();
					if (objs.Length > 0)
					{
						progress = 0f;
						step = 1f / (float)objs.Length;
						for (int j = 0; j < objs.Length; j++)
						{
							progress += step;
							if (EditorUtility.DisplayCancelableProgressBar("Please wait", "Checking PersistableObject in scenes ...", progress))
							{
								stopped = true;
								break;
							}

							if (usedIds.Contains(objs[j].id))
							{
								Debug.Log("Found duplicate ID in " + EditorBuildSettings.scenes[i].path + "/" + objs[j].name + ". Generating new one.");
								objs[j].id = UniqueID.Create();
								EditorUtility.SetDirty(objs[j]);
							}

							usedIds.Add(objs[j].id);
						}

						if (stopped) break;
					}
				}
			}

			EditorUtility.ClearProgressBar();
		}

		#endregion
		// ============================================================================================================
		#region Helpers

		public static bool UpdateBuildSettings(bool complete)
		{
			// if "complete = true" then more things will be run through and refreshed
			// use this to determine if slow things should update too

			string prevScene = EditorApplication.currentScene;
			if (!EditorApplication.SaveCurrentSceneIfUserWantsTo()) return false;

			CheckLayersAndTags();
			if (complete)
			{
				if (EditorUtility.DisplayDialog("Generate Link File?", "This could take a while and is only needed if you are creating a mobile build and want to use stripping.", "Yes", "No"))
				{
					plyBloxSettingsEd.UpdateLinkerFile();
				}
			}

			// ----------------------------------------------------------------------------
			// Check if GameGlobal is setup properly
			// Setup BOOTSTRAP scene
			bool err = true;
			if (EditorApplication.OpenScene(plyEdUtil.DATA_PATH_SYSTEM + "00-bootstrap.unity"))
			{
				GameObject go = GameObject.Find("plyGame");
				if (go)
				{
					GameGlobal b = go.GetComponent<GameGlobal>();
					if (b)
					{
						err = false;

						if (b.bloxGlobalFab == null) err = true;
						if (b.uiManagerFab == null) err = true;
						if (b.inputAsset == null) err = true;
						if (b.splashAsset == null) err = true;
						if (b.langScrAsset == null) err = true;
						if (b.custScrAsset == null) err = true;
						if (b.loadScrAsset == null) err = true;
						if (b.dataAsset == null) err = true;
					}
				}
			}

			if (err)
			{
				if (EditorUtility.DisplayDialog("Data Missing", "The plyGame Data setup seems to be incomplete. Initialise plyGame now?", "Yes", "No"))
				{
					CreateData();
				}
				else
				{
					EditorApplication.OpenScene(prevScene);
					return false;
				}
			}

			// ----------------------------------------------------------------------------
			// Update the Build Settings - check that the bootstrap scene is present

			List<string> paths = new List<string>();
			for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
			{
				if (EditorBuildSettings.scenes[i].enabled && false == EditorBuildSettings.scenes[i].path.Equals(edData.bootstrapScene))
				{
					paths.Add(EditorBuildSettings.scenes[i].path);
				}
			}

			EditorBuildSettingsScene[] scenes = new EditorBuildSettingsScene[paths.Count + 1];
			scenes[0] = new EditorBuildSettingsScene { enabled = true, path = edData.bootstrapScene };
			for (int i = 0; i < paths.Count; i++) scenes[i + 1] = new EditorBuildSettingsScene { enabled = true, path = paths[i] };
			EditorBuildSettings.scenes = scenes;

			// ----------------------------------------------------------------------------
			// Check Unique IDs

			if (complete)
			{
				if (EditorUtility.DisplayDialog("Check IDs", "Check Unique IDs? This is needed to make sure that there are no duplicate IDs present but can take a while to complete. You only really need to run this when you want to make a build ready or for testing the loading and saving system.", "Yes", "No"))
				{
					CheckUniqueIDs();
				}
			}

			// ----------------------------------------------------------------------------
			// done, reopen previous scene

			EditorApplication.OpenScene(prevScene);

			return true;
		}

		private static void RefreshAndRunGame()
		{
			EditorPrefs.SetString("plyGame.PlayTestingModeScene", EditorApplication.currentScene);
			if (UpdateBuildSettings(false))
			{
				if (EditorApplication.OpenScene(edData.bootstrapScene))
				{
					EditorPrefs.SetInt("plyGame.CurrentPlayTestingMode", 2);
					EditorApplication.isPlaying = true;
					playTestingMode = 2;
				}
			}
		}

		private static void OnDataPathChanged(object sender, object[] args)
		{	// called when the data path (Assets/plyData) is changed
			string oldPath = (string)args[0];

			if (edData.bootstrapScene.StartsWith(oldPath))
			{
				edData.bootstrapScene = edData.bootstrapScene.Replace(oldPath, plyEdUtil.DataPath);
				EditorUtility.SetDirty(edData);
			}

			for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
			{
				if (EditorBuildSettings.scenes[i].path.StartsWith(oldPath))
				{
					EditorBuildSettings.scenes[i].path = EditorBuildSettings.scenes[i].path.Replace(oldPath, plyEdUtil.DataPath);
				}
			}
		}

		#endregion
		// ============================================================================================================
	}
}
