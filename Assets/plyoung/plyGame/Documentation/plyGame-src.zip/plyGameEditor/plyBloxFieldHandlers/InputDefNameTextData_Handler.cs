﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(InputDefNameTextData))]
	public class InputDefNameTextData_Handler : plyBlockFieldHandler
	{

		private string[] names = new string[0];
		private InputDefAsset inputAsset;

		public override object GetCopy(object obj)
		{
			InputDefNameTextData target = obj as InputDefNameTextData;
			if (target != null) return target.Copy();
			return new InputDefNameTextData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			InputDefNameTextData target = obj == null ? new InputDefNameTextData() : obj as InputDefNameTextData;
			CheckNamesArray();
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			InputDefNameTextData target = obj == null ? new InputDefNameTextData() : obj as InputDefNameTextData;

			EditorGUI.BeginChangeCheck();
			target.name = EditorGUILayout.TextField(target.name, plyEdGUI.TextFieldNoLRMarginStyle);
			if (EditorGUI.EndChangeCheck()) ret = true;

			int sel = EditorGUILayout.Popup(-1, names, EditorStyles.miniButtonRight, GUILayout.Width(20));
			if (sel >= 0)
			{
				target.name = names[sel]; // names[sel].Substring(names[sel].IndexOf('/') + 1);
				ret = true;
			}

			obj = target;
			return ret;
		}

		private void CheckNamesArray()
		{
			inputAsset = (InputDefAsset)EdGlobal.LoadOrCreateAsset<InputDefAsset>(plyEdUtil.DATA_PATH_SYSTEM + "input.asset", "Input Definitions");
			if (names.Length != inputAsset.inputDefs.Count)
			{
				names = new string[inputAsset.inputDefs.Count];
				for (int i = 0; i < names.Length; i++)
				{
					names[i] = inputAsset.inputDefs[i].category + "/" + inputAsset.inputDefs[i].name;
				}
			}
		}

		// ============================================================================================================
	}
}