﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

namespace plyGameEditor
{
	/// <summary> Attribute for load save provider editor, used when defining the editor, derived from
	///  LoadSaveProviderEdBase, of the LoadSave provider. </summary>
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
	public class LoadSaveProviderAttribute : System.Attribute
	{
		public string Name;					//!< The name of the provider. Shown to user
		public System.Type ProviderType;	//!< Type of the provider that the editor handles

		/// <summary> Constructor. </summary>
		/// <param name="name">		    The name of the provider. Shown to user. </param>
		/// <param name="providerType"> Type of the provider that the editor handles. </param>
		public LoadSaveProviderAttribute(string name, System.Type providerType)
		{
			this.Name = name;
			this.ProviderType = providerType;
		}

		// ============================================================================================================
	}
}