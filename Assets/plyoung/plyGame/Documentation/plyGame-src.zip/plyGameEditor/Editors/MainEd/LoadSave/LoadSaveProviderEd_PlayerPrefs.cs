﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using plyGame;

namespace plyGameEditor
{
	[LoadSaveProvider("PlayerPrefs", typeof(LoadSave_PlayerPrefs))]
	public class LoadSaveProviderEd_PlayerPrefs : LoadSaveProviderEdBase
	{
		public override void OnGUI(EditorWindow ed, LoadSaveProviderBase data)
		{
			GUILayout.Label("This LoadSave Provider makes use of Unity's PlayerPrefs for saving and loading.");
		}

		// ============================================================================================================
	}
}