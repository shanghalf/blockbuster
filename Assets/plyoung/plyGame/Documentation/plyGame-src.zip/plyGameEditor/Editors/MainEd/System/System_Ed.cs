﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using plyGame;
using plyCommon;
using plyBloxKit;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyBloxKitEditor;
using System.Reflection;
using System.IO;

namespace plyGameEditor
{
	[ChildEditor("Main", Order = -100000, Icon = "main")]
	public class System_Ed : ChildEditorBase
	{
		#region vars

		private static readonly GUIContent[] MenuOpts = { 
					new GUIContent("Project"),
					new GUIContent("Global Variables"),
					new GUIContent("Input Definitions"),
					new GUIContent("Loading & Saving"),
					new GUIContent("Sound Settings"),
					new GUIContent("Auto Instantiate"),
					null,
					new GUIContent("System"),
					new GUIContent("Documentation")};

		private int sel = 0, prevSel = 0;
		private string dataPath = "/Assets/plyData";
		private string prevPath = "/Assets/plyData";

		private InputDefAsset inputAsset;
		private DataAsset dataAsset;

		private static GUIContent GC_AddInputGroup;
		private static GUIContent GC_ResetInput;
		private static GUIContent GC_AddInput;
		private static GUIContent GC_DelInput;
		private static GUIContent GC_SetupInput;
		private static GUIContent GC_AddScene;
		private static GUIContent GC_ToggleRight;
		private static GUIContent GC_ToggleDown;

		private static GUIContent GC_DelInputDef;
		private static GUIContent GC_AddInputBind;
		private static GUIContent GC_DelInputBind;
		private static GUIContent GC_EditBind;
		private static GUIContent GC_CollapseInput;

		//private string currSlot = null;
		//private ItemType currItemType = null;
		//private string currItemSubType = null;

		private Vector2[] scroll = new Vector2[] { Vector2.zero, Vector2.zero };
		private string[] loadSaveProviderNames = new string[0];
		private int currLoadSaveIdx = -1;
		private LoadSaveProviderBase lsProvider = null;
		private int selectedAutoFab = -1;

		//private Dictionary<string, string> pluginStats = new Dictionary<string, string>();

		#endregion
		// ============================================================================================================
		#region sys

		public override void OnFocus()
		{
			dataPath = plyEdUtil.DataPath;
			dataPath = plyEdUtil.FullProjectPath + dataPath;
			prevPath = dataPath;

			if (inputAsset == null)
			{
				inputAsset = (InputDefAsset)EdGlobal.LoadOrCreateAsset<InputDefAsset>(plyEdUtil.DATA_PATH_SYSTEM + "input.asset", "Input Definitions");
				SortInputs(inputAsset);
			}

			if (dataAsset == null)
			{
				dataAsset = (DataAsset)EdGlobal.LoadOrCreateAsset<DataAsset>(plyEdUtil.DATA_PATH_SYSTEM + "data.asset", "Global Data");
			}

			CreateDefaultLoadSaveProvider(dataAsset);
			if (dataAsset.loadSaveProviderFab != null)
			{
				lsProvider = dataAsset.loadSaveProviderFab.GetComponent<LoadSaveProviderBase>();
			}

			currLoadSaveIdx = -1;
			loadSaveProviderNames = new string[EdGlobal.loadSaveEditors.Length];
			for (int i = 0; i < EdGlobal.loadSaveEditors.Length; i++)
			{
				if (dataAsset.loadSaveProviderFab == null)
				{
					CreateProvider(EdGlobal.loadSaveEditors[i]);
				}

				loadSaveProviderNames[i] = EdGlobal.loadSaveEditors[i].name;
				if (lsProvider.GetType() == EdGlobal.loadSaveEditors[i].providerType) currLoadSaveIdx = i;
			}

			//UpdatePluginStats();
		}

		private void CheckGUIContent()
		{
			if (GC_AddScene == null)
			{
				GC_AddScene = new GUIContent(FA.plus_circle.ToString(), "Add scene");

				GC_AddInputGroup = new GUIContent(FA.plus + " Add Input Group", "Add new input definition group");
				GC_ResetInput = new GUIContent(FA.undo +  " Reset to Defaults", "Reset definitions to defaults");
				GC_AddInput = new GUIContent(FA.plus_circle.ToString(), "Add new input definition");
				GC_DelInput = new GUIContent(FA.times_circle.ToString(), "Remove input category");
				GC_ToggleRight = new GUIContent(FA.chevron_right.ToString(), "Show definitions of input group");
				GC_ToggleDown = new GUIContent(FA.chevron_down.ToString(), "Hide definitions of input group");
				GC_SetupInput = new GUIContent(FA.keyboard_o + " Setup Input Manager", "Setup Unity InputManager");
				GC_CollapseInput = new GUIContent(FA.angle_double_right + " Collapse All", "Collapse all Input Groups");

				GC_DelInputDef = new GUIContent(plyEdGUI.Texture_ListItemDel2Button, "Remove this input definition");
				GC_AddInputBind = new GUIContent(plyEdGUI.Texture_ListItemAddButton, "Add input bind to definition");
				GC_DelInputBind = new GUIContent(plyEdGUI.Texture_ListItemDelButton, "Remove selected input bind from definition");
				GC_EditBind = new GUIContent(FA.Ico12(FA.edit, plyEdGUI.IconColor), "Edit input bind");
			}
		}

		public override void OnGUI()
		{
			CheckGUIContent();
			EditorGUILayout.BeginHorizontal();
			{
				prevSel = sel;
				sel = plyEdGUI.Menu(sel, MenuOpts, GUILayout.Width(MainEditorWindow.MenuWidth));

				if (sel != prevSel)
				{
					scroll[0] = Vector2.zero;
					scroll[1] = Vector2.zero;
				}

				switch (sel)
				{
					case 0: Project(); break;
					case 1:
					{
						sel = 0;
						plyBloxSettingsEd.Show_plyBloxSettingsEd();
					} break;
					case 2: InputDefs(); break;
					case 3: LoadSave(); break;
					case 4: SoundSettings(); break;
					case 5: AutoObjects(); break;
					case 6: break; // spacer
					case 7: SystemEd(); break;
					case 8:
					{
						sel = 0;
						Application.OpenURL(EdGlobal.HLP_MainEd);
					} break;
				}
			}
			EditorGUILayout.EndHorizontal();
		}

		#endregion
		// ============================================================================================================
		#region system

		private void SystemEd()
		{
			EditorGUILayout.BeginVertical();
			{
				ShowPlugins();

				EditorGUILayout.Space();
				plyEdGUI.SectionHeading("System Settings");


				plyEdGUI.LookLikeControls(200, 450);
				EdGlobal.floorLayer = plyEdGUI.LayerMaskField("Default Floor Placement Layer", EdGlobal.floorLayer, 450);
			}
			EditorGUILayout.EndVertical();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorPrefs.SetInt("plyGame.Ed.FloorLayer", EdGlobal.floorLayer);
			}
		}

		private void ShowPlugins()
		{
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				plyEdGUI.SectionHeading("Plugins", false);
				EditorGUILayout.Space();
				if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
				{
					Application.OpenURL(EdGlobal.HLP_SystemEd);
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.HLine(5);

			bool style2 = true;
			for (int i = 0; i < EdGlobal.plugins.Count; i++)
			{
				if (EdGlobal.plugins[i] == null) continue;

				EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
				{
					EditorGUILayout.Space();
					GUILayout.Label(string.Format("{0} ({1})", EdGlobal.plugins[i].name, EdGlobal.plugins[i].version));
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
			}

			//int act = 0;
			//int idx = -1;
			//bool style2 = true;
			//for (int i = 0; i < EdGlobal.plugins.Count; i++)
			//{
			//	if (EdGlobal.plugins[i] == null) continue;

			//	EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
			//	{
			//		EditorGUILayout.Space();
			//		GUILayout.Label(string.Format("{0} ({1})", EdGlobal.plugins[i].name, EdGlobal.plugins[i].version));
			//		GUILayout.FlexibleSpace();
			//	}
			//	EditorGUILayout.EndHorizontal();

				//bool isEnabled = true;
				//string stat = "1";
				//if (pluginStats.TryGetValue(EdGlobal.plugins[i].name, out stat))
				//{
				//	if (stat != "1") isEnabled = false;
				//}

				//style2 = !style2;
				//GUI.backgroundColor = isEnabled ? Color.green : Color.red;
				//EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
				//{
				//	GUI.backgroundColor = Color.white;
				//	if (isEnabled)
				//	{
				//		if (GUILayout.Button("Disable", GUILayout.Width(120)))
				//		{
				//			if (EditorUtility.DisplayDialog("Disable Plugin", "Disabling the plugin will cause runtime and editor code related to this plugin to be disabled. If you created objects that depend on scripts from this plugin then those objects will become broken as the components on them will be invalid. Continue?", "Yes", "No"))
				//			{
				//				act = 1; idx = i;
				//			}
				//		}
				//	}
				//	else
				//	{
				//		if (GUILayout.Button("Enable", GUILayout.Width(120)))
				//		{
				//			act = 2; idx = i;
				//		}
				//	}

				//	EditorGUILayout.Space();
				//	GUILayout.Label(string.Format("{0} ({1})", EdGlobal.plugins[i].name, EdGlobal.plugins[i].version));
				//	GUILayout.FlexibleSpace();
				//}
				//EditorGUILayout.EndHorizontal();
			//}

			//if (idx >= 0 && act > 0)
			//{
			//	EdGlobal.EnDisablePlugin(EdGlobal.plugins[idx], (act == 2), ref pluginStats);
			//	EdGlobal.plugins[idx]._isActive = (act == 2);
			//	EditorUtility.DisplayDialog("Restart Unity", "Please restart Unity for the changes to take affect.", "Ok");
			//}
		}

		//private void UpdatePluginStats()
		//{
		//	string fn = plyEdUtil.FullProjectPath + "Library/plygame.plugins";
		//	string data = "";
		//	try
		//	{
		//		if (File.Exists(fn))
		//		{
		//			using (StreamReader sr = new StreamReader(fn))
		//			{
		//				data = sr.ReadToEnd();
		//				sr.Close();
		//			}
		//		}
		//	}
		//	catch { }

		//	pluginStats = new Dictionary<string, string>();
		//	if (false == string.IsNullOrEmpty(data))
		//	{
		//		string[] vals = data.Split((char)31);
		//		for (int i = 0; i < vals.Length; i++)
		//		{
		//			string[] v = vals[i].Split((char)30);
		//			if (v.Length == 2)
		//			{
		//				if (false == pluginStats.ContainsKey(v[0]))
		//				{
		//					pluginStats.Add(v[0], v[1]);
		//				}
		//			}
		//		}
		//	}
		//}

		#endregion
		// ============================================================================================================
		#region project

		private void Project()
		{
			int ren=-1, del=-1;

			EditorGUILayout.BeginVertical();
			{
				EditorGUILayout.Space();
				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.SectionHeading("Project", false);
					EditorGUILayout.Space();
					if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
					{
						Application.OpenURL(EdGlobal.HLP_ProjectEd);
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				plyEdGUI.HLine(5);

				if (plyEdGUI.LabelButton("Refresh", "Refresh and Update Build Settings", 115, 335))
				{
					EdGlobal.RefreshBuild();
				}

				if (plyEdGUI.LabelButton("Languages", "Edit Languages", 115, 335))
				{
					LanguageEditor.Show_Language_Ed();
				}

				GUILayout.Space(20);
				plyEdGUI.SectionHeading("Main Paths");
				//EditorGUILayout.BeginHorizontal();
				//{
				//	plyEdGUI.SectionHeading("Main Paths", false);
				//	EditorGUILayout.Space();
				//	if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
				//	{
				//		Application.OpenURL(EdGlobal.HLP_ProjectEd);
				//	}
				//	GUILayout.FlexibleSpace();
				//}
				//EditorGUILayout.EndHorizontal();
				//plyEdGUI.HLine(5);

				EditorGUI.BeginChangeCheck();
				dataPath = plyEdGUI.PathField(dataPath, "Data Path", "Data Path", 115, 335);
				if (EditorGUI.EndChangeCheck()) plyEdUtil.ChangeDataPath(ref dataPath, ref prevPath);

				// I'm not gonna allow changing the bootstrap cause the init process is complicated and 3rd parties might mess it up
				//EditorGUI.BeginChangeCheck();
				//EdGlobal.edData.bootstrapScene = plyEdGUI.RelativeFileField(EdGlobal.edData.bootstrapScene, "Bootstrap Scene", "Select Scene", "unity", 115, 335);
				//if (EditorGUI.EndChangeCheck()) EdGlobal.UpdateBuildSettings(false);
				GUI.enabled = false;
				plyEdGUI.RelativeFileField(EdGlobal.edData.bootstrapScene, "Bootstrap Scene", "Select Scene", "unity", 115, 335);
				GUI.enabled = true;

				GUILayout.Space(20);
				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.SectionHeading("All Game Scenes", false);
					EditorGUILayout.Space();
					if (GUILayout.Button(GC_AddScene, plyEdGUI.FlatIconButtonStyle))
					{
						string fn = EditorUtility.OpenFilePanel("Select Scene", plyEdUtil.FullProjectAssetsPath, "unity");
						if (!string.IsNullOrEmpty(fn))
						{
							fn = plyEdUtil.ProjectRelativePath(fn);
							EditorBuildSettingsScene[] scenes = new EditorBuildSettingsScene[EditorBuildSettings.scenes.Length + 1];
							for (int i = 0; i < EditorBuildSettings.scenes.Length; i++) scenes[i] = EditorBuildSettings.scenes[i];
							scenes[scenes.Length-1] = new EditorBuildSettingsScene { enabled = true, path = fn };
							EditorBuildSettings.scenes = scenes;
						}
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				plyEdGUI.HLine(5);

				scroll[0] = EditorGUILayout.BeginScrollView(scroll[0]);
				{
					for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
					{
						if (i == 0) continue;
						EditorGUILayout.BeginHorizontal();
						{
							GUILayout.Label(" ", plyEdGUI.ButtonLeftStyle, GUILayout.Width(15));
							if (GUILayout.Button(EditorBuildSettings.scenes[i].path, plyEdGUI.ButtonMidStyle, GUILayout.Width(375)))
							{
								if (EditorApplication.SaveCurrentSceneIfUserWantsTo())
								{
									EditorApplication.OpenScene(EditorBuildSettings.scenes[i].path);
									if (SceneView.sceneViews.Count > 0) ((SceneView)SceneView.sceneViews[0]).Focus();
								}
							}
							if (GUILayout.Button(plyEdGUI.GC_Rename, plyEdGUI.IconButtonMidStyle, GUILayout.Width(30)))
							{
								ren = i;
							}
							if (GUILayout.Button(plyEdGUI.GC_Remove, plyEdGUI.IconButtonRightStyle, GUILayout.Width(30)))
							{
								del = i;
							}
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				EditorGUILayout.EndScrollView();
			}
			EditorGUILayout.EndVertical();

			if (del >= 0)
			{
				//if (EditorBuildSettings.scenes[del].path == EdGlobal.edData.bootstrapScene)
				//{
				//	EditorUtility.DisplayDialog("Error", "You can't remove the main (bootstrap) scene.", "Ok");
				//	return;
				//}

				if (EditorBuildSettings.scenes.Length > 0)
				{
					EditorBuildSettingsScene[] scenes = new EditorBuildSettingsScene[EditorBuildSettings.scenes.Length - 1];
					int j = 0;
					for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
					{
						if (i != del) { scenes[j] = EditorBuildSettings.scenes[i]; j++; }
					}
					EditorBuildSettings.scenes = scenes;
				}
				else
				{
					EditorBuildSettings.scenes = new EditorBuildSettingsScene[0];
				}

				ed.Repaint();
			}

			if (ren >= 0)
			{
				if (EditorBuildSettings.scenes[ren].path == EdGlobal.edData.bootstrapScene)
				{
					EditorUtility.DisplayDialog("Error", "You can't rename the main (bootstrap) scene.", "Ok");
					return;
				}
				plyTextInputWiz.ShowWiz("Rename Scene", "Enter unique name for scene", plyEdUtil.SceneNameFromPath(EditorBuildSettings.scenes[ren].path), OnRenameScene, new object[] { ren });
			}

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(EdGlobal.edData);
			}
		}

		private void OnRenameScene(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string name = wiz.text;
			wiz.Close();

			int renaming = (int)args[0];
			if (renaming == -1 || string.IsNullOrEmpty(name)) return;

			string res = AssetDatabase.RenameAsset(EditorBuildSettings.scenes[renaming].path, name);
			if (!string.IsNullOrEmpty(res))
			{
				EditorUtility.DisplayDialog("Error", res, "Close");
			}
			ed.Repaint();
		}

		#endregion
		// ============================================================================================================
		#region Input Def

		private static Dictionary<string, List<InputDefinition>> inputs { get; set; }
		private InputDefinition selectedDef = null;
		private InputBind selectedBind = null;
		private bool[] inputCollapsed = new bool[0];

		public static void DefineDefaultInputBinds(InputDefAsset asset)
		{
			// clear old inputs
			bool cleared = false;
			if (EditorUtility.DisplayDialog("Remove old Defines?", "Remove existing input defines before importing defaults?", "Yes", "No"))
			{
				asset.inputDefs = new List<InputDefinition>();
				cleared = true;
			}

			// find input definers
			Assembly[] asms = System.AppDomain.CurrentDomain.GetAssemblies();
			List<System.Type> definerTypes = new List<System.Type>();
			for (int i = 0; i < asms.Length; i++)
			{
				System.Type[] types = asms[i].GetExportedTypes();
				for (int j = 0; j < types.Length; j++)
				{
					if (types[j].IsClass && typeof(InputDefiner).IsAssignableFrom(types[j]) && types[j].Name != "InputDefiner")
					{
						definerTypes.Add(types[j]);
					}
				}
			}

			// ask input definers for input definitions
			for (int i = 0; i < definerTypes.Count; i++)
			{
				InputDefiner d = (InputDefiner)System.Activator.CreateInstance(definerTypes[i]);
				if (cleared) asset.inputDefs.AddRange(d.DefineInput());
				else
				{
					List<InputDefinition> defs = d.DefineInput();
					for (int b = 0; b < defs.Count; b++)
					{
						for (int a = 0; a < asset.inputDefs.Count; a++)
						{	// check if existing define is in defs and remove it now as it will be re-added later
							if (string.IsNullOrEmpty(asset.inputDefs[a].name)) continue;
							if (asset.inputDefs[a].category.Equals(defs[b].category) && asset.inputDefs[a].name.Equals(defs[b].name))
							{
								asset.inputDefs.RemoveAt(a);
								break;
							}
						}
					}
					asset.inputDefs.AddRange(defs);
				}
			}

			// save
			EditorUtility.SetDirty(asset);
			AssetDatabase.SaveAssets();
			SortInputs(asset);
		}

		private static void SortInputs(InputDefAsset asset)
		{			
			inputs = new Dictionary<string, List<InputDefinition>>();
			for (int i = 0; i < asset.inputDefs.Count; i++)
			{
				List<InputDefinition> l = null;
				if (inputs.ContainsKey(asset.inputDefs[i].category)) l = inputs[asset.inputDefs[i].category];
				if (l == null)
				{
					l = new List<InputDefinition>();
					inputs.Add(asset.inputDefs[i].category, l);
				}
				l.Add(asset.inputDefs[i]);
			}
		}

		private void InputDefs()
		{
			InputDefinition del = null;
			string delcat = null;

			EditorGUILayout.BeginVertical();
			{
				// --------------------------------------------------------------------------------------------
				// Toolbar

				EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
				{
					if (GUILayout.Button(GC_CollapseInput, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(100)))
					{
						for (int i = 0; i < inputCollapsed.Length; i++) inputCollapsed[i] = true;
					}
					if (GUILayout.Button(GC_AddInputGroup, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(130)))
					{
						plyEdGUI.ClearFocus();
						plyTextInputWiz.ShowWiz("Create Group", "Enter unique input group name", "", OnInputGroupName, new object[] { 0 });
					}
					if (GUILayout.Button(GC_ResetInput, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(140)))
					{
						plyEdGUI.ClearFocus();
						DefineDefaultInputBinds(inputAsset);
					}
					if (GUILayout.Button(GC_SetupInput, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(160)))
					{
						plyEdGUI.ClearFocus();
						SetupInputManager();
						EditorUtility.DisplayDialog("Done", "The Unity Input Manager has been updated.", "Ok");
					}					
					EditorGUILayout.Space();
					if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.ToolbarIconButtonStyle))
					{
						Application.OpenURL(EdGlobal.HLP_InputManager);
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Space();

				// --------------------------------------------------------------------------------------------
				// Input Definitions

				scroll[0] = EditorGUILayout.BeginScrollView(scroll[0]);
				EditorGUILayout.BeginVertical(plyEdGUI.LRPaddingHelperStyle);
				{
					if (inputCollapsed.Length != inputs.Count) inputCollapsed = new bool[inputs.Count];
					int idx = -1;
					foreach (KeyValuePair<string, List<InputDefinition>> kv in inputs)
					{
						idx++;
						EditorGUILayout.Space();
						EditorGUILayout.BeginHorizontal();
						{
							GUILayout.Space(20);
							
							// Button to add definition
							if (GUILayout.Button(GC_AddInput, plyEdGUI.FlatIconButtonStyle))
							{
								string s = kv.Key;
								plyEdGUI.ClearFocus();
								plyTextInputWiz.ShowWiz("Create Definition", "Enter unique input definition name", "", OnInputDefName, new object[] { 0, s });								
							}
							if (GUILayout.Button(GC_DelInput, plyEdGUI.FlatIconButtonStyle))
							{
								if (EditorUtility.DisplayDialog("Remove Category", "This will remove all input definitions of this category.", "Continue", "Cancel"))
								{
									delcat = kv.Key;
									plyEdGUI.ClearFocus();
								}
							}
							GUILayout.Space(5);
							if (GUILayout.Button(inputCollapsed[idx] ? GC_ToggleRight : GC_ToggleDown, plyEdGUI.FlatIconButtonStyle)) inputCollapsed[idx] = !inputCollapsed[idx];
							GUILayout.Space(5);
							GUILayout.Label(kv.Key, plyEdGUI.LargeFALabelStyle);
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
						GUILayout.Space(15);

						if (inputCollapsed[idx]) continue;

						foreach (InputDefinition def in kv.Value)
						{
							if (string.IsNullOrEmpty(def.name)) continue; // there might be an empty define when the category is created for first time
							EditorGUILayout.BeginVertical(plyEdGUI.ItemListBoxStyle);
							{
								EditorGUILayout.BeginHorizontal();
								{
									GUILayout.Space(6);
									def.active = EditorGUILayout.Toggle(def.active, GUILayout.Width(20));
									GUI.enabled = def.active;

									// Button to Delete definition
									if (GUILayout.Button(GC_DelInputDef, plyEdGUI.ItemListButtonStyle)) del = def;
									EditorGUILayout.Space();

									// Button to Add Bind
									if (GUILayout.Button(GC_AddInputBind, plyEdGUI.ItemListButtonStyle))
									{
										System.Array.Resize<InputBind>(ref def.binds, def.binds.Length + 1);
										def.binds[def.binds.Length - 1] = new InputBind();
										EditorUtility.SetDirty(inputAsset);
									}

									// Button to Delete selected Bind									
									GUI.enabled = (selectedDef == def && selectedBind != null && def.active);
									if (GUILayout.Button(GC_DelInputBind, plyEdGUI.ItemListButtonStyle))
									{
										if (def.binds.Length <= 1) def.binds = new InputBind[0];
										else
										{
											InputBind[] binds = new InputBind[def.binds.Length - 1];
											int j = 0;
											for (int i = 0; i < def.binds.Length; i++)
											{
												if (def.binds[i] != selectedBind)
												{
													binds[j] = def.binds[i];
													j++; if (j == binds.Length) break;
												}
											}
											def.binds = new InputBind[binds.Length];
											binds.CopyTo(def.binds, 0);
										}

										EditorUtility.SetDirty(inputAsset);
										selectedDef = null; selectedBind = null;
									}
									GUI.enabled = def.active;
									EditorGUILayout.Space();

									GUILayout.Label(def.name, plyEdGUI.ItemListHeadStyle);
									GUILayout.FlexibleSpace();
								}
								EditorGUILayout.EndHorizontal();
								GUILayout.Space(5);
								EditorGUI.BeginDisabledGroup(!def.active);

								// Common definition info
								EditorGUILayout.BeginHorizontal();
								def.type = (InputDefinition.InputType)EditorGUILayout.EnumPopup(def.type, GUILayout.Width(100));
								EditorGUILayout.Space();
								plyEdGUI.LookLikeControls(100, 100);
								def.screenName1 = EditorGUILayout.TextField("Screen Name 1:", def.screenName1);
								GUILayout.Space(5);
								plyEdGUI.LookLikeControls(80, 100);
								def.screenName2 = EditorGUILayout.TextField("and Name 2:", def.screenName2);
								GUILayout.FlexibleSpace();
								EditorGUILayout.EndHorizontal();
								GUILayout.Space(5);
								plyEdGUI.LookLikeControls(0, 0);

								// The Binds
								if (def.active)
								{
									bool style2 = false;
									for (int i = 0; i < def.binds.Length; i++)
									{
										style2 = !style2;
										Rect r = EditorGUILayout.BeginHorizontal(def.binds[i] == selectedBind ? plyEdGUI.ItemListEntrySelectedStyle : style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
										{
											// Button to edit a bind
											if (GUILayout.Button(GC_EditBind, EditorStyles.miniButtonLeft))
											{
												InputSelectWiz.Show_Wiz(def.binds[i], def.type, def.name, OnInputWiz, new object[] { def, i });
											}

											GUILayout.Label(def.binds[i].device.ToString() + ": ");

											// ** Info for a Button type bind
											if (def.type == InputDefinition.InputType.Button)
											{
												if (def.binds[i].device == InputBind.Device.KeyMouse)
												{
													if (def.binds[i].keyMod != KeyCode.None) GUILayout.Label("[" + def.binds[i].keyMod + "] +");
													if (def.binds[i].key1 != KeyCode.None) GUILayout.Label("[" + def.binds[i].key1 + "]");
													else if (def.binds[i].mouseAxis != InputBind.MouseAxis.None) GUILayout.Label("[" + (def.binds[i].mouseAxisSide == InputBind.AxisSide.Positive ? "+":"-") + def.binds[i].mouseAxis + "]");
												}
												if (def.binds[i].device == InputBind.Device.Gamepad)
												{
													if (def.binds[i].gamepadAxisMod != InputBind.GamepadAxis.None) GUILayout.Label("[" + (def.binds[i].gamepadAxisModSide == InputBind.AxisSide.Negative ? "-" : "+") + def.binds[i].gamepadAxisMod + "] +");
													else if (def.binds[i].keyMod != KeyCode.None) GUILayout.Label("[" + def.binds[i].keyMod + "] +");
													if (def.binds[i].gamepadAxis != InputBind.GamepadAxis.None) GUILayout.Label("[" + (def.binds[i].gamepadAxisSide == InputBind.AxisSide.Negative ? "-" : "+") + def.binds[i].gamepadAxis + "]");
													if (def.binds[i].key1 != KeyCode.None) GUILayout.Label("[" + def.binds[i].key1 + "]");
												}
											}

											// ** Info for an Axis type bind
											else if (def.type == InputDefinition.InputType.Axis)
											{
												if (def.binds[i].device == InputBind.Device.KeyMouse)
												{
													if (def.binds[i].keyMod != KeyCode.None) GUILayout.Label("[" + def.binds[i].keyMod + "] +");
													if (def.binds[i].key2 != KeyCode.None || def.binds[i].key1 != KeyCode.None) GUILayout.Label("[" + def.binds[i].key1 + "] <-> [" + def.binds[i].key2 + "]");
													if (def.binds[i].mouseAxis != InputBind.MouseAxis.None) GUILayout.Label("[" + def.binds[i].mouseAxis + "]");
													if (def.binds[i].keyMouseInvert) GUILayout.Label("[inverted]");
												}
												if (def.binds[i].device == InputBind.Device.Gamepad)
												{
													if (def.binds[i].key2 != KeyCode.None || def.binds[i].key1 != KeyCode.None) GUILayout.Label("[" + def.binds[i].key1 + "] <-> [" + def.binds[i].key2 + "]");
													if (def.binds[i].gamepadAxis != InputBind.GamepadAxis.None) GUILayout.Label("[" + def.binds[i].gamepadAxis + "]");
													if (def.binds[i].gamepadInvert) GUILayout.Label("[inverted]");
												}
											}

											GUILayout.FlexibleSpace();
										}
										EditorGUILayout.EndHorizontal();

										if (Event.current.type == EventType.MouseDown && selectedBind != def.binds[i])
										{
											if (r.Contains(Event.current.mousePosition))
											{
												plyEdGUI.ClearFocus();
												selectedDef = def;
												selectedBind = def.binds[i];
												ed.Repaint();
											}
										}
									}
								}

							}
							EditorGUILayout.EndVertical();
							EditorGUILayout.Space();
							GUI.enabled = true;
						}
						EditorGUILayout.Space();
					}
					EditorGUILayout.Space();
				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();

				// --------------------------------------------------------------------------------------------
			}
			EditorGUILayout.EndVertical();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(inputAsset);
			}

			if (del != null)
			{
				int pos = inputAsset.inputDefs.IndexOf(del);
				inputAsset.inputDefs.Remove(del);
				
				// if no more more defines left then add empty one so that category do not go away
				bool foundOne = false;
				for (int i = 0; i < inputAsset.inputDefs.Count; i++)
				{
					if (inputAsset.inputDefs[i].category.Equals(del.category)) { foundOne = true; break; }
				}

				if (!foundOne)
				{
					inputAsset.inputDefs.Insert(pos, new InputDefinition() { category = del.category });
				}

				EditorUtility.SetDirty(inputAsset);
				SortInputs(inputAsset);
			}

			if (delcat != null)
			{
				for (int i = inputAsset.inputDefs.Count - 1; i >= 0; i--)
				{
					if (inputAsset.inputDefs[i].category.Equals(delcat)) inputAsset.inputDefs.RemoveAt(i);
				}
				EditorUtility.SetDirty(inputAsset);
				SortInputs(inputAsset);
			}
		}

		private void OnInputWiz(object sender, object[] args)
		{
			InputSelectWiz wiz = (InputSelectWiz)sender;
			InputDefinition def = (InputDefinition)args[0];
			int bindIdx = (int)args[1];

			if (def != null)
			{
				if (bindIdx < def.binds.Length && bindIdx >= 0)
				{
					def.binds[bindIdx] = wiz.bind.Copy();
					EditorUtility.SetDirty(inputAsset);
				}
			}

			wiz.Close();
			ed.Repaint();
		}

		private void OnInputGroupName(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			int opt = (int)args[0];
			if (opt == 0)	// new
			{
				if (string.IsNullOrEmpty(s) || inputs.ContainsKey(s))
				{
					EditorUtility.DisplayDialog("Error!", "You need to enter a unique category name.", "Close");
					return;
				}
				inputAsset.inputDefs.Insert(0 ,new InputDefinition() { category = s });
			}
			//else			// rename
			//{
			//	string prev = (string)args[1];
			//	if (prev == s) return; // did not actually rename
			//	if (string.IsNullOrEmpty(s) || inputs.ContainsKey(s))
			//	{
			//		EditorUtility.DisplayDialog("Error!", "You need to enter a unique category name.", "Close");
			//		return;
			//	}

			//	for (int i = 0; i < inputAsset.inputDefs.Count; i++)
			//	{
			//		if (inputAsset.inputDefs[i].category == prev)
			//		{
			//			inputAsset.inputDefs[i].category = s;
			//		}
			//	}
			//}

			plyEdGUI.ClearFocus();
			EditorUtility.SetDirty(inputAsset);
			SortInputs(inputAsset);
			ed.Repaint();
		}

		private void OnInputDefName(object sender, object[] args)
		{
			int opt = (int)args[0];
			string cat = (string)args[1];
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (opt == 0)	// new
			{
				bool error = string.IsNullOrEmpty(s);
				if (false == error)
				{
					for (int i = 0; i < inputAsset.inputDefs.Count; i++)
					{
						if (string.IsNullOrEmpty(inputAsset.inputDefs[i].name)) continue;
						if (inputAsset.inputDefs[i].category.Equals(cat) && inputAsset.inputDefs[i].name.Equals(s))
						{
							error = true;
							break;
						}
					}
				}

				if (error)
				{
					EditorUtility.DisplayDialog("Error!", "You need to enter a unique name.", "Close");
					return;
				}

				InputDefinition ni = new InputDefinition() { category = cat, name = s };
				int prev = -1; bool added = false;
				for (int i = 0; i < inputAsset.inputDefs.Count; i++)
				{
					if (inputAsset.inputDefs[i].category == cat)
					{
						prev = i;
					}
					else if (prev != -1)
					{
						added = true;
						inputAsset.inputDefs.Insert(i, ni);
						break;
					}
				}
				if (!added) inputAsset.inputDefs.Add(ni);

				// remove any empty defines of category as empty is no longer needed (empty was needed so that group can be presented in editor)
				for (int i = inputAsset.inputDefs.Count - 1; i >= 0; i--)
				{
					if (inputAsset.inputDefs[i].category.Equals(cat))
					{
						if (string.IsNullOrEmpty(inputAsset.inputDefs[i].name)) inputAsset.inputDefs.RemoveAt(i);
					}
				}
			}

			plyEdGUI.ClearFocus();
			EditorUtility.SetDirty(inputAsset);
			SortInputs(inputAsset);
			ed.Repaint();
		}

		//private void InputDefs()
		//{
		//	InputDefinition del = null;

		//	EditorGUILayout.BeginVertical();
		//	{
		//		EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
		//		{
		//			if (GUILayout.Button(GC_AddInputGroup, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(130)))
		//			{
		//				plyTextInputWiz.ShowWiz("Create Group", "Enter unique input group name", "", OnInputGroupName, new object[] { 0 });
		//			}
		//			if (GUILayout.Button(GC_ResetInput, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(140)))
		//			{
		//				if (EditorUtility.DisplayDialog("Warning", "All your current input defines will be lost. This can't be undone.", "Continue", "Cancel"))
		//				{
		//					DefineDefaultInputBinds(inputAsset);
		//				}
		//			}
		//			if (GUILayout.Button(GC_SetupInput, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(160)))
		//			{
		//				SetupInputManager();
		//			}
		//			EditorGUILayout.Space();
		//			if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.ToolbarIconButtonStyle))
		//			{
		//				Application.OpenURL(EdGlobal.HLP_InputManager);
		//			}
		//			GUILayout.FlexibleSpace();
		//		}
		//		EditorGUILayout.EndHorizontal();
		//		EditorGUILayout.Space();

		//		EditorGUILayout.Space();
		//		EditorGUILayout.BeginHorizontal();
		//		{
		//			GUILayout.Label(" ", EditorStyles.boldLabel, GUILayout.Width(165));
		//			GUILayout.Label("Primary Button(s)", EditorStyles.boldLabel, GUILayout.Width(245));
		//			GUILayout.Label("Alternate Button(s)", EditorStyles.boldLabel, GUILayout.Width(200));
		//			GUILayout.FlexibleSpace();
		//		}
		//		EditorGUILayout.EndHorizontal();
		//		EditorGUILayout.BeginHorizontal();
		//		{
		//			GUILayout.Space(10);
		//			GUILayout.Label("Active", EditorStyles.boldLabel, GUILayout.Width(55));
		//			GUILayout.Label("Name", EditorStyles.boldLabel, GUILayout.Width(100));
		//			GUILayout.Label("Positive", EditorStyles.boldLabel, GUILayout.Width(120));
		//			GUILayout.Label("Negative/ Mod", EditorStyles.boldLabel, GUILayout.Width(120));
		//			GUILayout.Label("Positive", EditorStyles.boldLabel, GUILayout.Width(120));
		//			GUILayout.Label("Negative/ Mod", EditorStyles.boldLabel, GUILayout.Width(120));
		//			GUILayout.Label("Mouse", EditorStyles.boldLabel, GUILayout.Width(90));
		//			GUILayout.Label("Gamepad", EditorStyles.boldLabel, GUILayout.Width(90));
		//			GUILayout.Label("Axis", EditorStyles.boldLabel, GUILayout.Width(90));
		//			GUILayout.Label("Axis Mod", EditorStyles.boldLabel, GUILayout.Width(90));
		//			GUILayout.FlexibleSpace();
		//		}
		//		EditorGUILayout.EndHorizontal();
		//		plyEdGUI.DrawHorizontalLine(1, 0, plyEdGUI.DividerColor, plyEdGUI.HLineStyle);

		//		scroll[0] = EditorGUILayout.BeginScrollView(scroll[0]);
		//		{
		//			foreach (KeyValuePair<string, List<InputDefinition>> kv in inputAsset.inputs)
		//			{
		//				EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
		//				{
		//					GUILayout.Space(20);
		//					if (GUILayout.Button(GC_AddInput, plyEdGUI.ToolbarButtonStyle))
		//					{
		//						plyEdGUI.ClearFocus();

		//						// insert the new input after last 9one to use same category/ group 
		//						InputDefinition ni = new InputDefinition() { category = kv.Key };
		//						int prev = -1; bool added = false;
		//						for (int i = 0; i < inputAsset.inputDefs.Count; i++)
		//						{
		//							if (inputAsset.inputDefs[i].category == kv.Key)
		//							{
		//								prev = i;
		//							}
		//							else if (prev != -1)
		//							{
		//								added = true;
		//								inputAsset.inputDefs.Insert(i, ni);
		//								break;
		//							}
		//						}
		//						if (!added) inputAsset.inputDefs.Add(ni);
		//						EditorUtility.SetDirty(inputAsset);
		//						inputAsset.SortInputs();
		//					}
		//					//if (GUILayout.Button(GC_Rename_L, plyEdGUI.ToolbarButtonStyle))
		//					//{
		//					//	plyTextInputWiz.ShowWiz("Rename Group", "Enter unique input group name", kv.Key, OnInputGroupName, new object[] { 1, kv.Key });
		//					//}
		//					GUILayout.Space(15);
		//					GUILayout.Label(kv.Key, plyEdGUI.ToolbarHeadStyle);
		//					GUILayout.FlexibleSpace();
		//				}
		//				EditorGUILayout.EndHorizontal();
		//				EditorGUILayout.Space();

		//				foreach (InputDefinition def in kv.Value)
		//				{
		//					EditorGUILayout.BeginHorizontal();
		//					{
		//						GUILayout.Space(3);
		//						if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonStyle))
		//						{
		//							del = def;
		//						}
		//						GUILayout.Space(7);

		//						//plyEdGUI.LookLikeControls(30, 30);
		//						def.active = EditorGUILayout.Toggle(def.active, GUILayout.Width(25));
		//						GUI.enabled = def.active;

		//						EditorGUILayout.BeginVertical();
		//						{
		//							def.type = (InputDefinition.InputType)EditorGUILayout.EnumPopup(def.type, GUILayout.Width(100));
		//							def.name = EditorGUILayout.TextField(def.name, GUILayout.Width(100));
		//						}
		//						EditorGUILayout.EndVertical();

		//						plyEdGUI.LookLikeControls(70, 50);
		//						EditorGUILayout.BeginVertical();
		//						{
		//							//GUI.enabled = def.type == InputDefinition.InputType.Button && def.active;
		//							EditorGUILayout.BeginHorizontal();
		//							if (GUILayout.Button(def.key1 == KeyCode.None ? "-" : def.key1.ToString(), GUILayout.Width(120))) plyButtonSelectWiz.Show_Wiz(def.key1, OnInputButtonSelected, new object[] { 1, def });
		//							if (GUILayout.Button(def.key2 == KeyCode.None ? "-" : def.key2.ToString(), GUILayout.Width(120))) plyButtonSelectWiz.Show_Wiz(def.key2, OnInputButtonSelected, new object[] { 2, def });
		//							EditorGUILayout.EndHorizontal();
		//							def.screenName1 = EditorGUILayout.TextField("Name 1", def.screenName1);
		//						}
		//						EditorGUILayout.EndVertical();
		//						EditorGUILayout.BeginVertical();
		//						{
		//							//GUI.enabled = def.type == InputDefinition.InputType.Button && def.active;
		//							EditorGUILayout.BeginHorizontal();
		//							if (GUILayout.Button(def.key1Alt == KeyCode.None ? "-" : def.key1Alt.ToString(), GUILayout.Width(120))) plyButtonSelectWiz.Show_Wiz(def.key1Alt, OnInputButtonSelected, new object[] { 3, def });
		//							if (GUILayout.Button(def.key2Alt == KeyCode.None ? "-" : def.key2Alt.ToString(), GUILayout.Width(120))) plyButtonSelectWiz.Show_Wiz(def.key2Alt, OnInputButtonSelected, new object[] { 4, def });
		//							EditorGUILayout.EndHorizontal();
		//							def.screenName2 = EditorGUILayout.TextField("Name 2", def.screenName2);
		//						}
		//						EditorGUILayout.EndVertical();

		//						EditorGUILayout.BeginVertical();
		//						{
		//							def.mouseAxis = (InputDefinition.MouseAxis)EditorGUILayout.EnumPopup(def.mouseAxis, GUILayout.Width(90));
		//							GUI.enabled = (def.mouseAxis != InputDefinition.MouseAxis.None && def.active);
		//							if (def.type == InputDefinition.InputType.Axis)
		//							{
		//								plyEdGUI.LookLikeControls(70, 15);
		//								def.mouseInvert = EditorGUILayout.Toggle("Invert Axis", def.mouseInvert);
		//							}
		//							else def.mouseAxisSide = (InputDefinition.AxisSide)EditorGUILayout.EnumPopup(def.mouseAxisSide, GUILayout.Width(90));
		//							GUI.enabled = def.active;
		//						}
		//						EditorGUILayout.EndVertical();
		//						EditorGUILayout.BeginVertical();
		//						{
		//							def.gamepad = (InputDefinition.Gamepad)EditorGUILayout.EnumPopup(def.gamepad, GUILayout.Width(90));
		//							GUI.enabled = (def.gamepad != InputDefinition.Gamepad.None && def.active);
		//						}
		//						EditorGUILayout.EndVertical();
		//						EditorGUILayout.BeginVertical();
		//						{
		//							def.gamepadAxis = (InputDefinition.GamepadAxis)EditorGUILayout.EnumPopup(def.gamepadAxis, GUILayout.Width(90));
		//							GUI.enabled = (def.gamepadAxis != InputDefinition.GamepadAxis.None && def.active);
		//							if (def.type == InputDefinition.InputType.Axis)
		//							{
		//								plyEdGUI.LookLikeControls(70, 15);
		//								def.gamepadInvert = EditorGUILayout.Toggle("Invert Axis", def.gamepadInvert);
		//							}
		//							else def.gamepadAxisSide = (InputDefinition.AxisSide)EditorGUILayout.EnumPopup(def.gamepadAxisSide, GUILayout.Width(90));
		//							GUI.enabled = (def.gamepad != InputDefinition.Gamepad.None && def.active);
		//						}
		//						EditorGUILayout.EndVertical();
		//						if (def.type == InputDefinition.InputType.Button)
		//						{
		//							EditorGUILayout.BeginVertical();
		//							{
		//								def.gamepadAxisMod = (InputDefinition.GamepadAxis)EditorGUILayout.EnumPopup(def.gamepadAxisMod, GUILayout.Width(90));
		//								GUI.enabled = (def.gamepadAxisMod != InputDefinition.GamepadAxis.None && def.active);
		//								def.gamepadAxisModSide = (InputDefinition.AxisSide)EditorGUILayout.EnumPopup(def.gamepadAxisModSide, GUILayout.Width(90));
		//							}
		//							EditorGUILayout.EndVertical();
		//							GUI.enabled = def.active;
		//						}

		//						GUI.enabled = true;
		//						GUILayout.FlexibleSpace();
		//					}
		//					EditorGUILayout.EndHorizontal();
		//					GUILayout.Space(3);
		//				}
		//				EditorGUILayout.Space();
		//			}

		//			EditorGUILayout.Space();
		//		}
		//		EditorGUILayout.EndScrollView();
		//	}
		//	EditorGUILayout.EndVertical();

		//	if (GUI.changed)
		//	{
		//		GUI.changed = false;
		//		EditorUtility.SetDirty(inputAsset);
		//	}

		//	if (del != null)
		//	{
		//		inputAsset.inputDefs.Remove(del);
		//		EditorUtility.SetDirty(inputAsset);
		//		inputAsset.SortInputs();
		//	}
		//}

		//private void OnInputButtonSelected(object sender, object[] args)
		//{
		//	int opt = (int)args[0];
		//	InputDefinition def = (InputDefinition)args[1];

		//	plyButtonSelectWiz wiz = sender as plyButtonSelectWiz;
		//	KeyCode k = wiz.key;
		//	wiz.Close();

		//	switch (opt)
		//	{
		//		case 1: def.key1 = k; break;
		//		case 2: def.key2 = k; break;
		//		case 3: def.key1Alt = k; break;
		//		case 4: def.key2Alt = k; break;
		//	}

		//	EditorUtility.SetDirty(inputAsset);
		//	ed.Repaint();
		//}
		
		#endregion
		// ============================================================================================================
		#region LoadSave Provider

		private void LoadSave()
		{
			EditorGUILayout.BeginVertical();
			{
				EditorGUILayout.Space();
				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.SectionHeading("Loading & Saving", false);
					EditorGUILayout.Space();
					if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
					{
						Application.OpenURL(EdGlobal.HLP_LoadSaveEd);
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				plyEdGUI.HLine(5);

				EditorGUIUtility.labelWidth = 150;
				EditorGUI.BeginChangeCheck();
				currLoadSaveIdx = EditorGUILayout.Popup("LoadSave Provider", currLoadSaveIdx, loadSaveProviderNames, GUILayout.Width(450));
				if (EditorGUI.EndChangeCheck())
				{
					CreateProvider(EdGlobal.loadSaveEditors[currLoadSaveIdx]);
				}

				if (currLoadSaveIdx >= 0 && lsProvider != null)
				{
					if (plyEdGUI.LabelButton(" ", "Delete All Saves", (int)EditorGUIUtility.labelWidth - 5, (int)(450 - EditorGUIUtility.labelWidth)))
					{
						lsProvider.DeleteAll();
					}
					plyEdGUI.HLine(10);

					EditorGUIUtility.labelWidth = 0;
					EditorGUILayout.BeginVertical(GUILayout.Width(450));
					EdGlobal.loadSaveEditors[currLoadSaveIdx].editor.OnGUI(ed, lsProvider);
					EditorGUILayout.EndVertical();
				}
			}
			EditorGUILayout.EndVertical();
		}

		private void CreateProvider(LoadSaveEdInfo providerInfo)
		{
			// first delete the old provider prefab
			if (plyEdUtil.RelativeFileExist(plyEdUtil.DATA_PATH_SYSTEM + "loadsave.prefab"))
			{
				AssetDatabase.DeleteAsset(plyEdUtil.DATA_PATH_SYSTEM + "loadsave.prefab");
				AssetDatabase.Refresh();
			}

			// now create new prefab with correct component on it
			GameObject prefab = plyEdUtil.CreatePrefab(providerInfo.providerType, "loadsave", plyEdUtil.DATA_PATH_SYSTEM + "loadsave.prefab");
			AssetDatabase.Refresh();
			dataAsset.loadSaveProviderFab = prefab;
			EditorUtility.SetDirty(dataAsset);
			AssetDatabase.SaveAssets();

			lsProvider = prefab.GetComponent<LoadSaveProviderBase>();
		}

		public static void CreateDefaultLoadSaveProvider(DataAsset dataAsset)
		{
			if (dataAsset.loadSaveProviderFab != null) return;

			// first delete the old provider prefab
			if (plyEdUtil.RelativeFileExist(plyEdUtil.DATA_PATH_SYSTEM + "loadsave.prefab"))
			{
				AssetDatabase.DeleteAsset(plyEdUtil.DATA_PATH_SYSTEM + "loadsave.prefab");
				AssetDatabase.Refresh();
			}

			// now create new prefab with correct component on it
			GameObject prefab = plyEdUtil.CreatePrefab<LoadSave_PlayerPrefs>("loadsave", plyEdUtil.DATA_PATH_SYSTEM + "loadsave.prefab");
			AssetDatabase.Refresh();
			dataAsset.loadSaveProviderFab = prefab;
			EditorUtility.SetDirty(dataAsset);
			AssetDatabase.SaveAssets();
		}

		#endregion
		// ============================================================================================================
		#region Sound Settings

		private void SoundSettings()
		{
			EditorGUILayout.BeginVertical();
			{
				EditorGUILayout.Space();
				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.SectionHeading("Sound Settings", false);
					EditorGUILayout.Space();
					if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
					{
						Application.OpenURL(EdGlobal.HLP_SoundSettings);
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				plyEdGUI.HLine(5);

				EditorGUI.BeginChangeCheck();
				EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
				{
					GUILayout.Label("Initial Volume", plyEdGUI.LargeBoldLabelStyle);
					EditorGUIUtility.labelWidth = 80;
					EditorGUI.indentLevel++;
					for (int i = 0; i < 10; i++)
					{
						dataAsset.volume[i] = EditorGUILayout.Slider(((GameGlobal.VolumeType)i).ToString(), dataAsset.volume[i], 0f, 1f);
					}
					EditorGUI.indentLevel--;

					EditorGUILayout.Space();
					GUILayout.Label("Settings", plyEdGUI.LargeBoldLabelStyle);
					EditorGUIUtility.labelWidth = 190;
					EditorGUI.indentLevel++;
					dataAsset.guiVolumeType = (GameGlobal.VolumeType)EditorGUILayout.EnumPopup("Screens Sound Volume Type", dataAsset.guiVolumeType);
					dataAsset.createDefaultAudioListener = EditorGUILayout.Toggle("Auto-create Audio Listener", dataAsset.createDefaultAudioListener);
					EditorGUI.indentLevel--;
				}
				EditorGUILayout.EndVertical();
				if (EditorGUI.EndChangeCheck()) EditorUtility.SetDirty(dataAsset);
			}
			EditorGUILayout.EndVertical();
		}

		#endregion
		// ============================================================================================================
		#region Auto instantiate objects

		private void AutoObjects()
		{
			EditorGUILayout.BeginVertical();
			{
				EditorGUILayout.Space();
				EditorGUILayout.BeginHorizontal();
				{
					plyEdGUI.SectionHeading("Auto Instantiate", false);
					EditorGUILayout.Space();
					if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.FlatIconButtonStyle))
					{
						Application.OpenURL(EdGlobal.HLP_AutoObjects);
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				plyEdGUI.HLine(5);

				EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
				{
					EditorGUILayout.HelpBox("You can add prefabs here that will be auto instantiated by plyGame when the game is started. The objects will be set to not auto destroy when a scene is loaded.", MessageType.Info);

					int res = plyEdGUI.SimpleItemList<GameObject>(ref selectedAutoFab, dataAsset.autoFabs, "Auto Fabs", AutoObjectsDraw);
					if (res == 2)
					{
						dataAsset.autoFabs.Add(null);
						EditorUtility.SetDirty(dataAsset);
					}
					else if (res >= 10)
					{
						res -= 10;
						dataAsset.autoFabs.RemoveAt(res);
						EditorUtility.SetDirty(dataAsset);
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndVertical();
		}

		private void AutoObjectsDraw(object sender, object[] args)
		{
			int i = (int)args[0];
			EditorGUI.BeginChangeCheck();
			dataAsset.autoFabs[i] = (GameObject)EditorGUILayout.ObjectField(dataAsset.autoFabs[i], typeof(GameObject), false);
			if (EditorGUI.EndChangeCheck()) EditorUtility.SetDirty(dataAsset);
		}

		#endregion
		// ============================================================================================================
		#region Misc

		private void Misc()
		{
			EditorGUILayout.BeginVertical();
			{
				//EditorGUILayout.Space();
				//plyEdGUI.SectionHeading("Graphics Quality", true);
				//EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
				//{
				//	EditorGUILayout.HelpBox("You need to update this list with the names of graphics quality levels that are defined. See menu: Edit > Project Settings > Quality.", MessageType.Info);

				//}
				//EditorGUILayout.EndVertical();
				EditorGUILayout.Space();
				GUILayout.Label("-nothing here-");
			}
			EditorGUILayout.EndVertical();
		}

		#endregion
		// ============================================================================================================
		#region Input Manager Setup

		public enum AxisType
		{
			KeyOrMouseButton = 0,
			MouseMovement = 1,
			JoystickAxis = 2
		};

		public class InputAxis
		{
			public string name;
			public string descriptiveName;
			public string descriptiveNegativeName;
			public string negativeButton;
			public string positiveButton;
			public string altNegativeButton;
			public string altPositiveButton;

			public float gravity;
			public float dead;
			public float sensitivity;

			public bool snap = false;
			public bool invert = false;

			public AxisType type;

			public int axis;
			public int joyNum;
		}

		public static void SetupInputManager()
		{
			// Remove All
			//SerializedObject serializedObject = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/InputManager.asset")[0]);
			//SerializedProperty axesProperty = serializedObject.FindProperty("m_Axes");
			//axesProperty.ClearArray();
			//serializedObject.ApplyModifiedProperties();

			// Add the plyGame specific mouse definitions
			AddAxis(new InputAxis() { name = "plyMouseX",		sensitivity = 1f, type = AxisType.MouseMovement, axis = 1 });
			AddAxis(new InputAxis() { name = "plyMouseY",		sensitivity = 1f, type = AxisType.MouseMovement, axis = 2 });
			AddAxis(new InputAxis() { name = "plyScrollWheel", sensitivity = 1f, type = AxisType.MouseMovement, axis = 3 });

			// Add the plyGame specific gamepad definitions
			int i = 1;
			//for (int i = 1; i <= (int)InputBind.Gamepad.Gamepad4; i++)
			//{
				for (int j = 0; j <= (int)InputBind.GamepadAxis.Axis10; j++)
				{
					AddAxis(new InputAxis() 
					{ 
						name = "plyPad" + i + "A" + (j + 1).ToString(), 
						dead = 0.2f,
						sensitivity = 1f,
						type = AxisType.JoystickAxis,
						axis = (j + 1),
						joyNum = (i - 1), // force "motion from all joysticks"
					});
				}
			//}

		}

		private static void AddAxis(InputAxis axis)
		{
			if (AxisDefined(axis.name)) return;

			SerializedObject serializedObject = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/InputManager.asset")[0]);
			SerializedProperty axesProperty = serializedObject.FindProperty("m_Axes");

			axesProperty.arraySize++;
			serializedObject.ApplyModifiedProperties();

			SerializedProperty axisProperty = axesProperty.GetArrayElementAtIndex(axesProperty.arraySize - 1);

			GetChildProperty(axisProperty, "m_Name").stringValue = axis.name;
			GetChildProperty(axisProperty, "descriptiveName").stringValue = axis.descriptiveName;
			GetChildProperty(axisProperty, "descriptiveNegativeName").stringValue = axis.descriptiveNegativeName;
			GetChildProperty(axisProperty, "negativeButton").stringValue = axis.negativeButton;
			GetChildProperty(axisProperty, "positiveButton").stringValue = axis.positiveButton;
			GetChildProperty(axisProperty, "altNegativeButton").stringValue = axis.altNegativeButton;
			GetChildProperty(axisProperty, "altPositiveButton").stringValue = axis.altPositiveButton;
			GetChildProperty(axisProperty, "gravity").floatValue = axis.gravity;
			GetChildProperty(axisProperty, "dead").floatValue = axis.dead;
			GetChildProperty(axisProperty, "sensitivity").floatValue = axis.sensitivity;
			GetChildProperty(axisProperty, "snap").boolValue = axis.snap;
			GetChildProperty(axisProperty, "invert").boolValue = axis.invert;
			GetChildProperty(axisProperty, "type").intValue = (int)axis.type;
			GetChildProperty(axisProperty, "axis").intValue = axis.axis - 1;
			GetChildProperty(axisProperty, "joyNum").intValue = axis.joyNum;

			serializedObject.ApplyModifiedProperties();
		}

		private static bool AxisDefined(string axisName)
		{
			SerializedObject serializedObject = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/InputManager.asset")[0]);
			SerializedProperty axesProperty = serializedObject.FindProperty("m_Axes");

			axesProperty.Next(true);
			axesProperty.Next(true);
			while (axesProperty.Next(false))
			{
				SerializedProperty axis = axesProperty.Copy();
				axis.Next(true);
				if (axis.stringValue == axisName) return true;
			}
			return false;
		}

		private static SerializedProperty GetChildProperty(SerializedProperty parent, string name)
		{
			SerializedProperty child = parent.Copy();
			child.Next(true);
			do
			{
				if (child.name == name) return child;
			}
			while (child.Next(false));
			return null;
		}

		#endregion
		// ============================================================================================================
	}
}
