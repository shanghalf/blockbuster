﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

namespace plyGameEditor
{
	public class PreviewResolutions
	{
		public enum SizeGroupType
		{
			Standalone,
			WebPlayer,
			iOS,
			Android,
			WP8,
			BB10,
			//Wii,
			//PS3,
			//Xbox360
		}

		public enum GameViewSizeType 
		{ 
			AspectRatio, 
			FixedResolution 
		}

		public class GameViewSize
		{
			public string name;
			public GameViewSizeType sizeType;
			public int w;
			public int h;

			public GameViewSize(GameViewSizeType sizeType, int w, int h, string name)
			{
				this.sizeType = sizeType;
				this.w = w;
				this.h = h;
				this.name = name;
			}

			public bool isFreeAspectRatio { get { return this.w == 0; } }

			public float aspectRatio { get { if (this.h == 0) return 0f; return (float)this.w / (float)this.h; } }
		}

		public class GameViewSizeGroup
		{
			public GameViewSize[] viewSizes;
			public string[] viewSizeNames;

			public void Add(GameViewSize[] sizes)
			{
				viewSizes = sizes;
				viewSizeNames = new string[viewSizes.Length];
				for (int i = 0; i < viewSizes.Length; i++)
				{
					if (string.IsNullOrEmpty(viewSizes[i].name))
					{
						viewSizeNames[i] = viewSizes[i].w + (viewSizes[i].sizeType == GameViewSizeType.FixedResolution ? " x " : " : ") + viewSizes[i].h;
					}
					else
					{
						viewSizeNames[i] = viewSizes[i].name;
						if (viewSizes[i].w != 0 && viewSizes[i].h != 0)
						{
							viewSizeNames[i] += " (" + viewSizes[i].w + (viewSizes[i].sizeType == GameViewSizeType.FixedResolution ? "x" : ":") + viewSizes[i].h + ")";
						}
					}
				}
			}
		}

		private GameViewSizeGroup m_Standalone = new GameViewSizeGroup();
		private GameViewSizeGroup m_WebPlayer = new GameViewSizeGroup();
		private GameViewSizeGroup m_iOS = new GameViewSizeGroup();
		private GameViewSizeGroup m_Android = new GameViewSizeGroup();
		private GameViewSizeGroup m_BB10 = new GameViewSizeGroup();
		private GameViewSizeGroup m_WP8 = new GameViewSizeGroup(); 
		//private GameViewSizeGroup m_XBox360 = new GameViewSizeGroup();
		//private GameViewSizeGroup m_PS3 = new GameViewSizeGroup();
		//private GameViewSizeGroup m_Wii = new GameViewSizeGroup();

		public Dictionary<SizeGroupType, GameViewSizeGroup> viewSizeGroups = new Dictionary<SizeGroupType, GameViewSizeGroup>();

		public PreviewResolutions()
		{
			GameViewSize gameViewSize1 = new GameViewSize(GameViewSizeType.AspectRatio, 0, 0, "Free Aspect");
			GameViewSize gameViewSize2 = new GameViewSize(GameViewSizeType.AspectRatio, 5, 4, string.Empty);
			GameViewSize gameViewSize3 = new GameViewSize(GameViewSizeType.AspectRatio, 4, 3, string.Empty);
			GameViewSize gameViewSize4 = new GameViewSize(GameViewSizeType.AspectRatio, 3, 2, string.Empty);
			GameViewSize gameViewSize5 = new GameViewSize(GameViewSizeType.AspectRatio, 16, 10, string.Empty);
			GameViewSize gameViewSize6 = new GameViewSize(GameViewSizeType.AspectRatio, 16, 9, string.Empty);
			GameViewSize gameViewSize7 = new GameViewSize(GameViewSizeType.FixedResolution, 1024, 768, "Standalone");
			GameViewSize gameViewSize8 = new GameViewSize(GameViewSizeType.FixedResolution, 960, 600, "Web");
			GameViewSize gameViewSize9 = new GameViewSize(GameViewSizeType.FixedResolution, 320, 480, "iPhone Tall");
			GameViewSize gameViewSize10 = new GameViewSize(GameViewSizeType.FixedResolution, 480, 320, "iPhone Wide");
			GameViewSize gameViewSize11 = new GameViewSize(GameViewSizeType.FixedResolution, 640, 960, "iPhone 4G Tall");
			GameViewSize gameViewSize12 = new GameViewSize(GameViewSizeType.FixedResolution, 960, 640, "iPhone 4G Wide");
			GameViewSize gameViewSize13 = new GameViewSize(GameViewSizeType.FixedResolution, 768, 1024, "iPad Tall");
			GameViewSize gameViewSize14 = new GameViewSize(GameViewSizeType.FixedResolution, 1024, 768, "iPad Wide");
			GameViewSize gameViewSize15 = new GameViewSize(GameViewSizeType.AspectRatio, 9, 16, "iPhone 5 Tall");
			GameViewSize gameViewSize16 = new GameViewSize(GameViewSizeType.AspectRatio, 16, 9, "iPhone 5 Wide");
			GameViewSize gameViewSize17 = new GameViewSize(GameViewSizeType.AspectRatio, 2, 3, "iPhone Tall");
			GameViewSize gameViewSize18 = new GameViewSize(GameViewSizeType.AspectRatio, 3, 2, "iPhone Wide");
			GameViewSize gameViewSize19 = new GameViewSize(GameViewSizeType.AspectRatio, 3, 4, "iPad Tall");
			GameViewSize gameViewSize20 = new GameViewSize(GameViewSizeType.AspectRatio, 4, 3, "iPad Wide");
			GameViewSize gameViewSize21 = new GameViewSize(GameViewSizeType.FixedResolution, 320, 480, "HVGA Portrait");
			GameViewSize gameViewSize22 = new GameViewSize(GameViewSizeType.FixedResolution, 480, 320, "HVGA Landscape");
			GameViewSize gameViewSize23 = new GameViewSize(GameViewSizeType.FixedResolution, 480, 800, "WVGA Portrait");
			GameViewSize gameViewSize24 = new GameViewSize(GameViewSizeType.FixedResolution, 800, 480, "WVGA Landscape");
			GameViewSize gameViewSize25 = new GameViewSize(GameViewSizeType.FixedResolution, 480, 854, "FWVGA Portrait");
			GameViewSize gameViewSize26 = new GameViewSize(GameViewSizeType.FixedResolution, 854, 480, "FWVGA Landscape");
			GameViewSize gameViewSize27 = new GameViewSize(GameViewSizeType.FixedResolution, 600, 1024, "WSVGA Portrait");
			GameViewSize gameViewSize28 = new GameViewSize(GameViewSizeType.FixedResolution, 1024, 600, "WSVGA Landscape");
			GameViewSize gameViewSize29 = new GameViewSize(GameViewSizeType.FixedResolution, 800, 1280, "WXGA Portrait");
			GameViewSize gameViewSize30 = new GameViewSize(GameViewSizeType.FixedResolution, 1280, 800, "WXGA Landscape");
			GameViewSize gameViewSize31 = new GameViewSize(GameViewSizeType.AspectRatio, 2, 3, "Portrait");
			GameViewSize gameViewSize32 = new GameViewSize(GameViewSizeType.AspectRatio, 3, 2, "Landscape");
			GameViewSize gameViewSize33 = new GameViewSize(GameViewSizeType.AspectRatio, 10, 16, "Portrait");
			GameViewSize gameViewSize34 = new GameViewSize(GameViewSizeType.AspectRatio, 16, 10, "Landscape");
			//GameViewSize gameViewSize35 = new GameViewSize(GameViewSizeType.FixedResolution, 1280, 720, "720p (16:9)");
			//GameViewSize gameViewSize36 = new GameViewSize(GameViewSizeType.FixedResolution, 1920, 1080, "1080p (16:9)");
			//GameViewSize gameViewSize37 = new GameViewSize(GameViewSizeType.FixedResolution, 1280, 720, "720p (16:9)");
			//GameViewSize gameViewSize38 = new GameViewSize(GameViewSizeType.FixedResolution, 720, 576, "576p (4:3)");
			//GameViewSize gameViewSize39 = new GameViewSize(GameViewSizeType.FixedResolution, 1024, 576, "576p (16:9)");
			//GameViewSize gameViewSize40 = new GameViewSize(GameViewSizeType.FixedResolution, 640, 480, "480p (4:3)");
			//GameViewSize gameViewSize41 = new GameViewSize(GameViewSizeType.FixedResolution, 853, 480, "480p (16:9)");
			//GameViewSize gameViewSize42 = new GameViewSize(GameViewSizeType.FixedResolution, 608, 456, "Wii 4:3");
			//GameViewSize gameViewSize43 = new GameViewSize(GameViewSizeType.FixedResolution, 832, 456, "Wii 16:9");
			GameViewSize gameViewSize44 = new GameViewSize(GameViewSizeType.FixedResolution, 720, 1280, "Touch Phone Portrait");
			GameViewSize gameViewSize45 = new GameViewSize(GameViewSizeType.FixedResolution, 1280, 720, "Touch Phone Landscape");
			GameViewSize gameViewSize46 = new GameViewSize(GameViewSizeType.FixedResolution, 720, 720, "Keyboard Phone");
			GameViewSize gameViewSize47 = new GameViewSize(GameViewSizeType.FixedResolution, 600, 1024, "Playbook Portrait");
			GameViewSize gameViewSize48 = new GameViewSize(GameViewSizeType.FixedResolution, 1024, 600, "Playbook Landscape");
			GameViewSize gameViewSize49 = new GameViewSize(GameViewSizeType.AspectRatio, 9, 16, "Portrait");
			GameViewSize gameViewSize50 = new GameViewSize(GameViewSizeType.AspectRatio, 16, 9, "Landscape");
			GameViewSize gameViewSize51 = new GameViewSize(GameViewSizeType.AspectRatio, 1, 1, string.Empty);
			GameViewSize gameViewSize52 = new GameViewSize(GameViewSizeType.FixedResolution, 480, 800, "WVGA Portrait");
			GameViewSize gameViewSize53 = new GameViewSize(GameViewSizeType.FixedResolution, 800, 480, "WVGA Landscape");
			GameViewSize gameViewSize54 = new GameViewSize(GameViewSizeType.FixedResolution, 768, 1280, "WXGA Portrait");
			GameViewSize gameViewSize55 = new GameViewSize(GameViewSizeType.FixedResolution, 1280, 768, "WXGA Landscape");
			GameViewSize gameViewSize56 = new GameViewSize(GameViewSizeType.FixedResolution, 720, 1280, "720p Portrait");
			GameViewSize gameViewSize57 = new GameViewSize(GameViewSizeType.FixedResolution, 1280, 720, "720p Landscape");
			GameViewSize gameViewSize58 = new GameViewSize(GameViewSizeType.AspectRatio, 9, 15, "WVGA Portrait");
			GameViewSize gameViewSize59 = new GameViewSize(GameViewSizeType.AspectRatio, 15, 9, "WVGA Landscape");
			GameViewSize gameViewSize60 = new GameViewSize(GameViewSizeType.AspectRatio, 9, 15, "WXGA Portrait");
			GameViewSize gameViewSize61 = new GameViewSize(GameViewSizeType.AspectRatio, 15, 9, "WXGA Landscape");
			GameViewSize gameViewSize62 = new GameViewSize(GameViewSizeType.AspectRatio, 9, 16, "720p Portrait");
			GameViewSize gameViewSize63 = new GameViewSize(GameViewSizeType.AspectRatio, 16, 9, "720p Landscape");

			m_WP8.Add(new GameViewSize[]
			{
				gameViewSize1,
				gameViewSize52,
				gameViewSize58,
				gameViewSize53,
				gameViewSize59,
				gameViewSize54,
				gameViewSize60,
				gameViewSize55,
				gameViewSize61,
				gameViewSize56,
				gameViewSize62,
				gameViewSize57,
				gameViewSize63
			});
			m_Standalone.Add(new GameViewSize[]
			{
				gameViewSize1,
				gameViewSize2,
				gameViewSize3,
				gameViewSize4,
				gameViewSize5,
				gameViewSize6,
				gameViewSize7
			});
			m_WebPlayer.Add(new GameViewSize[]
			{
				gameViewSize1,
				gameViewSize2,
				gameViewSize3,
				gameViewSize4,
				gameViewSize5,
				gameViewSize6,
				gameViewSize8
			});
			m_iOS.Add(new GameViewSize[]
			{
				gameViewSize1,
				gameViewSize9,
				gameViewSize10,
				gameViewSize11,
				gameViewSize12,
				gameViewSize13,
				gameViewSize14,
				gameViewSize15,
				gameViewSize16,
				gameViewSize17,
				gameViewSize18,
				gameViewSize19,
				gameViewSize20
			});
			m_Android.Add(new GameViewSize[]
			{
				gameViewSize1,
				gameViewSize21,
				gameViewSize22,
				gameViewSize23,
				gameViewSize24,
				gameViewSize25,
				gameViewSize26,
				gameViewSize27,
				gameViewSize28,
				gameViewSize29,
				gameViewSize30,
				gameViewSize31,
				gameViewSize32,
				gameViewSize33,
				gameViewSize34
			});
			m_BB10.Add(new GameViewSize[]
			{
				gameViewSize1,
				gameViewSize44,
				gameViewSize45,
				gameViewSize46,
				gameViewSize47,
				gameViewSize48,
				gameViewSize49,
				gameViewSize50,
				gameViewSize51
			});
			//m_Wii.Add(new GameViewSize[]
			//{
			//	gameViewSize1,
			//	gameViewSize3,
			//	gameViewSize6,
			//	gameViewSize42,
			//	gameViewSize43
			//});
			//m_PS3.Add(new GameViewSize[]
			//{
			//	gameViewSize1,
			//	gameViewSize3,
			//	gameViewSize6,
			//	gameViewSize5,
			//	gameViewSize36,
			//	gameViewSize37,
			//	gameViewSize38,
			//	gameViewSize39,
			//	gameViewSize40,
			//	gameViewSize41
			//});
			//m_XBox360.Add(new GameViewSize[]
			//{
			//	gameViewSize1,
			//	gameViewSize3,
			//	gameViewSize6,
			//	gameViewSize5,
			//	gameViewSize35
			//});

			viewSizeGroups.Add(SizeGroupType.Standalone, m_Standalone);
			viewSizeGroups.Add(SizeGroupType.WebPlayer, m_WebPlayer);
			viewSizeGroups.Add(SizeGroupType.iOS, m_iOS);
			viewSizeGroups.Add(SizeGroupType.Android, m_Android);
			viewSizeGroups.Add(SizeGroupType.WP8, m_WP8);
			viewSizeGroups.Add(SizeGroupType.BB10, m_BB10);
		}

		public Rect GetConstrainedRect(Rect rect, GameViewSize vs)
		{
			if (vs.isFreeAspectRatio) return rect;
			Rect result = rect;

			float num = 0f;
			GameViewSizeType sizeType = vs.sizeType;
			bool flag;
			if (sizeType != GameViewSizeType.AspectRatio)
			{
				if (sizeType != GameViewSizeType.FixedResolution)
				{
					Debug.LogError("Unhandled enum");
					return rect;
				}
				if ((float)vs.h > rect.height || (float)vs.w > rect.width)
				{
					num = vs.aspectRatio;
					flag = true;
				}
				else
				{
					result.height = (float)vs.h;
					result.width = (float)vs.w;
					flag = false;
				}
			}
			else
			{
				num = vs.aspectRatio;
				flag = true;
			}
			if (flag)
			{
				result.height = ((result.width / num <= rect.height) ? (result.width / num) : rect.height);
				result.width = result.height * num;
			}
			result.height = Mathf.Clamp(result.height, 0f, rect.height);
			result.width = Mathf.Clamp(result.width, 0f, rect.width);
			result.y = rect.height * 0.5f - result.height * 0.5f + rect.y;
			result.x = rect.width * 0.5f - result.width * 0.5f + rect.x;
			return result;
		}

		// ============================================================================================================

	}
}
