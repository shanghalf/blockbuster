﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyBloxKitEditor;

namespace plyGameEditor
{
	public class OnGUIElementsEditor
	{
		// ============================================================================================================
		#region vars

		private EditorWindow ed = null;
		private GUIScreen screenData = null;
		private ScriptableObject asset = null;
		private GameObject bloxGameObject = null;

		private OnGUIElement curr = null;

		private static PreviewResolutions previewRes = new PreviewResolutions();
		private static PreviewResolutions.SizeGroupType selectedPreviewGroup = PreviewResolutions.SizeGroupType.Standalone;
		private static int selectedPreviewSize = 0;
		private bool showFrames = true;
		private GUISkin skin;

		private Rect mainRect = new Rect();
		private Rect _allRect;
		private Rect _barRect;

		private GUIContent GC_FrameButton;
		private GUIContent GC_AddLabel;
		private GUIContent GC_AddButton;
		private GUIContent GC_AddEdit;
		private GUIContent GC_AddCheck;
		private GUIContent GC_AddImage;
		private GUIContent GC_AddMovie;
		private GUIContent GC_AddBox;
		private GUIContent GC_plyBlox;

		private Texture2D Icon_MovieTexture;
		private Texture2D Icon_Font;
		private Texture2D Icon_Texture;

		private GUIStyle BlockFrameStyle;
		private GUIStyle BlockFrameSelStyle;

		private GUIStyle textPreviewStyle = new GUIStyle() { wordWrap = true, clipping = TextClipping.Clip };

		private int drag = -1; // 0:moving, else scaling -> 1:left, 2: right, 3:top, 4:bottom
		private int[] dragUndoCheck = { 0, 0, 0, 0 };

		#endregion
		// ============================================================================================================
		#region Draw Properties of selected element

		public void SetElementList(GUIScreen screenData)
		{
			if (this.screenData == screenData) return;
			this.bloxGameObject = (GameObject)AssetDatabase.LoadAssetAtPath(plyEdUtil.DATA_PATH_SYSTEM + "ongui.prefab", typeof(GameObject));
			this.curr = null;
			this.screenData = screenData;
			this.screenData.SortElements();
		}

		public void DrawProperties(EditorWindow ed, GUIScreen screenData, ScriptableObject asset)
		{
			if (Application.isPlaying)
			{
				return;
			}

			this.ed = ed;
			this.screenData = screenData;
			this.asset = asset;

			DrawScreenProperties();

			if (curr != null)
			{
				DrawCommonProperties(curr);

				switch (curr.type)
				{
					case UIElementType.Label: DrawLabelProperties((OnGUILabel)curr); break;
					case UIElementType.Image: DrawImageProperties((OnGUIImage)curr); break;
					case UIElementType.Movie: DrawMovieProperties((OnGUIMovie)curr); break;
					case UIElementType.Button: DrawButtonProperties((OnGUIButton)curr); break;
					case UIElementType.Edit: DrawEditProperties((OnGUIEdit)curr); break;
					case UIElementType.Toggle: DrawToggleProperties((OnGUIToggle)curr); break;
				}
			}
			else
			{
				DrawElementsList();
			}
		}

		private void DrawScreenProperties()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Screen");
			plyEdGUI.LookLikeControls(60, 165);

			EditorGUI.BeginChangeCheck();
			screenData.skin = (GUISkin)EditorGUILayout.ObjectField("Skin", screenData.skin, typeof(GUISkin), false);
			if (EditorGUI.EndChangeCheck()) screenData.needGUICacheInit = true;

			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Clear background", GUILayout.Width(110));
				screenData.doClearBack = EditorGUILayout.Toggle(screenData.doClearBack, GUILayout.Width(25));
				GUI.enabled = screenData.doClearBack;
				screenData.backgroundColor = EditorGUILayout.ColorField(screenData.backgroundColor, GUILayout.Width(40));
				GUI.enabled = true;
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DrawElementsList()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("UI Elements");
			bool style2 = false;
			foreach (OnGUIElement b in screenData.uiElements)
			{
				style2 = !style2;
				if (GUILayout.Button(b.name)) SelectElement(b);
			}
		}

		private void DrawCommonProperties(OnGUIElement blk)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("UI Element");
			plyEdGUI.LookLikeControls(60, 165);
			blk.name = EditorGUILayout.TextField("Name", blk.name);
			plyEdGUI.LookLikeControls();
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.LabelField("Depth", GUILayout.Width(56));
				EditorGUILayout.LabelField(blk.zdepth.ToString(), EditorStyles.textField, GUILayout.Width(50));
				if (GUILayout.Button("<<", EditorStyles.miniButtonLeft, GUILayout.Width(25)))
				{
					blk.zdepth -= 5; if (blk.zdepth < 0) blk.zdepth = 0;
					screenData.SortElements(); ed.Repaint();
				}
				if (GUILayout.Button("<", EditorStyles.miniButtonMid, GUILayout.Width(25)))
				{
					blk.zdepth--; if (blk.zdepth < 0) blk.zdepth = 0;
					screenData.SortElements(); ed.Repaint();
				}
				if (GUILayout.Button(">", EditorStyles.miniButtonMid, GUILayout.Width(25)))
				{
					blk.zdepth++; if (blk.zdepth > 50) blk.zdepth = 50;
					screenData.SortElements(); ed.Repaint();
				}
				if (GUILayout.Button(">>", EditorStyles.miniButtonRight, GUILayout.Width(25)))
				{
					blk.zdepth += 5; if (blk.zdepth > 50) blk.zdepth = 50;
					screenData.SortElements(); ed.Repaint();
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.LookLikeControls(60, 165);
			blk.anchor = (UIAnchor)EditorGUILayout.EnumPopup("Anchor", blk.anchor);
			blk.scaling = (UIScale)EditorGUILayout.EnumPopup("Scale", blk.scaling);
			plyEdGUI.LookLikeControls();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Offset", GUILayout.Width(56));
				plyEdGUI.LookLikeControls(20, 30);
				blk.offsetX = EditorGUILayout.IntField("X", blk.offsetX);
				blk.offsetY = EditorGUILayout.IntField("Y", blk.offsetY);
				if (GUILayout.Button("r", EditorStyles.miniButtonRight, GUILayout.Width(20))) { blk.offsetX = 0; blk.offsetY = 0; }
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Size", GUILayout.Width(56));
				plyEdGUI.LookLikeControls(20, 30);
				blk.width = EditorGUILayout.IntField("W", blk.width);
				blk.height = EditorGUILayout.IntField("H", blk.height);
				if (GUILayout.Button("r", EditorStyles.miniButtonRight, GUILayout.Width(20))) { blk.width = 100; blk.height = 100; }
			}
			EditorGUILayout.EndHorizontal();
			plyEdGUI.LookLikeControls(60, 165);
			blk.styleName = EditorGUILayout.TextField("Style", blk.styleName);
			EditorGUILayout.BeginHorizontal();
			{
				blk.visible = GUILayout.Toggle(blk.visible, " Visible");
				GUILayout.Space(10);
				blk.enabled = GUILayout.Toggle(blk.enabled, " Enabled");
			}
			EditorGUILayout.EndHorizontal();
		}

		// ============================================================================================================

		private void DrawImageProperties(OnGUIImage currImg)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Image");
			plyEdGUI.LookLikeControls(60, 165);
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Texture", GUILayout.Width(60));
				currImg.texture = (Texture2D)EditorGUILayout.ObjectField(currImg.texture, typeof(Texture2D), false, GUILayout.Width(90));

				GUI.enabled = currImg.texture != null;
				if (GUILayout.Button("Snap Scale", EditorStyles.miniButtonRight, GUILayout.Width(70)))
				{
					currImg.width = currImg.texture.width;
					currImg.height = currImg.texture.height;
				}
				GUI.enabled = true;
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DrawLabelProperties(OnGUILabel currTxt)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Label");
			plyEdGUI.LookLikeControls(70, 155);

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Shadow", GUILayout.Width(50));
				currTxt.showShadow = EditorGUILayout.Toggle(currTxt.showShadow, GUILayout.Width(20));
				if (currTxt.showShadow)
				{
					currTxt.shadowColor = EditorGUILayout.ColorField(currTxt.shadowColor, GUILayout.Width(40));
					GUILayout.Label("X", GUILayout.Width(15));
					currTxt.shadowOffset.x = EditorGUILayout.FloatField(currTxt.shadowOffset.x, GUILayout.Width(30));
					GUILayout.Label("Y", GUILayout.Width(15));
					currTxt.shadowOffset.y = EditorGUILayout.FloatField(currTxt.shadowOffset.y, GUILayout.Width(30));
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Outline", GUILayout.Width(50));
				currTxt.showOutline = EditorGUILayout.Toggle(currTxt.showOutline, GUILayout.Width(20));
				if (currTxt.showOutline)
				{
					currTxt.outlineColor = EditorGUILayout.ColorField(currTxt.outlineColor, GUILayout.Width(40));
					GUILayout.Label("Thickness", GUILayout.Width(68));
					currTxt.outlineThickness = EditorGUILayout.FloatField(currTxt.outlineThickness, GUILayout.Width(30));
				}
			}
			EditorGUILayout.EndHorizontal();

			EditorGUILayout.Space();
			plyEdGUI.LookLikeControls();
			GUILayout.Label("Text");
			currTxt.text = EditorGUILayout.TextArea(currTxt.text, plyEdGUI.Skin.textArea);
		}

		private void DrawMovieProperties(OnGUIMovie currMov)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Movie");
			EditorGUILayout.BeginHorizontal();
			{
				MovieTexture mov = currMov.video as MovieTexture;
				if (mov != null) GUI.enabled = !mov.isPlaying;
				GUILayout.Label("Video", GUILayout.Width(60));

				EditorGUI.BeginChangeCheck();
				currMov.video = (MovieTexture)EditorGUILayout.ObjectField(currMov.video, typeof(MovieTexture), false, GUILayout.Width(90));
				if (EditorGUI.EndChangeCheck())
				{
					mov = currMov.video as MovieTexture;
					if (mov != null) currMov.soundClip = mov.audioClip;
					else currMov.soundClip = null;
					GUI.changed = true;
				}

				GUI.enabled = mov == null ? false : !mov.isPlaying;
				EditorGUILayout.BeginVertical();
				{
					if (GUILayout.Button("Snap Scale", EditorStyles.miniButtonRight, GUILayout.Width(70)))
					{
						currMov.width = mov.width;
						currMov.height = mov.height;
					}
					if (mov == null)
					{
						GUILayout.Button("Play", EditorStyles.miniButtonRight, GUILayout.Width(70));
					}
					else
					{
						GUI.enabled = true;
						if (GUILayout.Button(mov.isPlaying ? "Stop" : "Play", EditorStyles.miniButtonRight, GUILayout.Width(70)))
						{
							if (mov.isPlaying)
							{
								mov.Stop();
								plyEdUtil.StopAllAudioClips();
							}
							else
							{
								mov.Stop();
								plyEdUtil.StopAllAudioClips();

								mov.Play();
								plyEdUtil.PlayAudioClip(currMov.soundClip);
							}
						}
						GUI.enabled = !mov.isPlaying;
					}
				}
				EditorGUILayout.EndVertical();
				if (mov != null) GUI.enabled = !mov.isPlaying;
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(5);

			plyEdGUI.LookLikeControls(60, 165);
			currMov.soundClip = (AudioClip)EditorGUILayout.ObjectField("Audio", currMov.soundClip, typeof(AudioClip), false);
			GUI.enabled = true;
		}

		private void DrawButtonProperties(OnGUIButton currButton)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Button");
			plyEdGUI.LookLikeControls(60, 165);

			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("On Click", GUILayout.Width(60));
				currButton.eventName = EditorGUILayout.TextField(currButton.eventName, GUILayout.Width(105));
				if (GUILayout.Button(GC_plyBlox, EditorStyles.miniButtonRight, GUILayout.Width(55)))
				{
					Selection.activeGameObject = bloxGameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd();
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUIUtility.labelWidth = 64;
			currButton.eventParam1 = EditorGUILayout.TextField("param1", currButton.eventParam1);

			EditorGUILayout.Space();
			currButton.soundClip = (AudioClip)EditorGUILayout.ObjectField("Sound", currButton.soundClip, typeof(AudioClip), false);
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("Image", GUILayout.Width(60));
				currButton.image = (Texture2D)EditorGUILayout.ObjectField(currButton.image, typeof(Texture2D), false, GUILayout.Width(90));

				GUI.enabled = currButton.image != null;
				if (GUILayout.Button("Snap Scale", EditorStyles.miniButtonRight, GUILayout.Width(70)))
				{
					currButton.width = currButton.image.width;
					currButton.height = currButton.image.height;
				}
				GUI.enabled = true;
			}
			EditorGUILayout.EndHorizontal();

			EditorGUILayout.Space();
			plyEdGUI.LookLikeControls();
			GUILayout.Label("Text");
			currButton.label = EditorGUILayout.TextArea(currButton.label, plyEdGUI.Skin.textArea);
		}

		private void DrawEditProperties(OnGUIEdit currEd)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Text Field");
			GUILayout.Label("Text");
			currEd.initText = EditorGUILayout.TextArea(currEd.initText, plyEdGUI.Skin.textArea);
		}

		private void DrawToggleProperties(OnGUIToggle currToggle)
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Toggle");
			plyEdGUI.LookLikeControls(80);
			currToggle.initState = EditorGUILayout.Toggle("Init State", currToggle.initState);

			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label("On Click", GUILayout.Width(60));
				currToggle.eventName = EditorGUILayout.TextField(currToggle.eventName, GUILayout.Width(105));
				if (GUILayout.Button(GC_plyBlox, EditorStyles.miniButtonRight, GUILayout.Width(55)))
				{
					Selection.activeGameObject = bloxGameObject;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd();
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUIUtility.labelWidth = 64;
			currToggle.eventParam1 = EditorGUILayout.TextField("param1", currToggle.eventParam1);
			EditorGUILayout.LabelField("param2", "'on' or 'off'");

			EditorGUILayout.Space();
			currToggle.soundClip = (AudioClip)EditorGUILayout.ObjectField("Sound", currToggle.soundClip, typeof(AudioClip), false);

			plyEdGUI.LookLikeControls();
			GUILayout.Label("Text");
			currToggle.label = EditorGUILayout.TextArea(currToggle.label, plyEdGUI.Skin.textArea);
		}

		#endregion
		// ============================================================================================================
		#region Draw Main edit area

		private void CheckGUIContent()
		{
			plyBloxGUI.UseSkin();
			if (GC_plyBlox == null)
			{
				GC_plyBlox = new GUIContent(" Edit", plyBloxGUI.LogoIcon12, "Open plyBlox Editor");
				GC_FrameButton = new GUIContent(FA.square_o.ToString(), "Show Frames");

				GC_AddLabel = new GUIContent("T", "Add Text Element");
				GC_AddButton = new GUIContent(FA.square.ToString(), "Add Button Element");
				GC_AddEdit = new GUIContent(FA.terminal.ToString(), "Add Edit Element");
				GC_AddCheck = new GUIContent(FA.check_square_o.ToString(), "Add Toggle Element");
				GC_AddImage = new GUIContent(FA.picture_o.ToString(), "Add Image Element");
				GC_AddBox = new GUIContent(FA.square_o.ToString(), "Add Box Element");
				GC_AddMovie = new GUIContent(FA.film.ToString(), "Add Movie Element");

				Icon_MovieTexture = AssetPreview.GetMiniTypeThumbnail(typeof(MovieTexture));
				Icon_Font = AssetPreview.GetMiniTypeThumbnail(typeof(Font));
				Icon_Texture = AssetPreview.GetMiniTypeThumbnail(typeof(Texture));

				BlockFrameStyle = new GUIStyle()
				{
					border = new RectOffset(2, 2, 2, 2),
					normal = { background = plyEdGUI.LoadTextureResource("plyGameEditor.edRes.ScreenEd.blockframe.png", typeof(EdGlobal).Assembly) },
				};

				BlockFrameSelStyle = new GUIStyle()
				{
					border = new RectOffset(2, 2, 2, 2),
					normal = { background = plyEdGUI.LoadTextureResource("plyGameEditor.edRes.ScreenEd.blockframesel.png", typeof(EdGlobal).Assembly) },
				};
			}
		}

		public void DrawMain(EditorWindow ed, GUIScreen screenData, ScriptableObject asset, string helpUrl)
		{
			if (Application.isPlaying)
			{
				GUILayout.Label("-can't edit during play mode-");
				return;
			}

			CheckGUIContent();

			this.ed = ed;
			this.screenData = screenData;
			this.asset = asset;

			_allRect = EditorGUILayout.BeginVertical(GUILayout.ExpandHeight(true), GUILayout.ExpandWidth(true));
			{
				// tools
				_barRect = EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
				{
					if (GUILayout.Button(GC_AddLabel, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUILabel ele = new OnGUILabel();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Label-" + curr.id;
						ele.text = "label";
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					}
					if (GUILayout.Button(GC_AddButton, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUIButton ele = new OnGUIButton();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Button-" + curr.id;
						ele.label = "button";
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					}
					if (GUILayout.Button(GC_AddEdit, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUIEdit ele = new OnGUIEdit();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Edit-" + curr.id;
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					}
					if (GUILayout.Button(GC_AddCheck, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUIToggle ele = new OnGUIToggle();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Toggle-" + curr.id;
						ele.label = "toggle";
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					}
					if (GUILayout.Button(GC_AddImage, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUIImage ele = new OnGUIImage();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Image-" + curr.id;
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					}
					if (GUILayout.Button(GC_AddBox, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUIBox ele = new OnGUIBox();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Box-" + curr.id;
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					} 
					if (GUILayout.Button(GC_AddMovie, plyEdGUI.ToolbarIconButtonStyle, GUILayout.Width(30)))
					{
						OnGUIMovie ele = new OnGUIMovie();
						curr = ele;
						ele.id = screenData.NextUIElementId;
						ele.name = "Movie-" + curr.id;
						screenData.AddElement(ele);
						GUI.changed = true;
						plyEdGUI.ClearFocus();
					}

					GUILayout.Space(10);
					if (curr == null) GUI.enabled = false;
					if (GUILayout.Button(plyEdGUI.GC_Copy, plyEdGUI.ToolbarIconButtonStyle))
					{
						CopyElement();
						plyEdGUI.ClearFocus();
					}
					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.ToolbarIconButtonStyle))
					{
						DeleteElement();
						plyEdGUI.ClearFocus();
					}
					GUI.enabled = true;

					GUILayout.FlexibleSpace();

					showFrames = GUILayout.Toggle(showFrames, GC_FrameButton, plyEdGUI.ToolbarIconButtonStyle);
					selectedPreviewGroup = (PreviewResolutions.SizeGroupType)EditorGUILayout.EnumPopup(selectedPreviewGroup, plyEdGUI.ToolbarPopupStyle, GUILayout.Width(85));
					selectedPreviewSize = EditorGUILayout.Popup(selectedPreviewSize, previewRes.viewSizeGroups[selectedPreviewGroup].viewSizeNames, plyEdGUI.ToolbarPopupStyle, GUILayout.Width(120));

					if (helpUrl != null)
					{
						if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.ToolbarIconButtonStyle)) Application.OpenURL(helpUrl);
					}
				}
				EditorGUILayout.EndHorizontal();

				mainRect = _allRect;
				mainRect.y += (_barRect.height + 10);
				mainRect.height -= (_barRect.height + 20);
				mainRect.x += 10;
				mainRect.width -= 20;

				if (selectedPreviewSize >= previewRes.viewSizeGroups[selectedPreviewGroup].viewSizes.Length) selectedPreviewSize = 0;
				mainRect = previewRes.GetConstrainedRect(mainRect, previewRes.viewSizeGroups[selectedPreviewGroup].viewSizes[selectedPreviewSize]);

				// Draw a background colour
				if (screenData.doClearBack)
				{
					Color oldC = GUI.backgroundColor;
					screenData.backgroundColor.a = 1f; // system does not allow for translucent screens so do not show it like that in preview
					GUI.backgroundColor = screenData.backgroundColor;
					GUI.Box(mainRect, GUIContent.none, plyEdGUI.FlatWhiteStyle);
					GUI.backgroundColor = oldC;
				}
				else
				{
					plyEdGUI.DrawBlocksGrid(mainRect, 32, Color.gray, Color.white);
				}

				// Draw the blocks
				GUI.BeginGroup(mainRect);
				DrawElements();
				GUI.EndGroup();

				// Draw a Shadow over everything
				GUI.Box(mainRect, GUIContent.none, plyEdGUI.InnerShadowStyle);			
			}
			EditorGUILayout.EndVertical();

			HandleEvents();
		}

		private void DrawElements()
		{
			GUISkin oldSkin = GUI.skin;
			skin = screenData.skin != null ? screenData.skin : EditorGUIUtility.GetBuiltinSkin(EditorSkin.Scene);
			GUI.skin = skin;

			Rect r, r2;
			foreach (OnGUIElement b in screenData.uiElements)
			{
				//b.InitGUICache(skin);
				b.InitGUICacheEd(skin);

				r = GetElementFrame(b);
				b.EdDraw(r);

				switch (b.type)
				{
					case UIElementType.Label: DrawLabelEle(r, (OnGUILabel)b); break;
					case UIElementType.Image: DrawImageEle(r, (OnGUIImage)b); break;
					case UIElementType.Movie: DrawMovieEle(r, (OnGUIMovie)b); break;
				}

				if (showFrames || curr == b) GUI.Box(r, GUIContent.none, curr == b ? BlockFrameSelStyle : BlockFrameStyle);

				if (b == curr)
				{
					// Show a cursor for move/ scale
					int cid = EditorGUIUtility.GetControlID(FocusType.Passive, r);
					r2 = r; r2.width = 10; // left
					EditorGUIUtility.AddCursorRect(r2, MouseCursor.ResizeHorizontal, cid);
					r2.x = r.xMax - 10; // right
					EditorGUIUtility.AddCursorRect(r2, MouseCursor.ResizeHorizontal, cid);
					r2.x = r.x; r2.width = r.width; r2.height = 10; // top
					EditorGUIUtility.AddCursorRect(r2, MouseCursor.ResizeVertical, cid);
					r2.y = r.yMax - 10; // bottom
					EditorGUIUtility.AddCursorRect(r2, MouseCursor.ResizeVertical, cid);
					r2 = r; r2.x += 10; r2.width -= 20; r2.y += 10; r2.height -= 20;
					if (r2.height > 0 && r2.width > 0)
					{
						EditorGUIUtility.AddCursorRect(r2, MouseCursor.MoveArrow, cid);
					}
				}

				// Check if should handle event
				if (Event.current.type == EventType.MouseDown && Event.current.button == 0)
				{
					if (r.Contains(Event.current.mousePosition))
					{
						SelectElement(b);
						drag = 0;
						dragUndoCheck[0] = curr.offsetX;
						dragUndoCheck[1] = curr.offsetY;
						dragUndoCheck[2] = curr.width;
						dragUndoCheck[3] = curr.height;

						// check if what drag should be set to (move or scaling)
						// cant scale if too small since can't grab it
						if (curr.width >= 15 && curr.height >= 15)
						{
							r2 = r; r2.width = 10; // left
							if (r2.Contains(Event.current.mousePosition)) drag = 1;
							else
							{
								r2.x = r.xMax - 10; // right
								if (r2.Contains(Event.current.mousePosition)) drag = 2;
								else
								{
									r2.x = r.x; r2.width = r.width;
									r2.height = 10; // top
									if (r2.Contains(Event.current.mousePosition)) drag = 3;
									else
									{
										r2.y = r.yMax - 10; // bottom
										if (r2.Contains(Event.current.mousePosition)) drag = 4;
									}
								}
							}
						} // Check if width/height high enough to scale check
					} // contains
				} // event
			}

			GUI.skin = oldSkin;
			ed.Repaint();
		}

		private void DrawLabelEle(Rect r, OnGUILabel txt)
		{
			if (string.IsNullOrEmpty(txt.text))
			{
				r.width = 32; r.height = 32;
				GUI.DrawTexture(r, Icon_Font);
			}
		}

		private void DrawImageEle(Rect r, OnGUIImage img)
		{
			if (img.texture == null)
			{
				r.width = 32; r.height = 32;
				GUI.DrawTexture(r, Icon_Texture);
			}
		}

		private void DrawMovieEle(Rect r, OnGUIMovie mov)
		{
			MovieTexture m = mov.video as MovieTexture;
			if (m != null)
			{
				if (m.isPlaying)
				{
					ed.Repaint();
					return;
				}
			}
			
			r.width = 32; r.height = 32;
			GUI.DrawTexture(r, Icon_MovieTexture);
		}

		private Rect GetElementFrame(OnGUIElement block)
		{
			Rect r = new Rect(block.offsetX, block.offsetY, block.width, block.height);

			switch (block.scaling)
			{			
				case UIScale.StretchWidth:
				{
					r.width = mainRect.width;
				} break;
	
				case UIScale.StretchHeight:
				{
					r.height = mainRect.height;
				} break;

				case UIScale.StretchBoth:
				{
					r.width = mainRect.width;
					r.height = mainRect.height;
				} break;

				case UIScale.ScaleToFit:
				{
					float screenAspect = mainRect.width / mainRect.height;
					float imageAspect = (float)block.width / (float)block.height;
					if (screenAspect > imageAspect)
					{
						r.width = mainRect.width * (imageAspect / screenAspect);
						r.height = mainRect.height;
					}
					else
					{
						r.width =  mainRect.width;
						r.height = mainRect.height * (screenAspect / imageAspect);
					}
				} break;

				case UIScale.ScaleAndCrop:
				{
					float screenAspect = mainRect.width / mainRect.height;
					float imageAspect = (float)block.width / (float)block.height;
					if (screenAspect > imageAspect)
					{
						r.width = mainRect.width;
						r.height = mainRect.height * (screenAspect / imageAspect);
					}
					else
					{
						r.width = mainRect.width * (imageAspect / screenAspect);
						r.height = mainRect.height;
					}
				} break;
			}

			// -----------------------------------------------------

			switch (block.anchor)
			{
				case UIAnchor.UpperLeft:
				{
					// nothing to do
				} break;

				case UIAnchor.UpperCenter:
				{
					r.x += (mainRect.width / 2 - r.width / 2);
				} break;

				case UIAnchor.UpperRight:
				{
					r.x += (mainRect.width - r.width);
				} break;

				case UIAnchor.MiddleLeft:
				{
					r.y += (mainRect.height / 2 - r.height / 2);
				} break;

				case UIAnchor.MiddleCenter:
				{
					r.x += (mainRect.width / 2 - r.width / 2);
					r.y += (mainRect.height / 2 - r.height / 2);
				} break;

				case UIAnchor.MiddleRight:
				{
					r.x += (mainRect.width - r.width);
					r.y += (mainRect.height / 2 - r.height / 2);
				} break;

				case UIAnchor.LowerLeft:
				{
					r.y += (mainRect.height - r.height);
				} break;

				case UIAnchor.LowerCenter:
				{
					r.x += (mainRect.width / 2 - r.width / 2);
					r.y += (mainRect.height - r.height);
				} break;

				case UIAnchor.LowerRight:
				{
					r.x += (mainRect.width - r.width);
					r.y += (mainRect.height - r.height);
				} break;
			}

			return r;
		}

		private void HandleEvents()
		{
			if (drag >= 0)
			{
				if (Event.current.type == EventType.MouseDrag)
				{
					switch (drag)
					{
						case 0: // move
						{
							curr.offsetX += (int)Event.current.delta.x;
							curr.offsetY += (int)Event.current.delta.y;
						} break;
						case 1: // scale to left
						{
							if (curr.anchor == UIAnchor.MiddleCenter || curr.anchor == UIAnchor.UpperCenter || curr.anchor == UIAnchor.LowerCenter)
							{
								curr.width -= (int)Event.current.delta.x * 2;
							}
							else
							{
								if (curr.anchor == UIAnchor.UpperLeft || curr.anchor == UIAnchor.LowerLeft || curr.anchor == UIAnchor.MiddleLeft)
								{
									curr.offsetX += (int)Event.current.delta.x;
									curr.width -= (int)Event.current.delta.x;
								}
								else
								{
									curr.width -= (int)Event.current.delta.x;
								}
							}
							if (curr.width < 3) curr.width = 3;
						} break;
						case 2: // scale to right
						{
							if (curr.anchor == UIAnchor.MiddleCenter || curr.anchor == UIAnchor.UpperCenter || curr.anchor == UIAnchor.LowerCenter)
							{
								curr.width += (int)Event.current.delta.x * 2;
							}
							else
							{
								if (curr.anchor == UIAnchor.UpperLeft || curr.anchor == UIAnchor.LowerLeft || curr.anchor == UIAnchor.MiddleLeft)
								{
									curr.width += (int)Event.current.delta.x;
								}
								else
								{
									curr.offsetX += (int)Event.current.delta.x;
									curr.width += (int)Event.current.delta.x;
								} 
							}
							if (curr.width < 3) curr.width = 3;
						} break;
						case 3: // scale to top
						{
							if (curr.anchor == UIAnchor.MiddleCenter || curr.anchor == UIAnchor.MiddleLeft || curr.anchor == UIAnchor.MiddleRight)
							{
								curr.height -= (int)Event.current.delta.y * 2;
							}
							else
							{
								if (curr.anchor == UIAnchor.UpperCenter || curr.anchor == UIAnchor.UpperLeft || curr.anchor == UIAnchor.UpperRight)
								{
									curr.offsetY += (int)Event.current.delta.y;
									curr.height -= (int)Event.current.delta.y;
								}
								else
								{
									curr.height -= (int)Event.current.delta.y;
								}
							}
							if (curr.height < 3) curr.height = 3;
						} break;
						case 4: // scale to bottom
						{
							if (curr.anchor == UIAnchor.MiddleCenter || curr.anchor == UIAnchor.MiddleLeft || curr.anchor == UIAnchor.MiddleRight)
							{
								curr.height += (int)Event.current.delta.y * 2;
							}
							else
							{
								if (curr.anchor == UIAnchor.UpperCenter || curr.anchor == UIAnchor.UpperLeft || curr.anchor == UIAnchor.UpperRight)
								{
									curr.height += (int)Event.current.delta.y;
								}
								else
								{
									curr.offsetY += (int)Event.current.delta.y;
									curr.height += (int)Event.current.delta.y;
								}
							}
							if (curr.height < 3) curr.height = 3;
						} break;
					}

					GUI.changed = false;
					ed.Repaint();
				}

				else if (Event.current.type == EventType.mouseUp)
				{
					// only register an undo if the offset or size of block actually changed while mouse was down
					if (dragUndoCheck[0] != curr.offsetX || dragUndoCheck[1] != curr.offsetY || dragUndoCheck[2] != curr.width || dragUndoCheck[3] != curr.height)
					{
						// save info on where it is now
						int[] t = { curr.offsetX, curr.offsetY, curr.width, curr.height };

						// now move it back to where it was before I can register the undo
						curr.offsetX = dragUndoCheck[0];
						curr.offsetY = dragUndoCheck[1];
						curr.width = dragUndoCheck[2];
						curr.height = dragUndoCheck[3];

						// now register undo
						Undo.RecordObject(asset, (drag == 0 ? "Move: " : "Scaling: ") + curr.name);

						// and move it back to where it should be
						curr.offsetX = t[0];
						curr.offsetY = t[1];
						curr.width = t[2];
						curr.height = t[3];
					}
					drag = -1;
				}
			}

			else if (curr != null)
			{
				if (Event.current.type == EventType.ValidateCommand && Event.current.commandName == "Duplicate")
				{
					CopyElement();
					Event.current.Use();
				}

				if (Event.current.type == EventType.KeyDown)
				{
					if (Event.current.keyCode == KeyCode.Delete)
					{
						DeleteElement();
						Event.current.Use();
					}

					if (Event.current.keyCode == KeyCode.Escape)
					{	// Unselect Node
						if (curr != null)
						{
							if (curr.type == UIElementType.Movie)
							{
								OnGUIMovie currMov = (OnGUIMovie)curr;
								MovieTexture mov = currMov.video as MovieTexture;
								if (mov != null)
								{
									if (mov.isPlaying) mov.Stop();
									plyEdUtil.StopAllAudioClips();
								}
							}
						}

						curr = null;
						Event.current.Use();
						ed.Repaint();
					}
				}
			}
		}

		private void DeleteElement()
		{
			if (curr != null)
			{
				if (curr.type == UIElementType.Movie)
				{
					OnGUIMovie currMov = (OnGUIMovie)curr;
					MovieTexture mov = currMov.video as MovieTexture;
					if (mov != null)
					{
						if (mov.isPlaying) mov.Stop();
						plyEdUtil.StopAllAudioClips();
					}
				}
			}

			Undo.RecordObject(asset, "Delete: " + curr.name);
			screenData.RemoveElement(curr);
			curr = null;
			GUI.changed = true;
			ed.Repaint();
		}

		private void CopyElement()
		{
			if (curr == null) return;

			if (curr.type == UIElementType.Movie)
			{
				OnGUIMovie currMov = (OnGUIMovie)curr;
				MovieTexture mov = currMov.video as MovieTexture;
				if (mov != null)
				{
					if (mov.isPlaying) mov.Stop();
					plyEdUtil.StopAllAudioClips();
				}
			}

			OnGUIElement b = curr.Copy();
			b.id = screenData.NextUIElementId;
			b.name = b.type + "-" + b.id;
			screenData.AddElement(b);

			curr = b;

			GUI.changed = true;
			screenData.SortElements();
			ed.Repaint();
		}

		private void SelectElement(OnGUIElement b)
		{
			GUI.FocusControl("");
			curr = b;
			ed.Repaint();
		}

		#endregion
		// ============================================================================================================
	}
}
