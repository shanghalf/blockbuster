﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyGame;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[CustomEditor(typeof(PersistableObject))]
	public class PersistableObject_Inspector : Editor
	{
		private Object prefabLink = null;
		private UniqueID prefabUniqueId = null;

		protected void OnEnable() 
		{
			if (false == EditorUtility.IsPersistent(target))
			{
				PersistableObject fab = PrefabUtility.GetPrefabParent(target) as PersistableObject;
				if (fab != null) prefabUniqueId = fab.id;
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref ((PersistableObject)target).id, prefabUniqueId, true, true))
			{
				EditorUtility.SetDirty(target);
			}
		}

		public override void OnInspectorGUI()
		{
			if (UniqueIDManager.CheckID(target, ref prefabLink, ref ((PersistableObject)target).id, prefabUniqueId, false, true))
			{
				EditorUtility.SetDirty(target);
			}

			DrawDefaultInspector();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}
		
		// ============================================================================================================
	}
}
