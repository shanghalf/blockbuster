﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Input", "Input (plyGame)", "Button Held", BlockType.Condition, Order = 1,
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True while the defined button is held down in this frame. This works with the buttons you defined in plyGame Input Definitions editor.")]
	public class plyInput_ButtonHeld_plyBlock : Bool_Value
	{

		[plyBlockField("Button Name", ShowAfterField = "Button Held", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public InputDefNameTextData button = new InputDefNameTextData(); // input definition name

		private int KeyIdx = -1;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = !string.IsNullOrEmpty(button.name);
			if (!blockIsValid) Log(LogType.Error, "Button Name must be set.");
		}

		public override void Initialise()
		{
			KeyIdx = plyInput.GetInputIdx(button.name);
			value = false;
			if (KeyIdx == -1) blockIsValid = false;
			if (!blockIsValid) Log(LogType.Error, "Button is not defined: " + button.name);
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = plyInput.GetButton(KeyIdx);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}