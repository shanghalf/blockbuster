﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Set Toggle State", BlockType.Action, Order = 10, 
		Description = "Set the state of a Toggle Element to ON or OFF.")]
	public class ScreensEle_SetToggle_plyBlock : plyBlock
	{
		[plyBlockField("Set Toggle", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", CustomValueStyle = "plyBlox_BoldLabel", Description = "Name of the element as defined in the Screens Editor.")]
		public string eleName = "";

		[plyBlockField("on", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		[plyBlockField("to", ShowName = true, ShowValue = true, EmptyValueName="-off-", SubName="State - Boolean", Description="True = on, False = off")]
		public Bool_Value state;

		private OnGUIToggle ele;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) { Log(LogType.Error, "Screen name must be set."); return; }
			blockIsValid = !string.IsNullOrEmpty(eleName);
			if (!blockIsValid) { Log(LogType.Error, "Element name must be set."); return; }
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (ele == null)
			{
				GUIScreen scr = GameGlobal.Instance.uiManager.GetScreen(screen.name);
				if (scr == null)
				{
					Log(LogType.Error, "The screen [" + screen.name + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				OnGUIElement e = scr.GetElement(eleName);
				if (e == null)
				{
					Log(LogType.Error, "The element [" + eleName + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				ele = e as OnGUIToggle;
				if (ele == null)
				{
					Log(LogType.Error, "The element is not a Toggle type.");
					blockIsValid = false;
					return BlockReturn.Error;
				}
			}

			ele.state = (state == null ? false : state.RunAndGetBool());

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}