﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Set Enabled", BlockType.Action, Order = 10, 
		Description = "Set an element on a screen to be enabled or disabled.")]
	public class ScreensEle_SetEnabled_plyBlock : plyBlock
	{
		[plyBlockField("Set", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", CustomValueStyle = "plyBlox_BoldLabel", Description = "Name of the element as defined in the Screens Editor.")]
		public string ele = "";

		[plyBlockField("on", ShowAfterField="to", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		[plyBlockField("state", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public plyEnabledState state = plyEnabledState.Enabled;

		private GUIScreen scr;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) Log(LogType.Error, "Screen name must be set.");
			blockIsValid = !string.IsNullOrEmpty(ele);
			if (!blockIsValid) Log(LogType.Error, "Element name must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (scr == null)
			{
				scr = GameGlobal.Instance.uiManager.GetScreen(screen.name);
				if (scr == null)
				{
					Log(LogType.Error, "The screen [" + screen.name + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}
			}

			scr.SetElementEnabled(ele, state == plyEnabledState.Enabled);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}