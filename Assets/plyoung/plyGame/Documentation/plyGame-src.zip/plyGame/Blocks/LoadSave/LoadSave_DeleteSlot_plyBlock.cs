﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Delete Slot", BlockType.Action, Order = 1, ShowName = "Delete all data in",
		Description = "This will delete all data (keys and values) of the specified Slot and Active Profile. Will change active Slot if a slot is given.")]
	public class LoadSave_DeleteSlot_plyBlock : plyBlock
	{
		[plyBlockField("Slot", ShowName = true, ShowValue = true, EmptyValueName = "-current-", SubName="Slot - Integer", Description = "The slot to delete. Leave empty if currently set slot should be used. Will change the current/ active slot to this one if set.")]
		public Int_Value slot;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (slot != null) GameGlobal.SetActiveSaveSlot(slot.RunAndGetInt());
			GameGlobal.DeleteAllDataInActiveSlot();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}