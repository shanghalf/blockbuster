﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Get Slot Count", BlockType.Variable, Order = 1, ShowName = "LoadSave Slot Count",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value),
		/*CustomStyle = "plyBlox_VarYellowDark",*/ Description = "Get the number of slots that are saved in active profile.")]
	public class LoadSave_GetSlotCount_plyBlock : Int_Value
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GameGlobal.GetSavedSlotCount();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}