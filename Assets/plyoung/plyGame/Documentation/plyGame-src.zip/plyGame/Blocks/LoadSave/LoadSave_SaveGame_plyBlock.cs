﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Save Game", BlockType.Action, Order = 1, ShowName = "Save Game to",
		Description = "Save the current state of the game to specified slot of active profile. Will change active Slot if a slot is given.")]
	public class LoadSave_SaveGame_plyBlock : plyBlock
	{
		[plyBlockField("Slot", ShowName = true, ShowValue = true, EmptyValueName = "-current-", SubName="Slot - Integer", Description = "The slot to save to. Leave empty if currently set slot should be used. Will change the current/ active slot to this one if set.")]
		public Int_Value slot;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (slot != null) GameGlobal.SetActiveSaveSlot(slot.RunAndGetInt());
			GameGlobal.SaveGameSession();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}