﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Get Profile Name", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - String", ReturnValueType = typeof(String_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Return the name of a LoadSave Profile. Returned value (string) will be empty if profile was not found at given index.")]
	public class LoadSave_GetProfileName_plyBlock : String_Value
	{
		[plyBlockField("Profile", ShowAfterField="Name", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), EmptyValueName = "-invalid-", SubName = "Profile Index - Integer", Description = "The index (number) of the profile. This should be a number from 0 to one less than what is returned by Profile Count block.")]
		public Int_Value index;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = index != null;
			if (!blockIsValid) Log(LogType.Error, "The Profile index field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			int idx = index.RunAndGetInt();
			string n = GameGlobal.GetProfileName(idx);
			if (n == null)
			{
				Log(LogType.Warning, "No profile found at index: " + idx);
				return BlockReturn.Error;
			}

			value = n;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}