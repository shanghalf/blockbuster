﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Delete Profile", BlockType.Action, Order = 1,
		Description = "Delete the specified profile. Active profile will be reset to profile 0.")]
	public class LoadSave_DeleteProfile_plyBlock : plyBlock
	{
		[plyBlockField("Delete Profile", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot - Integer", Description = "Index of profile to delete.")]
		public Int_Value slot;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = slot != null;
			if (!blockIsValid) Log(LogType.Error, "Slot field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.DeleteProfile(slot.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}