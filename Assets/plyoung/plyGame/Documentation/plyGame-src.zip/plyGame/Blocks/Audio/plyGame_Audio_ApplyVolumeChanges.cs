﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Save Volume Changes", BlockType.Action, Order = 1, ShowIcon = "listener", ShowName = "Save Volume Changes",
		Description = "Save and notify the volume updaters about changes.")]
	public class plyGame_Audio_ApplyVolumeChanges : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.ApplySoundVolumeChanges();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}