﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Update Sound Volume", BlockType.Action, Order = 1, ShowIcon = "listener", ShowName = "Update Sound Volume",
		Description = "Force the audio listener (main) and sound volume updaters to adjust according to sound volume settings.")]
	public class plyGame_Audio_UpdateVolumes : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.UpdateAudioVolumes();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}