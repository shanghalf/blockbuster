﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Get Volume (Float)", BlockType.Variable, Order = 1, ShowIcon = "listener",
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Return the volume of the selected sound volume type as a float value from 0.0f to 1.0f.")]
	public class plyGame_Audio_GetVolumeFloat : Float_Value
	{
		[plyBlockField("Volume of", ShowAfterField="as Float", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "The sound volume type.")]
		public GameGlobal.VolumeType type = GameGlobal.VolumeType.Main;

		public override void Created()
		{
			GameGlobal.Create();
			stopAllOnError = false;
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GameGlobal.Instance.GetSoundVolume(type);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}