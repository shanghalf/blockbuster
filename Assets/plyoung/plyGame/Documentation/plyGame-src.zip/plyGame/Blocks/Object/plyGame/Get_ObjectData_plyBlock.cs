﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Object", "plyGame", "Get Object Ident", BlockType.Variable, Order = 1, ShowName = "Get",
		ReturnValueString = "Return - String", ReturnValueType = typeof(String_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Returns identifying data of an object from its common definition data (ident, screenName, shortName, meta, etc).")]
	public class Get_ObjectData_plyBlock : String_Value
	{
		[plyBlockField("Data Type", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", SubName = "Data Type - System.Object", Description = "The kind of data to retrieve.")]
		public plyGameObjectIdentifyingType dataType = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Target - Object", Description = "Should be an object that has this kind of data available, like Item, Skill, Attribute, Actor component, etc.")]
		public plyValue_Block target;

		public override void Created()
		{
			blockIsValid = target != null;
			if (!blockIsValid)
			{
				Log(LogType.Error, "The Target must be set");
				value = "-error-";
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			System.Object obj = target.RunAndGetValue();
			if (obj == null)
			{
				Log(LogType.Error, "The specified object was null.");
				value = "-error-";
				return BlockReturn.Error;
			}

			CommonDefinitionData def = plyReflectionUtil.GetFieldValue(obj, "def") as CommonDefinitionData;
			if (def == null)
			{
				Log(LogType.Error, "Could not find Common Definition Data on target.");
				value = "-error-";
				return BlockReturn.Error;
			}

			switch (dataType)
			{
				case plyGameObjectIdentifyingType.ident: value = def.ident == null ? "" : def.ident; break;
				case plyGameObjectIdentifyingType.screenName: value = def.screenName == null ? "" : def.screenName; break;
				case plyGameObjectIdentifyingType.shortName: value = def.shortName == null ? "" : def.shortName; break;
				case plyGameObjectIdentifyingType.meta: value = def.meta == null ? "" : def.meta; break;
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}