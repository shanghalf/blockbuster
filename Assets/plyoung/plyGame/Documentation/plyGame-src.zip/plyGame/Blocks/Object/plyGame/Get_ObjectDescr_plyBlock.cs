﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Object", "plyGame", "Get Object Description", BlockType.Variable, Order = 1, ShowName = "Get description",
		ReturnValueString = "Return - String", ReturnValueType = typeof(String_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Returns description of an object from its common definition data (ident, screenName, shortName, meta, etc).")]
	public class Get_ObjectDescr_plyBlock : String_Value
	{
		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Target - Object", Description = "Should be an object that has this kind of data available, like Item, Skill, Attribute, Actor component, etc.")]
		public plyValue_Block target;

		public override void Created()
		{
			blockIsValid = target != null;
			if (!blockIsValid)
			{
				Log(LogType.Error, "The Target must be set");
				value = "-error-";
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			System.Object obj = target.RunAndGetValue();
			if (obj == null)
			{
				Log(LogType.Error, "The specified object was null.");
				value = "-error-";
				return BlockReturn.Error;
			}

			CommonDefinitionData def = plyReflectionUtil.GetFieldValue(obj, "def") as CommonDefinitionData;
			if (def == null)
			{
				Log(LogType.Error, "Could not find Common Definition Data on target.");
				value = "-error-";
				return BlockReturn.Error;
			}

			value = def.description == null ? "" : def.description;

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}