﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Render", "Screen (plyGame)", "Apply Resolution", BlockType.Action, Order = 31, ShowName = "Apply Resolution",
		Description = "Apply the selected screen resolution.")]
	public class ApplyResolution_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.ApplySelectedResolution();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}