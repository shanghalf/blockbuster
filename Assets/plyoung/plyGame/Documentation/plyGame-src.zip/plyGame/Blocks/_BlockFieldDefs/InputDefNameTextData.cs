﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	public class InputDefNameTextData
	{
		public string name = "";

		public override string ToString()
		{
			return string.IsNullOrEmpty(name) ? "-none-" : name;
		}

		public InputDefNameTextData Copy()
		{
			InputDefNameTextData o = new InputDefNameTextData();
			o.name = this.name;
			return o;
		}

		// ============================================================================================================
	}
}