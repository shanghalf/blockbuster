﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("Common", "On After Load",
		Description = "Called after saved data was restored for the object. You might want to use this in place of the `On Start` and `On State Enter` events if you need saved data to be ready.")]
	public class OnAfterLoadEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_LoadSaveSystem);
		}

		// ============================================================================================================
	}
}