﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// Disables gameObject after timeout and then removes this component
	/// </summary>
	[AddComponentMenu("plyGame/Misc/Auto-Disable after Timeout")]
	public class AutoDisableTimeout : MonoBehaviour
	{
		public float timeout = 1f; // seconds
		private float startTime = 0f;

		protected void OnEnable()
		{
			startTime = Time.time + timeout;
		}

		protected void LateUpdate()
		{
			if (Time.time > startTime)
			{
				gameObject.SetActive(false);
				Destroy(this);
			}
		}

		// ============================================================================================================
	}
}