﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/Auto-Destroy after Timeout")]
	public class AutoDestroyTimeout : MonoBehaviour
	{
		public float timeout = 1f; // seconds

		protected void OnEnable()
		{
			Object.Destroy(gameObject, timeout);
		}

		// ============================================================================================================
	}
}