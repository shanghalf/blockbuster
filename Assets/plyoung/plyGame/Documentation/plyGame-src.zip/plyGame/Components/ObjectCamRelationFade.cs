﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/Object Cam Relation Fade")]
	public class ObjectCamRelationFade : MonoBehaviour
	{
		public Transform targetObject;
		public Vector3 focusPoint = new Vector3(0f, 1.7f, 0f);
		public float fadeDistance = 2.0f;
		public float hideDistance = 1.0f;

		private Camera cam;
		private Renderer[] ren = new Renderer[0];

		// ============================================================================================================

		public void RefreshRendererList()
		{
			ren = targetObject.GetComponentsInChildren<Renderer>(false);
			if (ren.Length == 0)
			{
				Debug.LogError("[Object Cam Relation Fade] The target object has no renderers. Disabling this component.");
				enabled = false;
			}
			else
			{
				enabled = true; // just in case it was disabled form a RefreshRendererList() before
			}
		}

		protected void Reset()
		{
			Setup();
		}

		protected void Start()
		{
			Setup();

			if (cam == null) cam = Camera.main;

			if (targetObject == null)
			{
				Debug.LogError("[Object Cam Relation Fade] No object assigned.");
				enabled = false;
				return;
			}

			if (cam == null)
			{
				Debug.LogError("[Object Cam Relation Fade] No main camera found.");
				enabled = false;
				return;
			}

			RefreshRendererList();

			// using sqrMagnitude in checks, so multiply the distances
			//fadeDistance = fadeDistance * fadeDistance;
			//hideDistance = hideDistance * hideDistance;
		}

		private void Setup()
		{
			if (targetObject == null) targetObject = GetComponent<Transform>();
		}

		protected void Update()
		{
			float distance = ((targetObject.transform.position + focusPoint) - cam.transform.position).magnitude;

			if (distance < hideDistance)
			{
				SetAllEnabled(false);
			}
			else if (distance < fadeDistance)
			{
				SetAllEnabled(true);
				float alpha = 1.0f - (fadeDistance - distance) / (fadeDistance - hideDistance);
				UpdateAllAlpha(alpha);
			}
			else
			{
				SetAllEnabled(true);
				UpdateAllAlpha(1.0f);
			}
		}

		private void SetAllEnabled(bool en)
		{
			bool refresh = false;
			for (int i = 0; i < ren.Length; i++)
			{
				if (ren[i] == null) { refresh = true; continue; }
				ren[i].enabled = en;
			}
			if (refresh) RefreshRendererList();
		}

		private void UpdateAllAlpha(float a)
		{
			bool refresh = false;
			for (int i = 0; i < ren.Length; i++)
			{
				if (ren[i] == null) { refresh = true; continue; }
				if (ren[i].material.color.a != a)
				{
					ren[i].material.color = new Color(ren[i].material.color.r, ren[i].material.color.g, ren[i].material.color.b, a);
				}
			}
			if (refresh) RefreshRendererList();
		}

		// ============================================================================================================
	}
}