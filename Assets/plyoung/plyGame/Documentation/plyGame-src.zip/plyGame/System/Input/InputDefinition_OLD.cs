﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================
/*
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> An input definition. </summary>
	[System.Serializable]
	public class InputDefinition
	{
		/// <summary> Type of input definitions this is. </summary>
		public enum InputType 
		{ 
			Button=0,   //!< A Button. Keyboard, Gamepad or Mouse button.
			Axis		//!< An Axis. Mouse movement and scroll-wheel, or gamepad stick.
		}

		/// <summary> Which mouse axis to use. </summary>
		public enum MouseAxis 
		{ 
			None=0,		//!< none
			MouseX,		//!< Mouse X
			MouseY,		//!< Mouse Y
			ScrollWheel //!< The Scroll Wheel
		}

		/// <summary> Which gamepad to use. </summary>
		public enum Gamepad 
		{ 
			None=0,		//!< None
			Gamepad1,   //!< Gamepad 1
			Gamepad2,   //!< Gamepad 2
			Gamepad3,   //!< Gamepad 3
			Gamepad4    //!< Gamepad 4
		}

		/// <summary> Which gamepad axis to use. </summary>
		public enum GamepadAxis 
		{ 
			None=-1,	//!< None
			Axis1=0,	//!< Axis 1
			Axis2,		//!< Axis 2
			Axis3,		//!< Axis 3
			Axis4,		//!< Axis 4
			Axis5,		//!< Axis 5
			Axis6,		//!< Axis 6
			Axis7,		//!< Axis 7
			Axis8,		//!< Axis 8
			Axis9,		//!< Axis 9
			Axis10 		//!< Axis 10
		}

		/// <summary> When definition is set as Button and an Axis is used to detect button press </summary>
		public enum AxisSide
		{
			Positive,	//!< Positive
			Negative	//!< Negative
		}

		public InputType type = InputType.Button;			//!< The type of this input

		public bool active = true;							//!< Is the definition active?
		public string category;								//!< The category this definition belongs to
		public string name;									//!< The name of the definition
		public string screenName1;							//!< The name to show when presenting the input definition to the player - for key1 & key1Alt option (positive)
		public string screenName2;							//!< The name to show when presenting the input definition to the player - for key2 & key2Alt option (negative)

		public KeyCode key1 = KeyCode.None;					//!< The positive (or single) key to bind to
		public KeyCode key2 = KeyCode.None;					//!< The negative key to bind to
		public KeyCode key1Alt = KeyCode.None;				//!< The alternative positive (or single) key to bind to
		public KeyCode key2Alt = KeyCode.None;				//!< The alternative negative key to bind to
		
		public MouseAxis mouseAxis = MouseAxis.None;		//!< The mouse axis to bind to
		public bool mouseInvert = false;					//!< should value be inversed? When positive/ negative or axis is used
		public AxisSide mouseAxisSide = AxisSide.Positive;	//!< Determine if Positive or Negative axis is used to represent button when type = InputType.Button

		public Gamepad gamepad = Gamepad.None;				//!< The gamepad to bind to
		public GamepadAxis gamepadAxis = GamepadAxis.None;	//!< The gamepad axis to bind to
		public GamepadAxis gamepadAxisMod = GamepadAxis.None; //!< Only used when type = button and this axis is used as modifier
		public bool gamepadInvert = false;					//!< should value be inversed? When positive/ negative or axis is sued
		public AxisSide gamepadAxisSide = AxisSide.Positive;//!< Determine if Positive or Negative axis is used to represent button when type = InputType.Button
		public AxisSide gamepadAxisModSide = AxisSide.Positive;//!< Determine if Positive or Negative axis is used to represent button when type = InputType.Button

		private string _ident = null;
		public string def.ident
		{
			get
			{
				if (_ident == null) _ident = category + "/" + name;
				return _ident;
			}
		}

		// ============================================================================================================

		public InputDefinition Copy()
		{
			InputDefinition d = new InputDefinition();

			d.type = this.type;
	
			d.active = this.active;
			d.category = this.category;
			d.name = this.name;
			d.screenName1 = this.screenName1;
			d.screenName2 = this.screenName2;

			d.key1 = this.key1;
			d.key2 = this.key2;
			d.key1Alt = this.key1Alt;
			d.key2Alt = this.key2Alt;

			d.mouseAxis = this.mouseAxis;
			d.mouseInvert = this.mouseInvert;
			d.mouseAxisSide = this.mouseAxisSide;

			d.gamepad = this.gamepad;
			d.gamepadAxis = this.gamepadAxis;
			d.gamepadAxisMod = this.gamepadAxisMod;
			d.gamepadInvert = this.gamepadInvert;
			d.gamepadAxisSide = this.gamepadAxisSide;
			d.gamepadAxisModSide = this.gamepadAxisModSide;

			return d;
		}

		// ============================================================================================================
	}
}
*/