﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> An interface for all components that might be handled by the LoadSave System. The
	///  PersistenceProvider component looks for components that implements this interface when
	///  deciding what to call to save or load.
	///  
	///  You must add a unique string to the key passed in Save() and Load() and not use it directly.
	///  A good idea might be to use the component's name, for example newKey = key + "." + name_of_component_class.
	///  You can use a shorter string to append, just make sure it does not
	///  clash with keys chosen by other components.
	///  
	///  You might have more than one value to save, in that case you would append further strings to
	///  the key to identify the data uniquely. For example, you want to save two values,
	///  
	///  - key1 = key + "." + component_name + ".a";  
	///  - key2 = key + "." + component_name + ".b";  
	///  
	///  Be sure to use the same way to generate the keys needed when loading.
	///  
	///  You will make calls to GameGlobal.Instance.Set... and Get... functions to do the actual
	///  saving and loading, using your newly created key and the value to save.
	///  
	///  An object that wants to restore itself at runtime, if placed at runtime and not design time, should 
	///  have a static function called LoadCreate(string key) that takes one string argument (the key).
	///  This will then be called when the object should create itself in the scene. An object that want 
	///	 this call to happen should register itself, in Save(), by making a call to GameGlobal.AddCreateLoadKey()
	/// </summary>
	public interface IPersistable
	{
		/// <summary> Implement this to handle saving. This will be called when this component should save. </summary>
		void Save(string key);

		/// <summary> Implement this to handle loading. This will be called when this component should
		///  restore itself from saved data. This will happen after Start() is done. </summary>
		void Load(string key);

		/// <summary> Implement this to handle keys that should be marked for deletion. This will be
		/// called when a GameObject this component is on is marked as destroyed and can therefore
		/// remove all its old saved keys to clear up storage space. </summary>
		void DeleteSaveData(string key);

		/// <summary> Called to tell the component it is not supposed to persist. The Spawn Point
		///  could request this from NPCs since NPCs made by it might not be allowed to save
		///  their states. </summary>
		void DisablePersistence();

		// ============================================================================================================
	}
}