﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> The plyGame Global Object </summary>
	[AddComponentMenu("")]
	public class GameGlobal : MonoBehaviour
	{
		// ================================================================================================================
		#region defines

		/// <summary> Layers used in plyGame </summary>
		public static class LayerMapping
		{
			public const int Floor = 8;			//!< Floor (Floor/ Terrain/ Ground that the characters move on)
			public const int Wall = 9;			//!< Wall (Obstacles)
			public const int Player = 18;		//!< Player (player character)
			public const int NPC = 19;			//!< NPC (non-player character)
			public const int plyObject = 20;	//!< plyObject (Object that can be targeted and interacted with)
			public const int plyItem = 21;		//!< plyItem (Item that can be picked up and used)
			public const int plyTrigger = 22;   //!< plyTrigger (Area Trigger)
		}

		/// <summary> Tags used in plyGame </summary>
		public static class Tag
		{
			public const string Untagged = "Untagged";		//!< Untagged
			public const string MainCamera = "MainCamera";  //!< MainCamera
		}

		/// <summary> The available volume types. These are indexed to DataAsset.volume </summary>
		public enum VolumeType
		{
			Main = 0,
			General = 1,
			GUI = 2,
			Effects = 3,
			Voice = 4,
			Ambient = 5,
			Music = 6,
			Custom1 = 7,
			Custom2 = 8,
			Custom3 = 9
		}

		#endregion
		// ================================================================================================================
		#region properties/ assets/ prefabs

		public GameObject bloxGlobalFab;		// Prefab of the plyBlox Global
		public GameObject uiManagerFab;			// Prefab of GUI/ Screens Manager

		public InputDefAsset inputAsset;		// Data about defined inputs
		public SplashScreenAsset splashAsset;	// Data about defined splash screens
		public LangScreenAsset langScrAsset;	// Data about defined language selection screen
		public LoadScreensAsset loadScrAsset;	// Data about defined load Screens
		public CustomScreensAsset custScrAsset;	// Data about defined custom Screens

		public DataAsset dataAsset;				//!< Contains various definitions like Items and Equip Slots

		#endregion
		// ================================================================================================================
		#region runtime

		/// <summary> Instance of the Game Global. </summary>
		public static GameGlobal Instance { get { return _instance; } }
		private static GameGlobal _instance = null;

		/// <summary> Return true if the instance exist, else false. </summary>
		public static bool HasInstance { get { return _instance != null; } }

		/// <summary> Indicates if game is considered paused or not. When paused the character controllers 
		/// should not allow input, perform AI, or move the characters. There might be other systems that 
		/// need to check this flag to decide when they should be active or not. </summary>
		public static bool Paused { get; set; }

		/// <summary> Reference to the plyBlox Global. </summary>
		public static plyBloxGlobal BloxGlobal { get; private set; }

		/// <summary> The audio listener. </summary>
		public static AudioListener audioListener { get; private set; }
		private Transform audioListenerTr = null;
		private Transform audioListenerFollowTarget = null;

		/// <summary> The music audio source. This is only valid if GameGlobal.PlayMusic() was called at least once.
		/// It is reused by GameGlobal.PlayMusic to play music. </summary>
		public static AudioSource musicSource { get; private set; }

		/// <summary> Instance of GUI/ Screens Manager. </summary>
		public GUIManager uiManager { get; set; }

		/// <summary> Strings data for currently selected language. </summary>
		public StringsAsset stringsData { get; set; }

		/// <summary> Reference to the LoadSave Provider </summary>
		public LoadSaveProviderBase loadSaveProvider { get; private set; }

		/// <summary> Index of active LoadSave Profile under which slots are saved/ loaded. Defaults to 0. </summary>
		private int loadSaveProfileIdx = 0;

		/// <summary> The slot used when calls are made to the LoadSave system. Use SetActiveSaveSlot() to
		///  set the slot. Use positive slot numbers if possible. Slot defaults to '-1' and is reserved to
		///  plyGame's test mode when no slot is specified. The slot is initialized to '0' just after the
		///  splash screens where shown so this will happen if you test the game with plyGame Play button
		///  or during stand-alone build. If you use the Unity play button then the slot will stay -1
		///  until you change it. </summary>
		private int loadSaveSlot = -1;
		private int lastLoadSlot = -1; // the slot last loaded from (-1 = no loading took place or key is reset for new-game)

		/// <summary> This is the main key under which data is saved. It is a combination of the active profile and slot.
		/// Do not change this directly. It is updated when you set the active profile or slot via provided functions. </summary>
		public string loadSaveMainKey { get; private set; }

		// This is set set True when LoadGameSession() is called to indicate to the Get.. functions
		// to not read from the tempKeyStore since this is a proper load.
		public bool isSessionRestore { get; set; }

		// set true when Create() was called and Instance was null. Most likely that user 
		// pressed Unity play button to test a game scene. The Global needs to be 
		// created but Bootstrap needs to skip the whole splash screen process.
		public static bool EditorRunMode = false;

		public string _internalSelectedLang { get; set; }

		private LoadSaveTempKeyStore tempKeyStore = new LoadSaveTempKeyStore();
		private event GeneralCallback LS_SaveEventListeners = null;
		private event GeneralCallback LS_LoadEventListeners = null;
		private event GeneralCallback LS_DeleteEventListeners = null;
		private event GeneralCallback LS_CopyEventListeners = null;

		#endregion
		// ================================================================================================================
		#region system init/ quit

		/// <summary> This is normally called in the Awake() of components that will need GameGlobal.
		///  Needed when designer press Unity play button. </summary>
		public static void Create()
		{
			if (_instance == null && !EditorRunMode)
			{
				Debug.Log(".. auto loading the plyGame Global");
				EditorRunMode = true;
				Application.LoadLevelAdditive("00-bootstrap");
			}
		}

		protected void Awake()
		{
			_instance = this;
			Object.DontDestroyOnLoad(gameObject);

			_internalSelectedLang = null;
			GameObject go;

			// Create the LoadSave Provider
			CreateLoadSaveProvider();

			// Grab a reference to the plyBlox global
			BloxGlobal = plyBloxGlobal.GetInstance(bloxGlobalFab);

			// Create the GUI/ Screen Manager
			GameObject uiGo = (GameObject)Object.Instantiate(uiManagerFab);
			uiGo.name = "ONGUI";
			uiGo.transform.parent = transform;
			uiManager = uiGo.GetComponent<GUIManager>();
			Object.DontDestroyOnLoad(uiGo);

			// Create Bootstrap object to handle loading of GUI assets and take player through various startup screens
			GameObject bootGo = new GameObject("Bootstrap");
			bootGo.AddComponent<Bootstrap>();

			// Init input (define buttons)
			plyInput.Init(gameObject, inputAsset);
			plyInput.Restore();
			inputAsset = null; // done with it, can be cleaned up

			// Instantiate the auto-create prefabs
			for (int i = 0; i < dataAsset.autoCreate.Count; i++)
			{
				if (dataAsset.autoCreate[i] == null) continue;
				go = (GameObject)Object.Instantiate(dataAsset.autoCreate[i]);
				Object.DontDestroyOnLoad(go);
			}

			// Instantiate the designer's auto-create prefabs
			for (int i = 0; i < dataAsset.autoFabs.Count; i++)
			{
				if (dataAsset.autoFabs[i] == null) continue;
				go = (GameObject)Object.Instantiate(dataAsset.autoFabs[i]);
				go.name = dataAsset.autoFabs[i].name;
				Object.DontDestroyOnLoad(go);
			}

			// add the auto components
			for (int i = 0; i < dataAsset.autoComponents.Count; i++)
			{
				if (string.IsNullOrEmpty(dataAsset.autoComponents[i])) continue;
				string[] s = dataAsset.autoComponents[i].Split(';');
				if (s.Length == 2)
				{
					go = GameObject.Find(s[0]);
					if (go != null)
					{
#if UNITY5
						if (null == go.AddComponent(plyReflectionUtil.FindType(s[1])))
#else
						if (null == go.AddComponent(s[1]))
#endif
						{
							Debug.LogWarning(string.Format("[AutoComponent Error] The Component [{0}] could not be added to the GameObject [{1}]", s[1], s[0]));
						}
					}
					else Debug.LogWarning("[AutoComponent Error] The GameObject could not be found: " + s[0]);
				}
				else Debug.LogWarning("[AutoComponent Error] The auto component string was invalid: " + dataAsset.autoComponents[i]);
			}

			// Create audio listener
			if (dataAsset.createDefaultAudioListener)
			{
				go = new GameObject("Audio Listener");
				audioListenerTr = go.transform;
				audioListenerTr.parent = transform;
				audioListener = go.AddComponent<AudioListener>();
				AudioListener.volume = dataAsset.volume[(int)GameGlobal.VolumeType.Main];
			}

			// restore some some settings from saves for default profile
			_instance.LoadSoundVolumeSettings();
			_instance.LoadGFXSettings();
		}

		private void CreateLoadSaveProvider()
		{
			loadSaveProfileIdx = 0;
			loadSaveSlot = -1;
			loadSaveMainKey = loadSaveProfileIdx + "." + loadSaveSlot;

			if (dataAsset.loadSaveProviderFab != null)
			{
				GameObject go = (GameObject)Instantiate(dataAsset.loadSaveProviderFab);
				if (go != null) loadSaveProvider = go.GetComponent<LoadSaveProviderBase>();
			}

			if (loadSaveProvider == null)
			{
				GameObject go = new GameObject();
				loadSaveProvider = go.AddComponent<LoadSave_PlayerPrefs>();
			}

			loadSaveProvider.gameObject.name = "LoadSave Provider";
			loadSaveProvider.transform.parent = transform;
			Object.DontDestroyOnLoad(loadSaveProvider.gameObject);

			loadSaveProvider.Load();
		}

		/// <summary> Loads the Custom and Loading Screens. SelectedLanguage must be set. </summary>
		public void LoadLanguageDependentData()
		{
			// load strings
			Languages.Instance.SetActiveLanguage(_internalSelectedLang);

			// load the load screens
			if (loadScrAsset != null)
			{
				uiManager.minLoadTime = loadScrAsset.minLoadTime;
				uiManager.clickToContinue = loadScrAsset.clickToContinue;
				for (int i = 0; i < loadScrAsset.screens.Count; i++)
				{
					GUIScreen scr = GUIScreen.CreateInstance(loadScrAsset.screens[i]);
					uiManager.AddLoadScreen(scr);
				}
			}

			// load the custom screens
			if (custScrAsset != null)
			{
				for (int i = 0; i < custScrAsset.screens.Count; i++)
				{
					GUIScreen scr = GUIScreen.CreateInstance(custScrAsset.screens[i]);
					uiManager.AddCustomScreen(scr);
				}
			}

			uiManager.loadText = loadScrAsset.loadText;
			uiManager.screensSystemReady = true;
			
			// done with the screens assets
			loadScrAsset = null;
			custScrAsset = null;
		}

		/// <summary> Get reference to an asset saved in dataAsset.assets list </summary>
		public ScriptableObject GetAsset<T>()
		{
			for (int i = 0; i < dataAsset.assets.Count; i++)
			{
				if (dataAsset.assets[i] == null) continue; // could happen
				if (typeof(T).IsAssignableFrom(dataAsset.assets[i].GetType()))
				{
					return dataAsset.assets[i];
				}
			}
			return null;
		}

		/// <summary> Set null and remove and asset in dataAsset.assets list </summary>
		public void RemoveAsset(ScriptableObject asset)
		{
			if (asset == null) return;
			int idx = dataAsset.assets.IndexOf(asset);
			if (idx >= 0)
			{
				dataAsset.assets[idx] = null;
				dataAsset.assets.RemoveAt(idx);
				Resources.UnloadUnusedAssets();
			}
		}

		#endregion
		// ================================================================================================================
		#region system

		protected void LateUpdate()
		{
			if (audioListenerTr != null && audioListenerFollowTarget != null)
			{
				audioListenerTr.position = audioListenerFollowTarget.position;
			}
		}

		protected void OnApplicationQuit()
		{
			_instance = null;
			if (loadSaveProvider != null)
			{
				loadSaveProvider.Save();
			}
		}

		protected void OnLevelWasLoaded(int level)
		{
			if (_instance != null) _instance.LoadCreate(level);
		}

		#endregion
		// ================================================================================================================
		#region Saving & Loading

		/// <summary> Registers a callbacks to call when 
		/// save: called when the listener should save data,
		/// load: called when the listener should load data,
		/// delete: called when the listener should delete data,
		/// copy: called when the listener should copy data from old load slot to current save slot 
		/// 
		/// args send to all are:
		/// args[0] = Profile IDX
		/// args[1] = Active Slot
		/// args[2] = [only for copy] Slot that data was last loaded from and should be copied from to active slot
		/// 
		/// Note. a main key is normally build from: (ProfileIDX + "." + ActiveSlot)
		/// </summary>
		public static void RegisterLoadSaveListener(GeneralCallback save, GeneralCallback load, GeneralCallback delete, GeneralCallback copy)
		{
			if (_instance == null) return;
			if (save != null) _instance.LS_SaveEventListeners += save;
			if (load != null) _instance.LS_LoadEventListeners += load;
			if (delete != null) _instance.LS_DeleteEventListeners += delete;
			if (copy != null) _instance.LS_CopyEventListeners += copy;
		}

		/// <summary> Remove a save, load and delete listener callbacks. 
		/// profile and slot is passed as args if you need them.
		/// int profile = (int)args[0];
		/// int slot = (int)args[1];
		/// </summary>
		public static void RemoveLoadSaveListener(GeneralCallback save, GeneralCallback load, GeneralCallback delete, GeneralCallback copy)
		{
			if (_instance == null) return;
			if (save != null) _instance.LS_SaveEventListeners -= save;
			if (load != null) _instance.LS_LoadEventListeners -= load;
			if (delete != null) _instance.LS_DeleteEventListeners -= delete;
			if (copy != null) _instance.LS_CopyEventListeners -= copy;
		}

		// ---------------------------------------------------------------------------------------------

		/// <summary> Set the profile and make it active. Will return the index of the new profile. 
		/// return -1 on error. Profile indexes starts at 0. Sets active profile idx to that of the
		/// newly added profile. Will not create new profile but rather return index of existing 
		/// if one of same name exist. </summary>
		public static int SetActiveProfile(string name)
		{
			if (_instance == null) return -1;
			if (string.IsNullOrEmpty(name)) return -1;
			int profileCount = _instance.loadSaveProvider.GetInt("profileCount", 0);

			// first check if exiting
			for (int i = 0; i < profileCount; i++)
			{
				string n = _instance.loadSaveProvider.GetString("profile." + i, "");
				if (!string.IsNullOrEmpty(n))
				{
					if (name.Equals(n)) return i;
				}
			}

			// not found, add
			_instance.loadSaveProvider.SetInt("profileCount", profileCount + 1);	// one more profile added
			_instance.loadSaveProvider.SetString("profile." + profileCount, name);	// save name of new profile
			SetActiveProfile(profileCount);
			return profileCount;
		}

		/// <summary> Sets the active profile to one with specified index. Does not check if index is valid. 
		/// Will reset active slot to slot 0.</summary>
		public static void SetActiveProfile(int profileIndex)
		{
			if (_instance == null) return;
			_instance.loadSaveProfileIdx = profileIndex;
			SetActiveSaveSlot(0);
			_instance.LoadSoundVolumeSettings();
			_instance.LoadGFXSettings();
		}

		/// <summary> Return the profile count (number of profiles that are saved) </summary>
		public static int GetSavedProfileCount()
		{
			return _instance.loadSaveProvider.GetInt("profileCount", 0);
		}

		/// <summary> Return the name of a saved profile. Return empty string if profile number not correct. </summary>
		public static string GetProfileName(int idx)
		{
			return _instance.loadSaveProvider.GetString("profile." + idx, "");
		}

		// ---------------------------------------------------------------------------------------------

		/// <summary> Set the slot which will be used when calls are made to the LoadSave system. Try to
		///  keep to positive slot numbers if possible. Slot defaults to '-1' and is reserved to plyGame's
		///  test mode when no slot is specified. </summary>
		public static void SetActiveSaveSlot(int slot)
		{
			if (_instance == null) return;
			_instance.loadSaveSlot = slot;
			_instance.loadSaveMainKey = _instance.loadSaveProfileIdx + "." + _instance.loadSaveSlot;

			// make sure the slot is saved in the list of known slots (under active profile)
			bool needToAdd = true;
			string s = _instance.loadSaveProvider.GetString("profile." + _instance.loadSaveProfileIdx + ".slots", "");
			if (!string.IsNullOrEmpty(s))
			{
				if (s.Contains(slot.ToString() + (char)31)) needToAdd = false;
			}

			if (needToAdd)
			{
				s += slot.ToString() + (char)31;
				_instance.loadSaveProvider.SetString("profile." + _instance.loadSaveProfileIdx + ".slots", s);
			}
		}

		/// <summary> Return the number of slots saved in the active LoadSave Profile. </summary>
		public static int GetSavedSlotCount()
		{
			int count = 0;
			string s = _instance.loadSaveProvider.GetString("profile." + _instance.loadSaveProfileIdx + ".slots", "");
			if (!string.IsNullOrEmpty(s))
			{	// need to run through and check as there might be "empty" entries
				string[] slots = s.Split((char)31);
				for (int i = 0; i < slots.Length; i++)
				{
					if (string.IsNullOrEmpty(slots[i])) continue;
					if (string.IsNullOrEmpty(GetSlotDateTime(int.Parse(slots[i])))) continue; // no date means this is not actually saved yet
					count++;
				}
			}
			return count;
		}

		/// <summary> Return the slot number of a saved slot. The index should be 
		/// within 0 and GetSavedSlotCount. Return -1 if not found. </summary>
		public static int GetSavedSlotNumber(int index)
		{
			string s = _instance.loadSaveProvider.GetString("profile." + _instance.loadSaveProfileIdx + ".slots", "");
			if (!string.IsNullOrEmpty(s))
			{	// need to run through and check as there might be "empty" entries
				int count = 0;
				string[] slots = s.Split((char)31);
				for (int i = 0; i < slots.Length; i++)
				{
					if (string.IsNullOrEmpty(slots[i])) continue;
					if (count == index) return int.Parse(slots[i]);
					count++;
				}
			}
			return -1;
		}

		/// <summary> Return the Date and Time the slot was last saved. Return empty string if not yet saved. </summary>
		public static string GetActiveSlotDateTime()
		{
			return _instance.loadSaveProvider.GetString(_instance.loadSaveMainKey + ".dt", "");
		}

		/// <summary> Return the Date and Time the slot was last saved. Return empty string if not yet saved. </summary>
		public static string GetSlotDateTime(int slot)
		{
			return _instance.loadSaveProvider.GetString(_instance.loadSaveProfileIdx + "." + slot + ".dt", "");
		}

		/// <summary> Should be called when the player starts a "new game". </summary>
		public static void ResetLastLoadSlot()
		{
			if (!_instance) return;
			_instance.tempKeyStore.ClearData();
			_instance.lastLoadSlot = -1;
		}

		// ---------------------------------------------------------------------------------------------

		/// <summary> Saves the game state to active slot. Keys from Temp Store and active scene's
		///  persistent marked objects are stored. The default slot, '-1' will be prevented from being
		///  saved as it is used by plyGame when scenes are tested. </summary>
		public static void SaveGameSession()
		{
			if (_instance == null) return;
			if (_instance.loadSaveSlot == -1) return; // not allowed to actually save to disc

			// copy all saved data, from whatever slot was last loaded, to the slot being saved
			_instance.ClearSlotAndCopyLastLoad();

			// set 'last loaded' slot to one saved to. this is so this slot do not get corrupted with old data
			// if saved to again or a future slot to totally different slot will include data from this save
			_instance.lastLoadSlot = _instance.loadSaveSlot;

			// save the slot session data
			_instance.loadSaveProvider.SetInt(_instance.loadSaveMainKey + ".scene", Application.loadedLevel);
			_instance.loadSaveProvider.SetString(_instance.loadSaveMainKey + ".dt", System.DateTime.Now.ToString());

			// tell all PersistenceProviders to save their data (to temp store)
			if (_instance.LS_SaveEventListeners != null) _instance.LS_SaveEventListeners(null, new object[] { _instance.loadSaveProfileIdx, _instance.loadSaveSlot });

			// now use LoadSave provider to store the keys and values and clear temp store
			_instance.tempKeyStore.PersistData(_instance.loadSaveMainKey, _instance.loadSaveProvider);

			// Save the plyBlox Global Variables.
			string var_data = BloxGlobal.EncodeVariables(false);
			_instance.loadSaveProvider.SetString(_instance.loadSaveMainKey + ".gvar", var_data);

			//if (BloxGlobal.RuntimeVars.Count > 0)
			//{
			//	string globalVarsKey = _instance.loadSaveMainKey + ".gvar";
			//	string key;
			//	string allVarNames = "";
			//	int count = 0;
			//	foreach (plyVar v in BloxGlobal.RuntimeVars.Values)
			//	{
			//		key = globalVarsKey + count.ToString();
			//		if (_instance.SaveBloxVar(key, v))
			//		{
			//			allVarNames += v.name + (char)31;
			//			count++;
			//		}
			//	}
			//	_instance.loadSaveProvider.SetString(globalVarsKey, allVarNames);
			//}

			// finally save data properly
			_instance.loadSaveProvider.Save();
		}

		private void ClearSlotAndCopyLastLoad()
		{
			// if slot loading from is same as one being saved to then no need to continue with this
			if (lastLoadSlot == -1) return;
			if (lastLoadSlot == loadSaveSlot) return;

			// data in destination slot needs to be cleared
			DeleteDataInActiveSlot();

			// let listeners do a data copy as needed
			if (_instance.LS_CopyEventListeners != null) _instance.LS_CopyEventListeners(null, new object[] { _instance.loadSaveProfileIdx, _instance.loadSaveSlot, _instance.lastLoadSlot });

			// copy data from last slot loaded to active slot
			string oldMainKey = loadSaveProfileIdx + "." + lastLoadSlot;

			// copy the various saved keys
			string k = loadSaveProvider.GetString(oldMainKey + ".keys", "");
			loadSaveProvider.SetString(loadSaveMainKey + ".keys", k);
			if (!string.IsNullOrEmpty(k))
			{
				string[] keys = k.Split((char)31);
				for (int i = 0; i < keys.Length; i++)
				{
					if (false == loadSaveProvider.HasKey(oldMainKey + "." + keys[i])) continue;
					string d = loadSaveProvider.GetString(oldMainKey + "." + keys[i], "");
					loadSaveProvider.SetString(loadSaveMainKey + "." + keys[i], d);
				}
			}

			// copy global vars
			k = loadSaveProvider.GetString(oldMainKey + ".gvar", "");
			loadSaveProvider.SetString(loadSaveMainKey + ".gvar", k);
			if (!string.IsNullOrEmpty(k))
			{
				string[] keys = k.Split((char)31);
				for (int i = 0; i < keys.Length; i++)
				{
					if (false == loadSaveProvider.HasKey(oldMainKey + ".gvar" + i)) continue;
					string d = loadSaveProvider.GetString(oldMainKey + ".gvar" + i, "");
					loadSaveProvider.SetString(loadSaveMainKey + ".gvar" + i, d);
				}
			}

			// copy the CreateLoad keys
			for (int i = 0; i < Application.levelCount; i++)
			{
				if (false == loadSaveProvider.HasKey(oldMainKey  + ".clk" + i)) continue;
				string d = loadSaveProvider.GetString(oldMainKey + ".clk" + i, "");
				loadSaveProvider.SetString(loadSaveMainKey + ".clk" + i, d);
			}

		}

		/// <summary> Loads game state from active slot. The last active scene saved for this slot will be
		///  restored and all persistent-marked objects loaded from save. The default slot, '-1' will be
		///  prevented from being loaded as it is used by plyGame when scenes are tested. </summary>
		public static void LoadGameSession()
		{
			if (_instance == null) return;
			if (_instance.loadSaveSlot == -1) return; // not allowed to actually load

			// set isSessionRestore = true to indicate to set/get that this is a proper load
			// and tempKeyStore should be ignored. this flag will be set false in OnAfterLevelLoaded
			// I can't reset the flags right after the LoadLevel() below since the Start and thus
			// Load on objects will not have been called by then.
			_instance.isSessionRestore = true;
			_instance.tempKeyStore.ClearData();

			// Check if there is a scene saved for current slot. if not then this slot is not a valid save.
			int sceneNumber = _instance.loadSaveProvider.GetInt(_instance.loadSaveMainKey + ".scene", -1);
			if (sceneNumber < 0)
			{
				Debug.LogError("Loading failed. The LoadSave Slot [" + _instance.loadSaveMainKey + "] did not contain a valid scene number.");
				_instance.isSessionRestore = false;
				return;
			}

			_instance.lastLoadSlot = _instance.loadSaveSlot;

			// Load the plyBlox Global Variables
			string var_data = _instance.loadSaveProvider.GetString(_instance.loadSaveMainKey + ".gvar", "");
			BloxGlobal.DecodeVariables(var_data);

			//string globalVarsKey = _instance.loadSaveMainKey + ".gvar";
			//string keys_data = _instance.loadSaveProvider.GetString(globalVarsKey, "");
			//string[] keys = keys_data.Split((char)31);
			//string key;

			//for (int i = 0; i < keys.Length; i++)
			//{
			//	if (string.IsNullOrEmpty(keys[i])) continue;
			//	key = globalVarsKey + i.ToString();
			//	_instance.LoadBloxVar(key, keys[i]);
			//}

			// Call the load callbacks
			if (_instance.LS_LoadEventListeners != null) _instance.LS_LoadEventListeners(null, new object[] { _instance.loadSaveProfileIdx, _instance.loadSaveSlot});

			// Load the saved scene
			Application.LoadLevel(sceneNumber);
			_instance.StartCoroutine(OnAfterSessionLevelLoaded());
		}

		// ---------------------------------------------------------------------------------------------
		
		//private bool SaveBloxVar(string key, plyVar v)
		//{	// returns true if variable was actually saved (does not save unsupported types)
		//	switch (v.type)
		//	{
		//		case VariableType.Bool:
		//		{
		//			loadSaveProvider.SetString(key, "0" + (char)30 + (v.boolValue ? "1" : "0"));
		//		} return true;
		//		case VariableType.Int:
		//		{
		//			loadSaveProvider.SetString(key, "1" + (char)30 + v.intValue.ToString());
		//		} return true;
		//		case VariableType.Float:
		//		{
		//			loadSaveProvider.SetString(key, "2" + (char)30 + v.floatValue.ToString());
		//		} return true;
		//		case VariableType.String:
		//		{
		//			loadSaveProvider.SetString(key, "3" + (char)30 + v.stringValue);
		//		} return true;
		//		case VariableType.Vector2:
		//		{
		//			loadSaveProvider.SetString(key, "4" + (char)30 + v.vect2Value.x + "|" + v.vect2Value.y);
		//		} return true;
		//		case VariableType.Vector3:
		//		{
		//			loadSaveProvider.SetString(key, "5" + (char)30 + v.vect3Value.x + "|" + v.vect3Value.y + "|" + v.vect3Value.z);
		//		} return true;
		//		case VariableType.Color:
		//		{
		//			loadSaveProvider.SetString(key, "6" + (char)30 + v.colorValue.r + "|" + v.colorValue.g + "|" + v.colorValue.b + "|" + v.colorValue.a);
		//		} return true;
		//		case VariableType.Rect:
		//		{
		//			loadSaveProvider.SetString(key, "7" + (char)30 + v.rectValue.x + "|" + v.rectValue.y + "|" + v.rectValue.width + "|" + v.rectValue.height);
		//		} return true;
		//	}
		//	return false;
		//}

		//private void LoadBloxVar(string key, string name)
		//{
		//	if (!loadSaveProvider.HasKey(key)) return;
		//	string data_s = loadSaveProvider.GetString(key, null);
		//	if (string.IsNullOrEmpty(data_s)) return;
		//	string[] data = data_s.Split((char)30);
		//	if (data.Length < 2) return;

		//	switch (data[0])
		//	{
		//		case "0":
		//		{
		//			bool v = data[1] == "1";
		//			BloxGlobal.SetVarValue(name, v);
		//		} break;
		//		case "1": 
		//		{
		//			int v = int.Parse(data[1]);
		//			BloxGlobal.SetVarValue(name, v);
		//		} break;
		//		case "2": 
		//		{ 
		//			float v = float.Parse(data[1]);
		//			BloxGlobal.SetVarValue(name, v);
		//		} break;
		//		case "3": 
		//		{ 
		//			BloxGlobal.SetVarValue(name, data[1]);
		//		} break;
		//		case "4": 
		//		{ 
		//			string[] d = data[1].Split('|');
		//			Vector2 v = new Vector2(float.Parse(d[0]), float.Parse(d[1]));
		//			BloxGlobal.SetVarValue(name, v);
		//		} break;
		//		case "5": 
		//		{ 
		//			string[] d = data[1].Split('|');
		//			Vector3 v = new Vector3(float.Parse(d[0]), float.Parse(d[1]), float.Parse(d[2]));
		//			BloxGlobal.SetVarValue(name, v);
		//		} break;
		//		case "6": 
		//		{ 
		//			string[] d = data[1].Split('|');
		//			Color v = new Color(float.Parse(d[0]), float.Parse(d[1]), float.Parse(d[2]), float.Parse(d[3]));
		//			BloxGlobal.SetVarValue(name, v);
		//		} break;
		//		case "7":
		//		{ 
		//			string[] d = data[1].Split('|');
		//			Rect v = new Rect(float.Parse(d[0]), float.Parse(d[1]), float.Parse(d[2]), float.Parse(d[3]));
		//			BloxGlobal.SetVarValue(name, v);
		//		}  break;
		//	}

		//	//if (!loadSaveProvider.HasKey(key)) return;
		//	//int type = loadSaveProvider.GetInt(key + ".t", -1);
		//	//if (type == -1) return;

		//	//switch (type)
		//	//{
		//	//	case 0: BloxGlobal.SetVarValue(name, loadSaveProvider.GetBool(key, false)); break;
		//	//	case 1: BloxGlobal.SetVarValue(name, loadSaveProvider.GetInt(key, 0)); break;
		//	//	case 2: BloxGlobal.SetVarValue(name, loadSaveProvider.GetFloat(key, 0f)); break;
		//	//	case 3: BloxGlobal.SetVarValue(name, loadSaveProvider.GetString(key, "")); break;
		//	//	case 4: BloxGlobal.SetVarValue(name, loadSaveProvider.GetVector2(key, Vector2.zero)); break;
		//	//	case 5: BloxGlobal.SetVarValue(name, loadSaveProvider.GetVector3(key, Vector3.zero)); break;
		//	//	case 6: BloxGlobal.SetVarValue(name, (Color)(loadSaveProvider.GetVector4(key, Color.white))); break;
		//	//	case 7: BloxGlobal.SetVarValue(name, loadSaveProvider.GetRect(key, new Rect())); break;
		//	//}
		//}

		private static IEnumerator OnAfterSessionLevelLoaded()
		{
			// wait two frames so that Destroy is called on all objects - which causes them
			// to make a call to Save. The save is ignored cause isSessionRestore is
			// still set. After one frame, Load will be called and will not load from
			// tempKeyStore cause the flag is still set. After all this the flag
			// will be set false and tempKeyStore cleared from any junk data
			yield return null;
			yield return null;

			// wait additional frame for things that gets instantiated in plyBlox "State Enter" Event
			// this will only work for "state enter" of objects that exist in scene when it was
			// loaded and not the event for those created by this call
			yield return null;

			// continue
			if (_instance != null)
			{
				//_instance.LoadCreate(); // moved this to OnLevelWasLoaded()
				_instance.tempKeyStore.ClearData();
				_instance.isSessionRestore = false;
			}
		}

		private void LoadCreate(int level)
		{
			//string s = loadSaveProvider.GetString(loadSaveMainKey + ".clk" + Application.loadedLevel, "");
			string s = loadSaveProvider.GetString(loadSaveMainKey + ".clk" + level, "");
			s = _instance.tempKeyStore.GetMergedCreateLoadKeys(Application.loadedLevel, s);
			string[] keys = s.Split((char)31); s = null;
			for (int i = 0; i < keys.Length; i++)
			{
				if (string.IsNullOrEmpty(keys[i])) continue;
				
				string[] kv = keys[i].Split((char)30); // 0: type, 1: def.ident
				if (kv.Length < 2)
				{	// just a sanity check
					Debug.LogWarning("LoadSave LoadCreate failed to recreate an object since key entry was invalid: " + keys[i]);
					continue;
				}
				
				System.Type t = plyReflectionUtil.FindType(kv[0]);
				if (t == null)
				{	// just a sanity check
					Debug.LogWarning("LoadSave LoadCreate failed to recreate an object since type was not found: " + keys[i]);
					continue;
				}

				plyReflectionUtil.ExecuteStatic(t, "LoadCreate", kv[1]);
 			}
		}

		// ---------------------------------------------------------------------------------------------

		/// <summary> Delete all saved data. </summary>
		public static void DeleteAllSaveData()
		{
			if (_instance == null) return;
			_instance.tempKeyStore.ClearData();
			_instance.loadSaveProvider.DeleteAll();
		}

		/// <summary> Delete all data of a profile. This should not be called during active session as
		/// it will also remove all temporarily saved data and corrupt an active game session.
		/// Note: The active profile will be reset to 0 </summary>
		public static void DeleteProfile(int idx)
		{
			if (_instance == null) return;
			_instance.tempKeyStore.ClearData();

			// delete profile's slots
			SetActiveProfile(idx);
			DeleteAllSlotsInActiveProfile();

			// update profiles count
			int profileCount = _instance.loadSaveProvider.GetInt("profileCount", 0);
			profileCount--; if (profileCount < 0) profileCount = 0;
			_instance.loadSaveProvider.SetInt("profileCount", profileCount);

			// get rid of profile data
			_instance.loadSaveProvider.DeleteKey("profile." + idx);				// profile name
			_instance.loadSaveProvider.DeleteKey("profile." + idx + ".slots");	// list of slots that belongs to profile

			// reset active profile to 0
			SetActiveProfile(0);
		}

		/// <summary> Delete all the slots (and their keys and values) from the specified profile. </summary>
		public static void DeleteAllSlotsInActiveProfile()
		{
			if (_instance == null) return;
			_instance.tempKeyStore.ClearData();

			string s = _instance.loadSaveProvider.GetString("profile." + _instance.loadSaveProfileIdx + ".slots", null);
			_instance.loadSaveProvider.DeleteKey("profile." + _instance.loadSaveProfileIdx + ".slots");

			if (s != null)
			{
				string[] slots = s.Split((char)31);
				for (int i = 0; i < slots.Length; i++)
				{
					if (string.IsNullOrEmpty(slots[i])) continue;
					_instance.loadSaveMainKey = _instance.loadSaveProfileIdx + "." + slots[i];
					DeleteAllDataInActiveSlot();
				}
			}

			// restore the profile and slot in useful state since everything was just deleted
			SetActiveProfile(_instance.loadSaveProfileIdx);
		}

		/// <summary> Delete all the keys and values from the specified slot. </summary>
		public static void DeleteAllDataInActiveSlot()
		{
			if (_instance == null) return;
			_instance.tempKeyStore.ClearData();
			_instance.DeleteDataInActiveSlot();
		}

		private void DeleteDataInActiveSlot()
		{
			// first check if there is data for the slot
			//int sceneNumber = loadSaveProvider.GetInt(loadSaveMainKey + ".scene", -1);
			//if (sceneNumber == -1) return;

			// call listeners to delete their data
			if (LS_DeleteEventListeners != null)
			{
				LS_DeleteEventListeners(null, new object[] { loadSaveProfileIdx, loadSaveSlot });
			}

			// get keys to delete
			string k = loadSaveProvider.GetString(loadSaveMainKey + ".keys", null);
			string g = loadSaveProvider.GetString(loadSaveMainKey + ".gvar", null);

			// delete keys
			loadSaveProvider.DeleteKey(loadSaveMainKey + ".scene");
			loadSaveProvider.DeleteKey(loadSaveMainKey + ".dt");
			loadSaveProvider.DeleteKey(loadSaveMainKey + ".keys");
			loadSaveProvider.DeleteKey(loadSaveMainKey + ".gvar");

			if (k != null)
			{
				string[] keys = k.Split((char)31);
				for (int i = 0; i < keys.Length; i++)
				{
					if (string.IsNullOrEmpty(keys[i])) continue;
					loadSaveProvider.DeleteKey(loadSaveMainKey + "." + keys[i]);
				}
			}

			// delete global vars
			if (g != null)
			{
				string[] keys = g.Split((char)31);
				for (int i = 0; i < keys.Length; i++)
				{
					loadSaveProvider.DeleteKey(loadSaveMainKey + ".gvar" + i);
				}
			}

			// delete the CreateLoad keys
			for (int i = 0; i < Application.levelCount; i++)
			{
				loadSaveProvider.DeleteKey(loadSaveMainKey + ".clk" + i);
			}
		}

		// ---------------------------------------------------------------------------------------------

		/// <summary> Delete a key from temp store key and permanently when SaveGameSession() is called. </summary>
		public static void DeleteKey(string key)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.DeleteKey(Application.loadedLevel + "." + key);
			_instance.tempKeyStore.DeleteKey(key);
		}

		/// <summary> Add the key of an object that was added to scene at runtime and knows how to and
		/// would like to recreate itself in the scene when the player enters the scene again next time. </summary>
		public static void AddCreateLoadKey(System.Type objectType, string key)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			key = objectType.Name + ((char)30) + key;
			_instance.tempKeyStore.AddCreateLoadKey(Application.loadedLevel, key);
		}

		/// <summary> Remove a key that was previously added via AddCreateLoadKey </summary>
		public static void RemoveCreateLoadKey(System.Type objectType, string key)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			key = objectType.Name + ((char)30) + key;
			_instance.tempKeyStore.RemoveCreateLoadKey(Application.loadedLevel, key);
		}

		// Note to self: These Set functions will not append the SaveSlot yet since that is technically unknown
		// The slot id will be appended to each key from the temp store once the SaveGameSession() call is made

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetStringKey(string key, string value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetString(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetString(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetIntKey(string key, int value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetInt(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetInt(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetFloatKey(string key, float value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetFloat(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetFloat(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetBoolKey(string key, bool value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetBool(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetBool(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetVector2Key(string key, Vector2 value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetVector2(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetVector2(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetVector3Key(string key, Vector3 value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetVector3(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetVector3(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetVector4Key(string key, Vector4 value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetVector4(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetVector4(key, value);
		}

		/// <summary> Sets a value to the given key. This will be saved when SaveGameSession() is called. </summary>
		public static void SetRectKey(string key, Rect value)
		{
			if (_instance == null) return;
			if (_instance.isSessionRestore) return;
			//_instance.tempKeyStore.SetRect(Application.loadedLevel + "." + key, value);
			_instance.tempKeyStore.SetRect(key, value);
		}

		// Note to Self: These Get functions will first check in the Temp Store for the key and if not found it will
		// append the current slot id and read from that, hoping slot id is valid by the time of call.

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static string GetStringKey(string key, string defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.stringKeys.ContainsKey(key)) return _instance.tempKeyStore.stringKeys[key];
			return _instance.loadSaveProvider.GetString(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static int GetIntKey(string key, int defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.intKeys.ContainsKey(key)) return _instance.tempKeyStore.intKeys[key];
			return _instance.loadSaveProvider.GetInt(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static float GetFloatKey(string key, float defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.floatKeys.ContainsKey(key)) return _instance.tempKeyStore.floatKeys[key];
			return _instance.loadSaveProvider.GetFloat(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static bool GetBoolKey(string key, bool defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.boolKeys.ContainsKey(key)) return _instance.tempKeyStore.boolKeys[key];
			return _instance.loadSaveProvider.GetBool(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static Vector2 GetVector2Key(string key, Vector2 defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.vector2Keys.ContainsKey(key)) return _instance.tempKeyStore.vector2Keys[key];
			return _instance.loadSaveProvider.GetVector2(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static Vector3 GetVector3Key(string key, Vector3 defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.vector3Keys.ContainsKey(key)) return _instance.tempKeyStore.vector3Keys[key];
			return _instance.loadSaveProvider.GetVector3(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static Vector4 GetVector4Key(string key, Vector4 defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.vector4Keys.ContainsKey(key)) return _instance.tempKeyStore.vector4Keys[key];
			return _instance.loadSaveProvider.GetVector4(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		/// <summary> Read a value from the given key. The current Save Slot is appended to the key. The
		///  LoadSave provider is checked if the key is not found in the temp store. defaultVal is
		///  returned if the key was not found in either location. </summary>
		public static Rect GetRectKey(string key, Rect defaultVal)
		{
			if (_instance == null) return defaultVal;
			//key = Application.loadedLevel + "." + key;
			if (!_instance.isSessionRestore)
				if (_instance.tempKeyStore.rectKeys.ContainsKey(key)) return _instance.tempKeyStore.rectKeys[key];
			return _instance.loadSaveProvider.GetRect(_instance.loadSaveMainKey + "." + key, defaultVal);
		}

		#endregion
		// ================================================================================================================
		#region Resolution

		private int[] selectedRes = { 0, 0 };

		public void ChangeSelectedResolution(bool increase)
		{
			if (Screen.resolutions.Length == 0) return;

			if (selectedRes[0] == 0)
			{
				selectedRes[0] = Screen.width;
				selectedRes[1] = Screen.height;
			}

			int idx = 0;
			for (int i = 0; i < Screen.resolutions.Length; i++)
			{
				if (Screen.resolutions[i].width == selectedRes[0] && Screen.resolutions[i].height == selectedRes[1])
				{
					idx = i; break;
				}
			}

			if (increase) idx++; else idx--;
			if (idx < 0) idx = 0;
			if (idx >= Screen.resolutions.Length) idx = Screen.resolutions.Length - 1;

			selectedRes[0] = Screen.resolutions[idx].width;
			selectedRes[1] = Screen.resolutions[idx].height;
		}

		public void ApplySelectedResolution()
		{
			if (selectedRes[0] == 0)
			{
				selectedRes[0] = Screen.width;
				selectedRes[1] = Screen.height;
			} 
			Screen.SetResolution(selectedRes[0], selectedRes[1], Screen.fullScreen);
		}

		public string GetSelectedResolution()
		{
			if (selectedRes[0] == 0)
			{
				selectedRes[0] = Screen.width;
				selectedRes[1] = Screen.height;
			} 
			return selectedRes[0] + "x" + selectedRes[1];
		}

		public void SafeGFXSettings()
		{
			loadSaveProvider.SetBool(_instance.loadSaveProfileIdx + ".fullscr", Screen.fullScreen);
			loadSaveProvider.SetInt(_instance.loadSaveProfileIdx + ".res.w", selectedRes[0]);
			loadSaveProvider.SetInt(_instance.loadSaveProfileIdx + ".res.h", selectedRes[1]);
			loadSaveProvider.SetInt(_instance.loadSaveProfileIdx + ".gfx", QualitySettings.GetQualityLevel());
		}

		public void LoadGFXSettings()
		{
			bool fullscreen = loadSaveProvider.GetBool(_instance.loadSaveProfileIdx + ".fullscr", Screen.fullScreen);
			selectedRes[0] = loadSaveProvider.GetInt(_instance.loadSaveProfileIdx + ".res.w", Screen.width);
			selectedRes[1] = loadSaveProvider.GetInt(_instance.loadSaveProfileIdx + ".res.h", Screen.height);
			int q = loadSaveProvider.GetInt(_instance.loadSaveProfileIdx + ".gfx", QualitySettings.GetQualityLevel());

			Screen.SetResolution(selectedRes[0], selectedRes[1], fullscreen);
			QualitySettings.SetQualityLevel(q, true);
		}

		#endregion
		// ================================================================================================================
		#region Music and Sound

		/// <summary> Force volume update on listener (main) and all audio updaters. </summary>
		public void UpdateAudioVolumes()
		{
			AudioListener.volume = dataAsset.volume[(int)GameGlobal.VolumeType.Main];
			Component[] c = GameObject.FindObjectsOfType<SoundVolumeUpdater>();
			for (int i = 0; i < c.Length; i++) ((SoundVolumeUpdater)c[i]).UpdateVolume();
		}

		/// <summary> Force volume update on listener (main) and all audio updaters. 
		/// And SAVE the audio volume settings. </summary>
		public void ApplySoundVolumeChanges()
		{
			UpdateAudioVolumes();
			string data = "";
			for (int i = 0; i < 10; i++) data += GameGlobal.Instance.dataAsset.volume[i].ToString() + (char)31;
			loadSaveProvider.SetString(_instance.loadSaveProfileIdx + ".sound", data);
		}

		/// <summary> Force volume update on listener (main) and all audio updaters
		/// after loading audio volume settings </summary>
		public void LoadSoundVolumeSettings()
		{
			string data = loadSaveProvider.GetString(_instance.loadSaveProfileIdx + ".sound", null);
			if (!string.IsNullOrEmpty(data))
			{
				string[] s = data.Split((char)31);
				if (s.Length >= 10)
				{
					for (int i = 0; i < 10; i++) float.TryParse(s[i], out GameGlobal.Instance.dataAsset.volume[i]);
					UpdateAudioVolumes();
				}
			}
		}

		public float GetSoundVolume(GameGlobal.VolumeType type)
		{
			return dataAsset.volume[(int)type];
		}

		public void ChangeSoundVolumeBy(GameGlobal.VolumeType type, int amount)
		{
			float v = amount + (dataAsset.volume[(int)type] * 100f);
			dataAsset.volume[(int)type] = Mathf.Clamp01(v / 100f);

			if (type == VolumeType.Main)
			{
				AudioListener.volume = dataAsset.volume[(int)VolumeType.Main];
			}

			else if (type == VolumeType.Music)
			{
				if (musicSource != null) musicSource.volume = dataAsset.volume[(int)VolumeType.Music];
			}
		}

		public void PlayMusic(AudioClip music, bool onlyIfNonePlaying)
		{
			if (musicSource == null)
			{
				musicSource = gameObject.AddComponent<AudioSource>();
				musicSource.playOnAwake = false;
				musicSource.bypassEffects = true;
				musicSource.bypassListenerEffects = true;
				musicSource.bypassReverbZones = true;
				musicSource.loop = true;
			}
			else if (onlyIfNonePlaying)
			{
				if (musicSource.isPlaying)
				{
					if (musicSource.clip == music) return;
				}
			}

			if (music == null)
			{
				Debug.LogError("You did not specify any music clip to play.");
				return;
			}

			musicSource.Stop();
			musicSource.clip = music;
			musicSource.mute = false;
			musicSource.volume = dataAsset.volume[(int)GameGlobal.VolumeType.Music];
			musicSource.Play();
		}

		public void StopMusic()
		{
			if (musicSource == null) return;
			musicSource.Stop();
		}

		/// <summary> Set the audio listener to follow the GameObject. Set null to stop following and move 
		/// audio listener back to world 0x0x0. Only works on plyGame's default audio listener if it
		/// was left to be created by plyGame. </summary>
		public void SetAudioListenerFollow(GameObject go)
		{
			if (audioListener == null) return;
			if (go == null)
			{
				audioListenerFollowTarget = null;
				audioListenerTr.position = Vector3.zero;
			}
			else audioListenerFollowTarget = go.transform;
		}

		#endregion
		// ================================================================================================================
	}
}