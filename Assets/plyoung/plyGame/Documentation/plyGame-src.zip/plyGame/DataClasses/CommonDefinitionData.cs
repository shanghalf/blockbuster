﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary>
	/// Some commonly used definition data
	/// </summary>
	[System.Serializable]
	public class CommonDefinitionData
	{
		public string ident = "";						//!< ident
		public string screenName = "";					//!< screenName
		public string shortName = "";					//!< shortName
		public string meta = "";						//!< meta
		public string description = "";					//!< description
		public Texture2D[] images = new Texture2D[3];   //!< images

		public CommonDefinitionData Copy()
		{
			CommonDefinitionData obj = new CommonDefinitionData();
			this.CopyTo(obj);
			return obj;
		}

		public void CopyTo(CommonDefinitionData o)
		{
			o.ident = this.ident;
			o.screenName = this.screenName;
			o.shortName = this.shortName;
			o.meta = this.meta;
			o.description = this.description;
			o.images = new Texture2D[this.images.Length];
			for (int i = 0; i < o.images.Length; i++) o.images[i] = this.images[i];
		}

		// ============================================================================================================
	}
}
