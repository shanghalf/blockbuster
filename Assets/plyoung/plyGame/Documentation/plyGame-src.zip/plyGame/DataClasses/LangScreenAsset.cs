﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class LangScreenAsset : ScriptableObject
	{
		[HideInInspector] public GUIScreen screenData = new GUIScreen();

		[HideInInspector] public int defaultLangBlockId = -1;				// ID of the UIBlock that will load the default language
		[HideInInspector] public List<int> langBlockIds = new List<int>();	// IDs of UIBlocks for each of the defined languages

		[HideInInspector] public int nextScreen = -1;						// The Custom screen to show next (will most likely be the main menu)
		[HideInInspector]public string nextScene = "";						// or if set, this scene will be loaded

		// ============================================================================================================
	}
}