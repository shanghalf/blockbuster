﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class GUIScreen
	{
		public int id = -1; // (-1 = invalid)
		public string name;

		public GUISkin skin;
		public bool doClearBack = true;
		public Color backgroundColor = new Color(0.204044104f, 0.238051474f, 0.272058845f, 1f);
		public int designWidth = 1024;
		public int designHeight = 768;

		// Need to be separate lists since Unity would not serialise it correctly if I used a UIBlock List
		public List<OnGUILabel> labelEles = new List<OnGUILabel>(0);
		public List<OnGUIImage> imageEles = new List<OnGUIImage>(0);
		public List<OnGUIMovie> movieEles = new List<OnGUIMovie>(0);
		public List<OnGUIButton> buttonEles = new List<OnGUIButton>(0);
		public List<OnGUIEdit> editEles = new List<OnGUIEdit>(0);
		public List<OnGUIToggle> toggleEles = new List<OnGUIToggle>(0);
		public List<OnGUIBox> boxEles = new List<OnGUIBox>(0);

		[SerializeField] private int nextUIEleId = 0;
		public int NextUIElementId { get { nextUIEleId++; return nextUIEleId - 1; } }

		// ============================================================================================================

		// a helper with a combination of the txt and img Blocks
		[System.NonSerialized] private List<OnGUIElement> _uiEles = null;
		public List<OnGUIElement> uiElements
		{
			get
			{
				if (_uiEles == null)
				{
					_uiEles = new List<OnGUIElement>();
					foreach (OnGUILabel b in labelEles) _uiEles.Add(b);
					foreach (OnGUIImage b in imageEles) _uiEles.Add(b);
					foreach (OnGUIMovie b in movieEles) _uiEles.Add(b);
					foreach (OnGUIButton b in buttonEles) _uiEles.Add(b);
					foreach (OnGUIEdit b in editEles) _uiEles.Add(b);
					foreach (OnGUIToggle b in toggleEles) _uiEles.Add(b);
					foreach (OnGUIBox b in boxEles) _uiEles.Add(b);
				}
				return _uiEles;
			}
		}

		[System.NonSerialized] public bool needRecalcFrames = true;
		[System.NonSerialized] public bool needGUICacheInit = true;
		[System.NonSerialized] public bool visible = false;

		private bool inited = false;

		// ============================================================================================================

		public static GUIScreen CreateInstance(GUIScreen data)
		{
			GUIScreen s = new GUIScreen();

			s.id = data.id;
			s.name = data.name;
			s.skin = data.skin;
			s.doClearBack = data.doClearBack;
			s.backgroundColor = data.backgroundColor;
			s.designWidth = data.designWidth;
			s.designHeight = data.designHeight;
			s.nextUIEleId = data.nextUIEleId;

			s._uiEles = new List<OnGUIElement>();
			foreach (OnGUILabel b in data.labelEles)
			{
				OnGUILabel nb = (OnGUILabel)b.Copy();
				s.labelEles.Add(nb); s._uiEles.Add(nb);
			}
			foreach (OnGUIImage b in data.imageEles)
			{
				OnGUIImage nb = (OnGUIImage)b.Copy();
				s.imageEles.Add(nb); s._uiEles.Add(nb);
			}
			foreach (OnGUIMovie b in data.movieEles)
			{
				OnGUIMovie nb = (OnGUIMovie)b.Copy();
				s.movieEles.Add(nb); s._uiEles.Add(nb);
			}
			foreach (OnGUIButton b in data.buttonEles)
			{
				OnGUIButton nb = (OnGUIButton)b.Copy();
				s.buttonEles.Add(nb); s._uiEles.Add(nb);
			}
			foreach (OnGUIEdit b in data.editEles)
			{
				OnGUIEdit nb = (OnGUIEdit)b.Copy();
				s.editEles.Add(nb); s._uiEles.Add(nb);
			}
			foreach (OnGUIToggle b in data.toggleEles)
			{
				OnGUIToggle nb = (OnGUIToggle)b.Copy();
				s.toggleEles.Add(nb); s._uiEles.Add(nb);
			}
			foreach (OnGUIBox b in data.boxEles)
			{
				OnGUIBox nb = (OnGUIBox)b.Copy();
				s.boxEles.Add(nb); s._uiEles.Add(nb);
			}

			return s;
		}

		// ============================================================================================================

		public void AddElement(OnGUIElement b)
		{
			uiElements.Add(b);
			switch (b.type)
			{
				case UIElementType.Label: labelEles.Add((OnGUILabel)b); break;
				case UIElementType.Image: imageEles.Add((OnGUIImage)b); break;
				case UIElementType.Movie: movieEles.Add((OnGUIMovie)b); break;
				case UIElementType.Button: buttonEles.Add((OnGUIButton)b); break;
				case UIElementType.Edit: editEles.Add((OnGUIEdit)b); break;
				case UIElementType.Toggle: toggleEles.Add((OnGUIToggle)b); break;
				case UIElementType.Box: boxEles.Add((OnGUIBox)b); break;
			}
		}

		public void RemoveElement(OnGUIElement b)
		{
			uiElements.Remove(b);
			switch (b.type)
			{
				case UIElementType.Label: labelEles.Remove((OnGUILabel)b); break;
				case UIElementType.Image: imageEles.Remove((OnGUIImage)b); break;
				case UIElementType.Movie: movieEles.Remove((OnGUIMovie)b); break;
				case UIElementType.Button: buttonEles.Remove((OnGUIButton)b); break;
				case UIElementType.Edit: editEles.Remove((OnGUIEdit)b); break;
				case UIElementType.Toggle: toggleEles.Remove((OnGUIToggle)b); break;
				case UIElementType.Box: boxEles.Remove((OnGUIBox)b); break;
			}
		}

		public OnGUIElement GetElement(int id)
		{
			if (id < 0) return null;
			for (int i = 0; i < uiElements.Count; i++)
			{
				if (uiElements[i].id == id) return uiElements[i];
			}
			return null;
		}

		public OnGUIElement GetElement(string name)
		{
			if (string.IsNullOrEmpty(name))
			{
				Debug.LogError("[GUIScreen] Error: The Element [" + name + "] was not found on the Screen [" + this.name + "]"); 
				return null;
			}
			
			for (int i = 0; i < uiElements.Count; i++)
			{
				if (uiElements[i].name.Equals(name)) return uiElements[i];
			}

			Debug.LogError("[GUIScreen] Error: The Element [" + name + "] was not found on the Screen [" + this.name + "]");
			return null;
		}

		public void SetElementVisible(string name, bool visible)
		{
			OnGUIElement ele = GetElement(name);
			if (ele != null) ele.visible = visible;
		}

		public void SetElementEnabled(string name, bool enabled)
		{
			OnGUIElement ele = GetElement(name);
			if (ele != null) ele.enabled = enabled;
		}

		public override string ToString()
		{
			return name;
		}

		public void SortElements()
		{
			uiElements.Sort((a, b) => { return a.zdepth.CompareTo(b.zdepth); });
			uiElements.Reverse();
		}

		public void InitGUICache()
		{
			if (!needGUICacheInit) return;
			needGUICacheInit = false;
			for (int i = 0; i < uiElements.Count; i++)
			{
				uiElements[i].InitGUICache(skin != null ? skin : GUI.skin);
			}
		}

		public void Init()
		{
			if (inited) return;
			inited = true;
			SortElements();
			for (int i = 0; i < uiElements.Count; i++)
			{
				uiElements[i].Init();
			}
		}

		public void OnAddedToManager()
		{
			Init();
		}

		public void OnVisibleChange(bool becomeVisible)
		{
			visible = becomeVisible;
			for (int i = 0; i < uiElements.Count; i++)
			{
				uiElements[i].OnScreenVisibleChange(becomeVisible);
			}
		}

		public void DrawElements()
		{
			GUI.skin = skin;
			InitGUICache();

			if (needRecalcFrames)
			{
				needRecalcFrames = false;
				for (int i = 0; i < uiElements.Count; i++)
				{
					uiElements[i].RecalcFrame();
				}
			}

			for (int i = 0; i < uiElements.Count; i++)
			{
				if (uiElements[i].visible)
				{
					GUI.enabled = uiElements[i].enabled;
					uiElements[i].Draw();
				}
			}

			GUI.enabled = true;
		}

		public static Rect GetElementFrame(OnGUIElement ele)
		{
			Rect r = new Rect(ele.offsetX, ele.offsetY, ele.width, ele.height);
			
			switch (ele.scaling)
			{
				case UIScale.StretchWidth:
				{
					r.width = Screen.width;
				} break;

				case UIScale.StretchHeight:
				{
					r.height = Screen.height;
				} break;

				case UIScale.StretchBoth:
				{
					r.width = Screen.width;
					r.height = Screen.height;
				} break;

				case UIScale.ScaleToFit:
				{
					float screenAspect = Screen.width / Screen.height;
					float imageAspect = (float)ele.width / (float)ele.height;
					if (screenAspect > imageAspect)
					{
						r.width = Screen.width * (imageAspect / screenAspect);
						r.height = Screen.height;
					}
					else
					{
						r.width = Screen.width;
						r.height = Screen.height * (screenAspect / imageAspect);
					}
				} break;

				case UIScale.ScaleAndCrop:
				{
					float screenAspect = Screen.width / Screen.height;
					float imageAspect = (float)ele.width / (float)ele.height;
					if (screenAspect > imageAspect)
					{
						r.width = Screen.width;
						r.height = Screen.height * (screenAspect / imageAspect);
					}
					else
					{
						r.width = Screen.width * (imageAspect / screenAspect);
						r.height = Screen.height;
					}
				} break;
			}

			// -----------------------------------------------------

			switch (ele.anchor)
			{
				case UIAnchor.UpperLeft:
				{
					// nothing to do
				} break;

				case UIAnchor.UpperCenter:
				{
					r.x += (Screen.width / 2 - r.width / 2);
				} break;

				case UIAnchor.UpperRight:
				{
					r.x += (Screen.width - r.width);
				} break;

				case UIAnchor.MiddleLeft:
				{
					r.y += (Screen.height / 2 - r.height / 2);
				} break;

				case UIAnchor.MiddleCenter:
				{
					r.x += (Screen.width / 2 - r.width / 2);
					r.y += (Screen.height / 2 - r.height / 2);
				} break;

				case UIAnchor.MiddleRight:
				{
					r.x += (Screen.width - r.width);
					r.y += (Screen.height / 2 - r.height / 2);
				} break;

				case UIAnchor.LowerLeft:
				{
					r.y += (Screen.height - r.height);
				} break;

				case UIAnchor.LowerCenter:
				{
					r.x += (Screen.width / 2 - r.width / 2);
					r.y += (Screen.height - r.height);
				} break;

				case UIAnchor.LowerRight:
				{
					r.x += (Screen.width - r.width);
					r.y += (Screen.height - r.height);
				} break;
			}

			return r;
		}

		public static Rect GetElementFrame(UIAnchor anchor, UIScale scaling, int offsetX, int offsetY, int width, int height)
		{
			Rect r = new Rect(offsetX, offsetY, width, height);

			switch (scaling)
			{
				case UIScale.StretchWidth:
				{
					r.width = Screen.width;
				} break;

				case UIScale.StretchHeight:
				{
					r.height = Screen.height;
				} break;

				case UIScale.StretchBoth:
				{
					r.width = Screen.width;
					r.height = Screen.height;
				} break;

				case UIScale.ScaleToFit:
				{
					float screenAspect = Screen.width / Screen.height;
					float imageAspect = (float)width / (float)height;
					if (screenAspect > imageAspect)
					{
						r.width = Screen.width * (imageAspect / screenAspect);
						r.height = Screen.height;
					}
					else
					{
						r.width = Screen.width;
						r.height = Screen.height * (screenAspect / imageAspect);
					}
				} break;

				case UIScale.ScaleAndCrop:
				{
					float screenAspect = Screen.width / Screen.height;
					float imageAspect = (float)width / (float)height;
					if (screenAspect > imageAspect)
					{
						r.width = Screen.width;
						r.height = Screen.height * (screenAspect / imageAspect);
					}
					else
					{
						r.width = Screen.width * (imageAspect / screenAspect);
						r.height = Screen.height;
					}
				} break;
			}

			// -----------------------------------------------------

			switch (anchor)
			{
				case UIAnchor.UpperLeft:
				{
					// nothing to do
				} break;

				case UIAnchor.UpperCenter:
				{
					r.x += (Screen.width / 2 - r.width / 2);
				} break;

				case UIAnchor.UpperRight:
				{
					r.x += (Screen.width - r.width);
				} break;

				case UIAnchor.MiddleLeft:
				{
					r.y += (Screen.height / 2 - r.height / 2);
				} break;

				case UIAnchor.MiddleCenter:
				{
					r.x += (Screen.width / 2 - r.width / 2);
					r.y += (Screen.height / 2 - r.height / 2);
				} break;

				case UIAnchor.MiddleRight:
				{
					r.x += (Screen.width - r.width);
					r.y += (Screen.height / 2 - r.height / 2);
				} break;

				case UIAnchor.LowerLeft:
				{
					r.y += (Screen.height - r.height);
				} break;

				case UIAnchor.LowerCenter:
				{
					r.x += (Screen.width / 2 - r.width / 2);
					r.y += (Screen.height - r.height);
				} break;

				case UIAnchor.LowerRight:
				{
					r.x += (Screen.width - r.width);
					r.y += (Screen.height - r.height);
				} break;
			}

			return r;
		}

		// ============================================================================================================
	}
}