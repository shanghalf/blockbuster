﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyGame;
using plyCommonEditor;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[InitializeOnLoad]
	public class plyRPGEdGlobal
	{
		public const string HLP_AreaTriggerEd = EdGlobal.HLP_URL + "area-trigger.html";
		public const string HLP_AttributesEd = EdGlobal.HLP_URL + "attributes.html";
		public const string HLP_ClassesEd = EdGlobal.HLP_URL + "actor-classes.html";
		public const string HLP_FactionsEd = EdGlobal.HLP_URL + "factions.html";
		public const string HLP_ItemsEd = EdGlobal.HLP_URL + "item.html";
		public const string HLP_ActorEd = EdGlobal.HLP_URL + "actors-list.html";
		public const string HLP_MarkerListEd = EdGlobal.HLP_URL + "markers.html";
		public const string HLP_LootEd = EdGlobal.HLP_URL + "loot.html";

		private static bool readyToLoad = false;
		private static plyRPGEdDataAsset _edData = null;
		public static plyRPGEdDataAsset edData
		{
			get
			{
				if (_edData == null && readyToLoad) LoadData();
				return _edData;
			}
		}

		/// <summary> Contains the skills prefabs. Default is 'Assets/plyData/System/Skills/'. </summary>
		public static string DATA_PATH_SKILLS { get { return plyEdUtil.DataPath + "/System/Skills/"; } }

		/// <summary> Contains the actor class prefabs. Default is 'Assets/plyData/System/Classes/'. </summary>
		public static string DATA_PATH_CLASSES { get { return plyEdUtil.DataPath + "/System/Classes/"; } }

		/// <summary> Contains the Item Event Responder prefabs. Default is 'Assets/plyData/System/Items/'. </summary>
		public static string DATA_PATH_ITEMS { get { return plyEdUtil.DataPath + "/System/Items/"; } }

		// ============================================================================================================

		static plyRPGEdGlobal()
		{
			readyToLoad = false;

			// hook some callbacks
			EditorApplication.update += RunOnce;
		}

		private static void RunOnce()
		{
			EditorApplication.update -= RunOnce;

			// init things here that should be loaded once the editor is up 
			// and would/ might cause errors if it executed in Constructor

			EdGlobal.RegisterPlugin(
						new plyGamePluginInfo()
						{
							name = "RPG by PL Young",
							versionFile = "plyoung/plyRPG/Documentation/version.txt",
						}
					);

			plyBloxGUI.blockIcons.Add("faction", plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.factionvar.png", typeof(EdGlobal).Assembly));
			RegisterDefaultToolButtons();

			// load data
			readyToLoad = true;
			LoadData();
		}

		private static void RegisterDefaultToolButtons()
		{
			EdToolbar.AddToolbarButtons(new System.Collections.Generic.List<EdToolbar.ToolbarButton>()
			{
				new EdToolbar.ToolbarButton() { order = 1000, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.systems" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Add System"), 
					popup = new List<EdToolbar.ToolbarButton>()
					{
						new EdToolbar.ToolbarButton() { order = 1, callback = Create_SpawnPoint, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_spawn" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Spawn Point") },
						new EdToolbar.ToolbarButton() { order = 2, callback = Create_GameTrigger, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_trigger" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Area Trigger") },
						new EdToolbar.ToolbarButton() { order = 3, callback = Create_WaypointPath, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_path" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Waypoint Path") },
						new EdToolbar.ToolbarButton() { order = 4, callback = Create_LocationMarker, gui = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.Toolbar.Icons.add_marker" + (EditorGUIUtility.isProSkin ? "" : "_l") + ".png", typeof(EdGlobal).Assembly), "Location Marker") },
					},
				},
			});	
		}

		private static void LoadData()
		{
			if (_edData == null)
			{
				CheckDataPaths();
				//edData = (plyRPGEdDataAsset)AssetDatabase.LoadAssetAtPath(plyEdUtil.DATA_PATH_SYSTEM + "plyrpg_ed.asset", typeof(plyRPGEdDataAsset));
				_edData = (plyRPGEdDataAsset)EdGlobal.LoadOrCreateAsset<plyRPGEdDataAsset>(plyEdUtil.DATA_PATH_SYSTEM + "plyrpg_ed.asset", null);
			}
		}

		public static void CheckDataPaths()
		{
			EdGlobal.CheckDataPaths();
			plyEdUtil.CheckDataPath(plyEdUtil.DATA_PATH_SYSTEM, DATA_PATH_SKILLS);
			plyEdUtil.CheckDataPath(plyEdUtil.DATA_PATH_SYSTEM, DATA_PATH_CLASSES);
			plyEdUtil.CheckDataPath(plyEdUtil.DATA_PATH_SYSTEM, DATA_PATH_ITEMS);
		}

		// ============================================================================================================
		#region menu

		//[MenuItem("Tools/PL Young/plyRPG/Items List", priority = 30)]
		//[MenuItem("Window/plyRPG/Items List", priority = 3)]
		//public static void ShowItemsListWindow()
		//{
		//	ItemsListWindow.Show_ItemsListWindow();
		//}

		[MenuItem("GameObject/Create Other/plyRPG/Spawn Point", false, 2010)]
		public static void Create_SpawnPoint()
		{
			// 1st create the parent if it does not exist
			GameObject parent = GameObject.Find("SpawnPoints");
			if (!parent) parent = new GameObject("SpawnPoints");

			// now create spawn point
			GameObject obj = plyEdUtil.CreateGameObjectInSceneView("SpawnPoint", new Vector3(0f, 0.1f, 0f), true, EdGlobal.floorLayer);
			if (!obj) return;
			obj.transform.parent = parent.transform;
			obj.AddComponent<SpawnPoint>();

			// select the new object
			Selection.activeGameObject = obj;
		}

		[MenuItem("GameObject/Create Other/plyRPG/Waypoint Path", false, 2011)]
		public static void Create_WaypointPath()
		{
			// 1st create the parent if it does not exist
			GameObject parent = GameObject.Find("WaypointPaths");
			if (!parent) parent = new GameObject("WaypointPaths");

			// now create spawn point
			GameObject obj = plyEdUtil.CreateGameObjectInSceneView("Path " + (parent.transform.childCount + 1).ToString(), new Vector3(0f, 0.1f, 0f), true, EdGlobal.floorLayer);
			if (!obj) return;
			obj.transform.parent = parent.transform;
			WaypointPath path = obj.AddComponent<WaypointPath>();

			// select the new object
			Selection.activeGameObject = obj;
		}

		[MenuItem("GameObject/Create Other/plyRPG/Area Trigger", false, 2012)]
		public static void Create_GameTrigger()
		{
			// 1st create the parent if it does not exist
			GameObject parent = GameObject.Find("Triggers");
			if (!parent) parent = new GameObject("Triggers");

			// now create trigger
			GameObject obj = plyEdUtil.CreateGameObjectInSceneView("Trigger " + (parent.transform.childCount + 1).ToString(), new Vector3(0f, 0.1f, 0f), true, EdGlobal.floorLayer);
			if (!obj) return;
			obj.transform.parent = parent.transform;
			obj.AddComponent<AreaTrigger>();

			// select the new object
			Selection.activeGameObject = obj;
		}

		[MenuItem("GameObject/Create Other/plyRPG/Location Marker", false, 2013)]
		public static void Create_LocationMarker()
		{
			// 1st create the parent if it does not exist
			GameObject parent = GameObject.Find("LocationMarkers");
			if (!parent) parent = new GameObject("LocationMarkers");

			// now create trigger
			GameObject obj = plyEdUtil.CreateGameObjectInSceneView("Marker " + (parent.transform.childCount + 1).ToString(), new Vector3(0f, 0.1f, 0f), true, EdGlobal.floorLayer);
			if (!obj) return;
			obj.transform.parent = parent.transform;
			obj.AddComponent<LocationMarker>();

			// select the new object
			Selection.activeGameObject = obj;
		}

		#endregion
		// ============================================================================================================
	}
}