﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	public class Action_InputDefiner: InputDefiner
	{
		public override List<InputDefinition> DefineInput()
		{
			return new List<InputDefinition>()
			{
				new InputDefinition() {
					category = "Action", name = "Action1", screenName1 = "Action 1",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha1 },
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton0, keyMod = KeyCode.JoystickButton4 } 
					}
				},
				new InputDefinition() {
					category = "Action", name = "Action2", screenName1 = "Action 2",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha2 },
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton1, keyMod = KeyCode.JoystickButton4 } 
					}
				},
				new InputDefinition() {
					category = "Action", name = "Action3", screenName1 = "Action 3",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha3 },
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton2, keyMod = KeyCode.JoystickButton4 } 
					}
				},
				new InputDefinition() {
					category = "Action", name = "Action4", screenName1 = "Action 4",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha4 },
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton3, keyMod = KeyCode.JoystickButton4 } 
					}
				},
				new InputDefinition() {
					category = "Action", name = "Action5", screenName1 = "Action 5",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha5 } }
				},
				new InputDefinition() {
					category = "Action", name = "Action6", screenName1 = "Action 6",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha6 } }
				},
				new InputDefinition() {
					category = "Action", name = "Action7", screenName1 = "Action 7",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha7 } }
				},
				new InputDefinition() {
					category = "Action", name = "Action8", screenName1 = "Action 8",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha8 } }
				},
				new InputDefinition() {
					category = "Action", name = "Action9", screenName1 = "Action 9",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha9 } }
				},
				new InputDefinition() {
					category = "Action", name = "Action10", screenName1 = "Action 10",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Alpha0 } }
				},
				new InputDefinition() {
					category = "Action", name = "Action11", screenName1 = "Action 11",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Minus } }
				},
				new InputDefinition() {
					category = "Action", name = "Action12", screenName1 = "Action 12",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Equals } }
				},
			};
		}

		// ============================================================================================================
	}
}
