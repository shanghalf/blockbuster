﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[CustomEditor(typeof(Marker))]
	public class Marker_Inspector : Editor
	{
		private Marker Target;
		private DataAsset dataAsset;
		private MarkersAsset markersAsset;

		private Object prefabLink = null;
		private UniqueID prefabUniqueId = null;

		// --------------------------------------------

		protected void OnEnable() 
		{
			Target = (Marker)target;

			if (false == EditorUtility.IsPersistent(target))
			{
				Marker fab = PrefabUtility.GetPrefabParent(target) as Marker;
				if (fab != null) prefabUniqueId = fab.id;
			}

			if (UniqueIDManager.CheckID(target, ref prefabLink, ref Target.id, prefabUniqueId, true, false))
			{
				EditorUtility.SetDirty(target);
			}

			if (markersAsset == null)
			{
				dataAsset = EdGlobal.GetDataAsset();
				markersAsset = (MarkersAsset)dataAsset.GetAsset<MarkersAsset>();
				if (markersAsset == null)
				{
					markersAsset = (MarkersAsset)EdGlobal.LoadOrCreateAsset<MarkersAsset>(plyEdUtil.DATA_PATH_SYSTEM + "markers.asset", "Marker Definitions");
					if (markersAsset.markerFabs.Count > 0)
					{	// make sure the asset is in the data asset if there is data defined
						if (dataAsset.AddAsset(markersAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}

			if (markersAsset.UpdateCache())
			{
				EditorUtility.SetDirty(markersAsset);
			}

			// check if this marker is in list and if not, add it
			GameObject g = markersAsset.GetPrefab(Target.id);
			if (g == null)
			{
				// be sure to only add prefabs to the list and not scene objects
				if (false == EditorUtility.IsPersistent(target))
				{
					// check if can get a prefab link before giving up
					Object o = PrefabUtility.GetPrefabParent(target);
					if (o != null)
					{
						GameObject fab = (o as Marker).gameObject;
						markersAsset.markerFabs.Add(fab);
						markersAsset.UpdateCache();
						EditorUtility.SetDirty(markersAsset);
					}
				}
				else
				{
					markersAsset.markerFabs.Add(Target.gameObject);
					markersAsset.UpdateCache();
					EditorUtility.SetDirty(markersAsset);
				}
			}
		}

		public override void OnInspectorGUI()
		{
			if (UniqueIDManager.CheckID(target, ref prefabLink, ref ((Marker)target).id, prefabUniqueId, false, false))
			{
				EditorUtility.SetDirty(target);
			}

			//EditorGUILayout.LabelField("ID", ((Marker)target).id.ToString());
		}

		// ============================================================================================================
	}
}
