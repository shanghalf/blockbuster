﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using plyGame;
using plyBloxKit;
using plyBloxKitEditor;

namespace plyGameEditor
{
	[CustomEditor(typeof(SimpleCustomizer))]
	public class SimpleCustomizer_Inspector : Editor
	{
		private GUIContent GC_OBJ;
		private GUIContent GC_MAT;
		private GUIContent GC_TEX;
		private GUIContent GC_COL;
		private GUIContent GC_ADD;

		SimpleCustomizer Target;
		private int sel = 0;

		// ============================================================================================================

		protected void OnEnable() 
		{
		}

		private void SetSkin()
		{
			plyEdGUI.UseSkin();
			if (GC_OBJ == null)
			{
				GC_OBJ = new GUIContent(FA.Ico16(FA.male, plyEdGUI.IconColor), "Object Groups");
				GC_MAT = new GUIContent(FA.Ico16(FA.adjust, plyEdGUI.IconColor), "Material Groups");
				GC_TEX = new GUIContent(FA.Ico16(FA.circle_o, plyEdGUI.IconColor), "Textures Groups");
				GC_COL = new GUIContent(FA.Ico16(FA.circle, plyEdGUI.IconColor), "Colour Groups");
				GC_ADD = new GUIContent(" Add Group", FA.Ico12(FA.plus, plyEdGUI.IconColor));
			}
		}

		public override void OnInspectorGUI()
		{
			SetSkin();
			Target = (SimpleCustomizer)target;

			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (plyEdGUI.ToggleButton(sel == 0, GC_OBJ, EditorStyles.miniButtonLeft, GUILayout.Width(30))) { sel = 0; plyEdGUI.ClearFocus(); }
				if (plyEdGUI.ToggleButton(sel == 1, GC_MAT, EditorStyles.miniButtonMid, GUILayout.Width(30))) { sel = 1; plyEdGUI.ClearFocus(); }
				if (plyEdGUI.ToggleButton(sel == 2, GC_TEX, EditorStyles.miniButtonMid, GUILayout.Width(30))) { sel = 2; plyEdGUI.ClearFocus(); }
				if (plyEdGUI.ToggleButton(sel == 3, GC_COL, EditorStyles.miniButtonRight, GUILayout.Width(30))) { sel = 3; plyEdGUI.ClearFocus(); }
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			switch (sel)
			{
				case 0: ObjGroups(); break;
				case 1: MatGroups(); break;
				case 2: TexGroups(); break;
				case 3: ColGroups(); break;
			}

			if (GUILayout.Button(GC_ADD, GUILayout.Width(120)))
			{
				switch (sel)
				{
					case 0: Target.objGroups.Add(new SimpleCustomizer_ObjectGroup()); break;
					case 1: Target.matGroups.Add(new SimpleCustomizer_Materials()); break;
					case 2: Target.texGroups.Add(new SimpleCustomizer_Textures()); break;
					case 3: Target.colGroups.Add(new SimpleCustomizer_Colors()); break;
				}
				plyEdGUI.ClearFocus();
				GUI.changed = true;
			}

			EditorGUILayout.Space();
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		private void ObjGroups()
		{
			plyEdGUI.SectionHeading("Object Groups", false);
			int del = -1;
			for (int i = 0; i < Target.objGroups.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Label(i.ToString() + ":", GUILayout.Width(25));
					Target.objGroups[i].name = EditorGUILayout.TextField(Target.objGroups[i].name);
					GUILayout.Space(10);
					if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.FlatIconButtonSmallStyle))
					{
						Target.objGroups[i].objects.Add(null);
						plyEdGUI.ClearFocus();
						EditorUtility.SetDirty(target);
					}
					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del = i;
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				int del2 = -1;
				for (int j = 0; j < Target.objGroups[i].objects.Count; j++)
				{
					EditorGUILayout.BeginHorizontal();
					{
						EditorGUI.indentLevel++;
						EditorGUILayout.LabelField(j.ToString(), GUILayout.Width(25));
						Target.objGroups[i].objects[j] = (GameObject)EditorGUILayout.ObjectField(Target.objGroups[i].objects[j], typeof(GameObject), true);
						GUILayout.Space(10);
						if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del2 = j;
						GUILayout.FlexibleSpace();
						EditorGUI.indentLevel--;
					}
					EditorGUILayout.EndHorizontal();
				}
				if (del2 >= 0)
				{
					plyEdGUI.ClearFocus();
					Target.objGroups[i].objects.RemoveAt(del2);
					EditorUtility.SetDirty(target);
				}
				plyEdGUI.HLine(10);
			}

			if (del >= 0)
			{
				plyEdGUI.ClearFocus();
				Target.objGroups.RemoveAt(del);
				EditorUtility.SetDirty(target);
			}
		}

		private void MatGroups()
		{
			plyEdGUI.SectionHeading("Material Groups", false);
			int del = -1;
			for (int i = 0; i < Target.matGroups.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Label(i.ToString() + ":", GUILayout.Width(25));
					Target.matGroups[i].name = EditorGUILayout.TextField(Target.matGroups[i].name, GUILayout.Width(75));
					Target.matGroups[i].targetObj = (GameObject)EditorGUILayout.ObjectField(Target.matGroups[i].targetObj, typeof(GameObject), true);
					GUILayout.Space(10);
					if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.FlatIconButtonSmallStyle))
					{
						Target.matGroups[i].materials.Add(null);
						plyEdGUI.ClearFocus();
						EditorUtility.SetDirty(target);
					}
					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del = i;
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();

				if (Target.matGroups[i].matIdx.Count < Target.matGroups[i].materials.Count)
				{	// hack to make sure that matIdx is same size at materials since it is feature added later
					while (Target.matGroups[i].matIdx.Count < Target.matGroups[i].materials.Count) Target.matGroups[i].matIdx.Add(0);
					EditorUtility.SetDirty(Target);
				}

				int del2 = -1;
				for (int j = 0; j < Target.matGroups[i].materials.Count; j++)
				{
					EditorGUILayout.BeginHorizontal();
					{
						EditorGUI.indentLevel++;
						EditorGUILayout.LabelField(j.ToString(), GUILayout.Width(25));
						Target.matGroups[i].matIdx[j] = EditorGUILayout.IntField(Target.matGroups[i].matIdx[j], GUILayout.Width(50));
						Target.matGroups[i].materials[j] = (Material)EditorGUILayout.ObjectField(Target.matGroups[i].materials[j], typeof(Material), false);
						GUILayout.Space(10);
						if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del2 = j;
						GUILayout.FlexibleSpace();
						EditorGUI.indentLevel--;
					}
					EditorGUILayout.EndHorizontal();
				}

				EditorGUIUtility.labelWidth = 60;
				EditorGUI.indentLevel++;
				Target.matGroups[i].depth = EditorGUILayout.IntField("Depth", Target.matGroups[i].depth, GUILayout.Width(120));
				EditorGUI.indentLevel--;
				EditorGUIUtility.labelWidth = 0;

				if (del2 >= 0)
				{
					plyEdGUI.ClearFocus();
					Target.matGroups[i].materials.RemoveAt(del2);
					EditorUtility.SetDirty(target);
				}
				plyEdGUI.HLine(10);
			}

			if (del >= 0)
			{
				plyEdGUI.ClearFocus();
				Target.matGroups.RemoveAt(del);
				EditorUtility.SetDirty(target);
			}
		}

		private void TexGroups()
		{
			plyEdGUI.SectionHeading("Texture Groups", false);
			int del = -1;
			for (int i = 0; i < Target.texGroups.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Label(i.ToString() + ":", GUILayout.Width(25));
					Target.texGroups[i].name = EditorGUILayout.TextField(Target.texGroups[i].name, GUILayout.Width(75));
					Target.texGroups[i].targetObj = (GameObject)EditorGUILayout.ObjectField(Target.texGroups[i].targetObj, typeof(GameObject), true);
					GUILayout.Space(10);
					if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.FlatIconButtonSmallStyle))
					{
						Target.texGroups[i].textures.Add(null);
						Target.texGroups[i].matIdx.Add(0);
						plyEdGUI.ClearFocus();
						EditorUtility.SetDirty(target);
					}
					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del = i;
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();

				if (Target.texGroups[i].matIdx.Count < Target.texGroups[i].textures.Count)
				{	// hack to make sure that matIdx is same size at textures since it is feature added later
					while (Target.texGroups[i].matIdx.Count < Target.texGroups[i].textures.Count) Target.texGroups[i].matIdx.Add(0);
					EditorUtility.SetDirty(Target);
				}

				int del2 = -1;
				for (int j = 0; j < Target.texGroups[i].textures.Count; j++)
				{
					EditorGUILayout.BeginHorizontal();
					{
						EditorGUI.indentLevel++;
						EditorGUILayout.LabelField(j.ToString(), GUILayout.Width(25));
						Target.texGroups[i].matIdx[j] = EditorGUILayout.IntField(Target.texGroups[i].matIdx[j], GUILayout.Width(50));
						Target.texGroups[i].textures[j] = (Texture2D)EditorGUILayout.ObjectField(Target.texGroups[i].textures[j], typeof(Texture2D), false);
						GUILayout.Space(10);
						if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del2 = j;
						GUILayout.FlexibleSpace();
						EditorGUI.indentLevel--;
					}
					EditorGUILayout.EndHorizontal();
				}

				EditorGUIUtility.labelWidth = 60;
				EditorGUI.indentLevel++;
				Target.texGroups[i].depth = EditorGUILayout.IntField("Depth", Target.texGroups[i].depth, GUILayout.Width(120));
				EditorGUI.indentLevel--;
				EditorGUIUtility.labelWidth = 0;

				if (del2 >= 0)
				{
					plyEdGUI.ClearFocus();
					Target.texGroups[i].textures.RemoveAt(del2);
					EditorUtility.SetDirty(target);
				}
				plyEdGUI.HLine(10);
			}

			if (del >= 0)
			{
				plyEdGUI.ClearFocus();
				Target.texGroups.RemoveAt(del);
				EditorUtility.SetDirty(target);
			}
		}

		private void ColGroups()
		{
			plyEdGUI.SectionHeading("Colour Groups", false);
			int del = -1;
			for (int i = 0; i < Target.colGroups.Count; i++)
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Label(i.ToString() + ":", GUILayout.Width(25));
					Target.colGroups[i].name = EditorGUILayout.TextField(Target.colGroups[i].name, GUILayout.Width(75));
					Target.colGroups[i].targetObj = (GameObject)EditorGUILayout.ObjectField(Target.colGroups[i].targetObj, typeof(GameObject), true);
					GUILayout.Space(10);
					if (GUILayout.Button(plyEdGUI.GC_Add, plyEdGUI.FlatIconButtonSmallStyle))
					{
						Target.colGroups[i].colors.Add(Color.white);
						Target.colGroups[i].matIdx.Add(0);
						plyEdGUI.ClearFocus();
						EditorUtility.SetDirty(target);
					}
					if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del = i;
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();

				if (Target.colGroups[i].matIdx.Count < Target.colGroups[i].colors.Count)
				{	// hack to make sure that matIdx is same size at colors since it is feature added later
					while (Target.colGroups[i].matIdx.Count < Target.colGroups[i].colors.Count) Target.colGroups[i].matIdx.Add(0);
					EditorUtility.SetDirty(Target);
				}

				int del2 = -1;
				for (int j = 0; j < Target.colGroups[i].colors.Count; j++)
				{
					EditorGUILayout.BeginHorizontal();
					{
						EditorGUI.indentLevel++;
						EditorGUILayout.LabelField(j.ToString(), GUILayout.Width(25));
						Target.colGroups[i].matIdx[j] = EditorGUILayout.IntField(Target.colGroups[i].matIdx[j], GUILayout.Width(50));
						Target.colGroups[i].colors[j] = EditorGUILayout.ColorField(Target.colGroups[i].colors[j]);
						GUILayout.Space(10);
						if (GUILayout.Button(plyEdGUI.GC_Delete, plyEdGUI.FlatIconButtonSmallStyle)) del2 = j;
						GUILayout.FlexibleSpace();
						EditorGUI.indentLevel--;
					}
					EditorGUILayout.EndHorizontal();
				}

				EditorGUIUtility.labelWidth = 60;
				EditorGUI.indentLevel++;
				Target.colGroups[i].depth = EditorGUILayout.IntField("Depth", Target.colGroups[i].depth, GUILayout.Width(120));
				EditorGUI.indentLevel--;
				EditorGUIUtility.labelWidth = 0;

				if (del2 >= 0)
				{
					plyEdGUI.ClearFocus();
					Target.colGroups[i].colors.RemoveAt(del2);
					EditorUtility.SetDirty(target);
				}
				plyEdGUI.HLine(10);
			}

			if (del >= 0)
			{
				plyEdGUI.ClearFocus();
				Target.colGroups.RemoveAt(del);
				EditorUtility.SetDirty(target);
			}
		}

		// ============================================================================================================
	}
}
