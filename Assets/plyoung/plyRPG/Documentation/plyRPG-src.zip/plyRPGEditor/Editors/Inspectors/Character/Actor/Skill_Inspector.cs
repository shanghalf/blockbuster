﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(Skill))]
	public class Skill_Inspector : Editor
	{
		Skill Target;

		protected void OnEnable()
		{
			Target = (Skill)target;
		}

		public override void OnInspectorGUI()
		{
			if (EditorApplication.isPlaying)
			{
				GUI.color = Color.red;
				if (plyEdGUI.ToggleButton(Target.showDebugInfo, "Show Debug Info", GUI.skin.button)) Target.showDebugInfo = !Target.showDebugInfo;
				GUI.color = Color.white;

				if (Target.showDebugInfo)
				{
					if (Target.gameObject.activeSelf == false) Target.gameObject.SetActive(true); // need to be active to be able to see gizmo/ debug info
					EditorGUILayout.BeginVertical(GUI.skin.box);
					GUILayout.Label("Showing debug info in scene.");
					EditorGUILayout.EndVertical();
				}
			}

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		//protected void OnSceneGUI()
		//{
		//	Vector3 p = Target.transform.position; p.y += 0.3f;
		//	Handles.color = plyEdGUI.ColorRedTrans;
		//	Handles.DrawSolidArc(p, Target.transform.up, Quaternion.AngleAxis(-(Target.targetingAngle / 2f), Target.transform.up) * Target.transform.forward, Target.targetingAngle, Target.targetingDistance);

		//	//Gizmos.color = Color.red;
		//	//Gizmos.DrawLine(p, p + (Target.transform.forward * Target.targetingDistance));
		//	//Gizmos.DrawLine(p, p + Quaternion.AngleAxis(+angle, Target.transform.up) * Target.transform.forward * Target.targetingDistance);
		//	//Gizmos.DrawLine(p, p + Quaternion.AngleAxis(-angle, Target.transform.up) * Target.transform.forward * Target.targetingDistance);
		//}

		// ============================================================================================================
	}
}
