﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;

namespace plyGameEditor
{
	[CustomEditor(typeof(PlayerTopDownNavController))]
	public class PlayerTopDownNavController_Inspector : CharacterControllerBase_Inspector
	{
		public override void OnInspectorGUI()
		{
			base.OnInspectorGUI();
		}

		protected override void PersistenceInfo()
		{
			base.PersistenceInfo();
			//if (Target.persistenceOn)
			//{
			//	// toggles for stuff to save comes here
			//}
		}

		// ============================================================================================================
	}
}
