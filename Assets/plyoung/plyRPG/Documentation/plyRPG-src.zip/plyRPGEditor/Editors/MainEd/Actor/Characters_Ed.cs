﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;

namespace plyGameEditor
{
	[ChildEditor("Actors", Order = -99800, Icon="char")]
	public class Characters_Ed : ChildEditorBase
	{
		private static string[] menuOpts = new string[0];
		private static ChildEditorBase[] editors;

		private static GUIContent GC_Refresh;
		private static GUIContent GC_Ping;

		private static GUIContent bPlayer;
		private static GUIContent bFaction;
		private static GUIContent bFriendly;
		private static GUIContent bNeutral;
		private static GUIContent bHostile;


		private Vector2 scroll = Vector2.zero;
		private int prevSel = 0;
		private int sel = 0;
		private bool needInit = true;

		// ============================================================================================================

		public override void OnCreated(Assembly[] asms) 
		{
			// find all the classes that inherit from ChildEditorBase
			List<System.Type> foundEdTypes = new List<System.Type>();
			for (int i = 0; i < asms.Length; i++)
			{
				System.Type[] types = asms[i].GetExportedTypes();
				for (int j = 0; j < types.Length; j++)
				{
					if (types[j].IsClass && typeof(ChildEditorBase).IsAssignableFrom(types[j]) && types[j].Name != "ChildEditorBase")
					{
						foundEdTypes.Add(types[j]);
					}
				}
			}

			// extract some def.meta data and look specifically for MarkersEdMenu attribute
			List<string> labels = new List<string>();
			List<ChildEditorBase> eds = new List<ChildEditorBase>();

			labels.Add("Player");
			eds.Add(null);
			labels.Add("NPC");
			eds.Add(null);
			labels.Add(null); // spacer
			eds.Add(null);

			for (int i = 0; i < foundEdTypes.Count; i++)
			{
				EdMenuOptionAttribute att = null;
				System.Object[] attribs = foundEdTypes[i].GetCustomAttributes(typeof(EdMenuOptionAttribute), false);
				if (attribs.Length > 0)
				{
					att = attribs[0] as EdMenuOptionAttribute;
					if (att != null)
					{
						if (att.ParentEd == typeof(Characters_Ed))
						{
							ChildEditorBase ed = (ChildEditorBase)System.Activator.CreateInstance(foundEdTypes[i]);
							labels.Add(att.Name);
							eds.Add(ed);
							ed.OnCreated(asms);
						}
					}
				}
			}

			// update the caches
			menuOpts = labels.ToArray();
			editors = eds.ToArray();
		}

		public override void OnFocus()
		{
			needInit = true;
			if (sel > 2)
			{
				editors[sel].ed = this.ed;
				editors[sel].OnFocus();
			}
		}

		private void Init()
		{
			if (plyRPGEdGlobal.edData != null)
			{
				needInit = false;
				if (plyRPGEdGlobal.edData.UpdateActorCache())
				{
					EditorUtility.SetDirty(plyRPGEdGlobal.edData);
				}
			}
		}

		private void CheckGUIContent()
		{
			if (GC_Refresh == null)
			{
				GC_Refresh = new GUIContent(FA.refresh + " Refresh", "Run through project and find all character prefabs");
				GC_Ping = new GUIContent(FA.Ico12(FA.bullseye, plyEdGUI.IconColor), "Ping the prefab");

				bPlayer = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_blue.png", typeof(EdGlobal).Assembly));
				bFaction = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_grey.png", typeof(EdGlobal).Assembly));
				bFriendly = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_green.png", typeof(EdGlobal).Assembly));
				bNeutral = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_yellow.png", typeof(EdGlobal).Assembly));
				bHostile = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.bullet_red.png", typeof(EdGlobal).Assembly));

			}
		}

		public override void OnGUI()
		{
			if (needInit) Init();
			CheckGUIContent();
			EditorGUILayout.BeginHorizontal();
			{
				prevSel = sel;
				sel = plyEdGUI.Menu(sel, menuOpts, GUILayout.Width(MainEditorWindow.MenuWidth));

				EditorGUILayout.BeginVertical();
				{
					if (sel == 0)
					{
						ShowActors(true);
					}
					if (sel == 1)
					{
						ShowActors(false);
					}
					else if (sel > 2) // note, skip 2 as it is a spacer
					{
						editors[sel].ed = this.ed;
						if (sel != prevSel) editors[sel].OnFocus();
						editors[sel].OnGUI();
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		private void ShowActors(bool showPlayerCharas)
		{
			EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
			{
				if (GUILayout.Button(GC_Refresh, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(120)))
				{
					plyEdGUI.ClearFocus();
					RefreshActors();
				}
				EditorGUILayout.Space();
				if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.ToolbarIconButtonStyle))
				{
					Application.OpenURL(plyRPGEdGlobal.HLP_ActorEd);
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			if (plyRPGEdGlobal.edData.actors.Count > 0)
			{
				scroll = EditorGUILayout.BeginScrollView(scroll);
				EditorGUILayout.BeginVertical(plyEdGUI.LRPaddingHelperStyle);
				{
					bool style2 = true;
					for (int i = 0; i < plyRPGEdGlobal.edData.actors.Count; i++)
					{
						if (plyRPGEdGlobal.edData.actors[i] == null)
						{
							Debug.LogError("Detected a null value in the list of actors. Press the Refresh button.");
							break;
						}

						if (plyRPGEdGlobal.edData.actors[i].character == null)
						{
							Debug.LogError("Detected an invalid character prefab that has no Player or NPC controller: " + plyRPGEdGlobal.edData.actors[i].gameObject.name);
							break;
						}

						if (plyRPGEdGlobal.edData.actors[i].character.IsPlayer())
						{
							if (showPlayerCharas == false) continue;
						}
						else
						{
							if (showPlayerCharas == true) continue;
						}

						style2 = !style2;
						EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
						{
							if (GUILayout.Button(GC_Ping, EditorStyles.miniButton, GUILayout.Width(20)))
							{
								EditorGUIUtility.PingObject(plyRPGEdGlobal.edData.actorFabs[i].gameObject);
							}

							if (plyRPGEdGlobal.edData.actors[i].character.IsPlayer())
							{
								GUILayout.Label(bPlayer);
							}
							else
							{
								if (plyRPGEdGlobal.edData.actors[i].overwriteStatus)
								{
									if (plyRPGEdGlobal.edData.actors[i].statusTowardsPlayer == StatusTowardsOther.Friendly) GUILayout.Label(bFriendly);
									else if (plyRPGEdGlobal.edData.actors[i].statusTowardsPlayer == StatusTowardsOther.Neutral) GUILayout.Label(bNeutral);
									else if (plyRPGEdGlobal.edData.actors[i].statusTowardsPlayer == StatusTowardsOther.Hostile) GUILayout.Label(bHostile);
								}
								else GUILayout.Label(bFaction);
							}

							GUILayout.Label(plyRPGEdGlobal.edData.actors[i].name);
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				EditorGUILayout.Space();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			else
			{
				GUILayout.Label("No Actor prefabs detected. Use the Refresh\nbutton to force a refresh if needed.");
			}
		}

		private void RefreshActors()
		{
			List<Actor> actors = plyEdUtil.FindPrefabsOfTypeAll<Actor>("Please wait", "Searching for all Actor prefabs");
			plyRPGEdGlobal.edData.actorFabs = new List<GameObject>(0);
			for (int i = 0; i < actors.Count; i++)
			{
				plyRPGEdGlobal.edData.actorFabs.Add(actors[i].gameObject);
			}
			plyRPGEdGlobal.edData.UpdateActorCache();
			EditorUtility.SetDirty(plyRPGEdGlobal.edData);
		}

		// ============================================================================================================
	}
}