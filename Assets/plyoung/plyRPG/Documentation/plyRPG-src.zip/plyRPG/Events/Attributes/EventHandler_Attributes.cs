﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_Attributes : plyEventHandler
	{
		private List<plyEvent> attribEvents = new List<plyEvent>(0);
		private List<plyEvent> levelEvents = new List<plyEvent>(0);
		private List<plyEvent> xpEvents = new List<plyEvent>(0);
		private List<plyEvent> hpEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			attribEvents = new List<plyEvent>(0);
			levelEvents = new List<plyEvent>(0);
			xpEvents = new List<plyEvent>(0);
			hpEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Attribute Change"))
			{
				attribEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Level Change"))
			{
				levelEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On XP Change"))
			{
				xpEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On HP Change"))
			{
				hpEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (attribEvents.Count > 0 || levelEvents.Count > 0 || xpEvents.Count > 0 || hpEvents.Count > 0);

			attribEvents.TrimExcess();
			levelEvents.TrimExcess();
			xpEvents.TrimExcess();
			hpEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnAttributeChange(ActorAttribute att)
		{
			if (attribEvents.Count == 0) return;
			RunEvents(attribEvents,
				new plyEventArg("attrib", att),
				new plyEventArg("attribValue", att.Value),
				new plyEventArg("attribConsumable", att.ConsumableValue),
				new plyEventArg("deltaVal", (att.lastValue - att.Value)),
				new plyEventArg("deltaCVal", (att.lastConsumableValue - att.ConsumableValue))
			);
		}

		public void OnLevelChanged(int level)
		{
			if (levelEvents.Count == 0) return;
			RunEvents(levelEvents,
				new plyEventArg("level", level)
			);
		}

		public void OnXPChanged(ActorAttribute att)
		{
			if (xpEvents.Count == 0) return;
			RunEvents(xpEvents,
				new plyEventArg("attrib", att),
				new plyEventArg("attribValue", att.Value),
				new plyEventArg("attribConsumable", att.ConsumableValue),
				new plyEventArg("deltaVal", (att.lastValue - att.Value)),
				new plyEventArg("deltaCVal", (att.lastConsumableValue - att.ConsumableValue))
			);
		}

		public void OnHPChanged(ActorAttribute att)
		{
			if (hpEvents.Count == 0) return;
			RunEvents(hpEvents,
				new plyEventArg("attrib", att),
				new plyEventArg("attribValue", att.Value),
				new plyEventArg("attribConsumable", att.ConsumableValue),
				new plyEventArg("wentDown", att.ConsumableValue < att.lastConsumableValue),
				new plyEventArg("deltaVal", (att.lastValue - att.Value)),
				new plyEventArg("deltaCVal", (att.lastConsumableValue - att.ConsumableValue))
			);
		}
		
		// ============================================================================================================
	}
}
