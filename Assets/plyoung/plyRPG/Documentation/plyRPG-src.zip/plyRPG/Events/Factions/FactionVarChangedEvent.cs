﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Factions", "On Variable Change",
		Description = "Called when the value of one of the Faction Variables of a Faction changed.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>varName</b>: Name of the faction variable that changed.\n"+
		"- <b>varValue</b>: New value of the changed faction variable.\n"+
		"- <b>faction</b>: Faction who's variable changed. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>otherFac</b>: Faction to which the variable value is related. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>factionIdx</b>: Index of faction who's variable changed. Index is in order as defined factions, starting at 0.\n" +
		"- <b>otherFacIdx</b>: Index of the Faction to which the variable value is related. Index is in order as defined factions, starting at 0.\n"
	)]
	public class FactionVarChangedEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Factions);
		}

		// ============================================================================================================
	}
}