﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_Factions : plyEventHandler
	{
		private List<plyEvent> varChangeEvents = new List<plyEvent>(0);
		private List<plyEvent> statusChangeEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			varChangeEvents = new List<plyEvent>(0);
			statusChangeEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Variable Change"))
			{
				varChangeEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Status Change"))
			{
				statusChangeEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (varChangeEvents.Count > 0 || statusChangeEvents.Count > 0);

			varChangeEvents.TrimExcess();
			statusChangeEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnVariableChange(ActorFaction faction, ActorFaction otherFac, plyVar changedVar, int factionIdx, int otherFacIdx)
		{
			if (varChangeEvents.Count == 0) return;
			RunEvents(varChangeEvents,
				new plyEventArg("varName", changedVar.name),
				new plyEventArg("varValue", changedVar.GetValue()),
				new plyEventArg("faction", faction),
				new plyEventArg("otherFac", otherFac),
				new plyEventArg("factionIdx", factionIdx),
				new plyEventArg("otherFacIdx", otherFacIdx)
			);

			//bloxObject.SetTempVarValue("varName", changedVar.name);
			//bloxObject.SetTempVarValue("varValue", changedVar.GetValue());
			//bloxObject.SetTempVarValue("faction", faction);
			//bloxObject.SetTempVarValue("otherFac", otherFac);
			//bloxObject.SetTempVarValue("factionIdx", factionIdx);
			//bloxObject.SetTempVarValue("otherFacIdx", otherFacIdx);

			//stateChanged = false;
			//for (int i = 0; i < varChangeEvents.Count; i++)
			//{
			//	bloxObject.RunEvent(varChangeEvents[i]);
			//	if (stateChanged) break; // don't execute any further Events if State changed
			//}
		}

		public void OnStatusChange(ActorFaction faction, ActorFaction otherFac, StatusTowardsOther newStatus, int factionIdx, int otherFacIdx)
		{
			if (statusChangeEvents.Count == 0) return;
			RunEvents(statusChangeEvents,
				new plyEventArg("newStatus",  (newStatus == StatusTowardsOther.Friendly ? (int)1 : newStatus == StatusTowardsOther.Neutral ? (int)2 : (int)3) ),
				new plyEventArg("faction", faction),
				new plyEventArg("otherFac", otherFac),
				new plyEventArg("factionIdx", factionIdx),
				new plyEventArg("otherFacIdx", otherFacIdx)
			);

			//if (newStatus == StatusTowardsOther.Friendly) bloxObject.SetTempVarValue("newStatus", (int)1);
			//else if (newStatus == StatusTowardsOther.Neutral) bloxObject.SetTempVarValue("newStatus", (int)2);
			//else if (newStatus == StatusTowardsOther.Hostile) bloxObject.SetTempVarValue("newStatus", (int)3);
			//bloxObject.SetTempVarValue("faction", faction);
			//bloxObject.SetTempVarValue("otherFac", otherFac);
			//bloxObject.SetTempVarValue("factionIdx", factionIdx);
			//bloxObject.SetTempVarValue("otherFacIdx", otherFacIdx);

			//stateChanged = false;
			//for (int i = 0; i < statusChangeEvents.Count; i++)
			//{
			//	bloxObject.RunEvent(statusChangeEvents[i]);
			//	if (stateChanged) break; // don't execute any further Events if State changed
			//}
		}

		// ============================================================================================================
	}
}
