﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_Item : plyEventHandler
	{
		public class Message
		{
			public Item item;
			public int slot;
			public GameObject owner;
		}

		private List<plyEvent> pickupEvents = new List<plyEvent>(0);
		private List<plyEvent> removeEvents = new List<plyEvent>(0);
		private List<plyEvent> useEvents = new List<plyEvent>(0);
		private List<plyEvent> equipEvents = new List<plyEvent>(0);
		private List<plyEvent> unequipEvents = new List<plyEvent>(0);
		private List<plyEvent> addCurrencyEvents = new List<plyEvent>(0);
		private List<plyEvent> remCurrencyEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			pickupEvents = new List<plyEvent>(0);
			removeEvents = new List<plyEvent>(0);
			useEvents = new List<plyEvent>(0);
			equipEvents = new List<plyEvent>(0);
			unequipEvents = new List<plyEvent>(0);
			addCurrencyEvents = new List<plyEvent>(0);
			remCurrencyEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Add Item to Bag"))
			{
				pickupEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Remove Item from Bag"))
			{
				removeEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Use Item from Bag"))
			{
				useEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Equip Item"))
			{
				equipEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On UnEquip Item"))
			{
				unequipEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Add Currency"))
			{
				addCurrencyEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Remove Currency"))
			{
				remCurrencyEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (pickupEvents.Count > 0 || removeEvents.Count > 0 || useEvents.Count > 0 || equipEvents.Count > 0 || unequipEvents.Count > 0 || addCurrencyEvents.Count > 0 || remCurrencyEvents.Count > 0);

			pickupEvents.TrimExcess();
			removeEvents.TrimExcess();
			useEvents.TrimExcess();
			equipEvents.TrimExcess();
			unequipEvents.TrimExcess();
			addCurrencyEvents.TrimExcess();
			remCurrencyEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnItemAddedToBag(Message msg)
		{
			if (pickupEvents.Count == 0) return;
			RunEvents(pickupEvents,
				new plyEventArg("bagSlot", msg.slot),
				new plyEventArg("item", msg.item),
				new plyEventArg("owner", msg.owner)
			);
		}

		public void OnItemRemovedFromBag(Message msg)
		{
			if (removeEvents.Count == 0) return;
			RunEvents(removeEvents,
				new plyEventArg("bagSlot", msg.slot),
				new plyEventArg("item", msg.item),
				new plyEventArg("owner", msg.owner)
			);
		}

		public void OnItemUse(Message msg)
		{
			if (useEvents.Count == 0) return;
			RunEvents(useEvents,
				new plyEventArg("bagSlot", msg.slot),
				new plyEventArg("item", msg.item),
				new plyEventArg("owner", msg.owner)
			);
		}

		public void OnItemEquipped(Message msg)
		{
			if (equipEvents.Count == 0) return;
			RunEvents(equipEvents,
				new plyEventArg("equipSlot", msg.slot),
				new plyEventArg("item", msg.item),
				new plyEventArg("owner", msg.owner)
			);
		}

		public void OnItemUnEquipped(Message msg)
		{
			if (unequipEvents.Count == 0) return;
			RunEvents(unequipEvents,
				new plyEventArg("equipSlot", msg.slot),
				new plyEventArg("item", msg.item),
				new plyEventArg("owner", msg.owner)
			);
		}

		public void OnCurrencyAddedToBag(Message msg)
		{
			if (pickupEvents.Count == 0) return;
			RunEvents(addCurrencyEvents,
				new plyEventArg("amount", msg.slot), // hi-jack "slot" variable for currency amount in this case
				new plyEventArg("owner", msg.owner)
			);
		}

		public void OnCurrencyRemovedFromBag(Message msg)
		{
			if (pickupEvents.Count == 0) return;
			RunEvents(remCurrencyEvents,
				new plyEventArg("amount", msg.slot), // hi-jack "slot" variable for currency amount in this case
				new plyEventArg("owner", msg.owner)
			);
		}

		// ============================================================================================================
	}
}
