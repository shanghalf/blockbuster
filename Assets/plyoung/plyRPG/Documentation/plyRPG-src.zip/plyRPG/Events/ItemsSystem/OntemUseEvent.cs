﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Items", "On Use Item from Bag",
		Description = "Called when an Item is used from a Bag. You can use this Event in the plyBlox of an Item or the object that has the Item Bag component on it. The Event will first trigger for the Bag and then for the Item." +
		"\n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>bagSlot</b>: The bag slot (int) from which the Item was used.\n" +
		"- <b>item</b>: The Item (System.Object) that was used. The instance of the Item object in the bag, just before the object is removed (destroyed) if it is consumable. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>owner</b>: The owner (GameObject) of the bag the Item was used from.\n"
		)]
	public class OntemUseEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Item);
		}

		// ============================================================================================================
	}
}