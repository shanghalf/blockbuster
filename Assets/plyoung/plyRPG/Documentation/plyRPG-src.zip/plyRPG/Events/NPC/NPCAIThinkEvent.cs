﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/NPC", "On AI Think",
		Description = "This Event is triggered in the Blox on the NPC object only. It is called at a regular interval as specified by the 'Think Interval' property of the NPC Controller. It is better to use this than the general purpose Update Event as you do not always want the NPC to execute its decision making each frame.\n")]
	public class NPCAIThinkEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_NPC);
		}

		// ============================================================================================================
	}
}