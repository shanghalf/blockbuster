﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Skill", "On Skill Hit",
		Description = "Called when the Skill's effect hits or affects a valid target.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>skillOwner</b>: The Actor (GameObject) that owns the Skill.\n"+
		"- <b>skillObject</b>: The Skill (GameObject).\n"+
		"- <b>hitObject</b>: will be set to the affected/ hit GameObject.\n"+
		"- <b>hitPoint</b>: The position (Vector3) in world space where the hit occurred.\n" +
		"- <b>skillOwnerData</b>: Data (System.Object) of owner. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"+
		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"+
		"- <b>hitObjectData</b>: Data (System.Object) of object that was hit. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"
	)]
	public class SkillHitEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Skills);
		}

		// ============================================================================================================
	}
}