﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Skill", "On Skill Fizzle",
		Description = "Called when when a projectile hit an obstacle or simply fizzle because of its life timeout or max distance traveled before hitting a valid target.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>skillOwner</b>: The Actor (GameObject) that owns the Skill.\n"+
		"- <b>skillObject</b>: The Skill (GameObject).\n"+
		"- <b>fizzlePos</b>: is the world position (Vector3) at which it fizzled.\n"+
		"- <b>wasObstacle</b>: will be set True (Boolean) if the fizzle occurred because of obstacle.\n" +
		"- <b>skillOwnerData</b>: Data (System.Object) of owner. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"
	)]
	public class SkillFizzleEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Skills);
		}

		// ============================================================================================================
	}
}