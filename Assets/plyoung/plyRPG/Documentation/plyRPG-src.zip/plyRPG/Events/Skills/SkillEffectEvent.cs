﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Skill", "On Skill Effect",
		Description = "Called when a skill's effect is created. For a projectile skill it would be when the projectile is created. For instant it would be after the skill was activated and valid to execute. It is called for each valid target when using an instant skill that can collect more than one target. Instant Skills with Hit delay will still collect targets and trigger this event for each since it triggers before hits. These targets might not be same as targets that are finally hit.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>skillOwner</b>: The Actor (GameObject) that owns the Skill.\n"+
		"- <b>skillObject</b>: The Skill (GameObject).\n" +
		"- <b>skillOwnerData</b>: Data (System.Object) of owner. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"+
		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>targetLocation</b>: (Vector3) The world position of the effect's target.\n" +
		"- <b>targetObject</b>: (GameObject) The target as a GameObject.\n" +
		"- <b>projectileForward</b>: (Vector3) Only valid when projectile type skill. The forward direction that the projectile should move from the skill owner.\n"
	)]
	public class SkillEffectEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Skills);
		}

		// ============================================================================================================
	}
}