﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_ObjectInteract : plyEventHandler
	{
		private List<plyEvent> interactEvents = new List<plyEvent>(0);
		private List<plyEvent> interactStopEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			interactEvents = new List<plyEvent>(0);
			interactStopEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Interact"))
			{
				interactEvents.Add(e);
			}
			else if (e.uniqueIdent.Equals("On Interact Stopped"))
			{
				interactStopEvents.Add(e);
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = (interactEvents.Count > 0 || interactStopEvents.Count > 0);

			interactEvents.TrimExcess();
			interactStopEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnInteract(CharacterControllerBase chara)
		{
			if (interactEvents.Count == 0) return;
			RunEvents(interactEvents,
				new plyEventArg("character", chara.gameObject),
				new plyEventArg("characterData", chara.DataObject())
			);
		}

		public void OnInteractStop(CharacterControllerBase chara)
		{
			if (interactStopEvents.Count == 0) return;
			RunEvents(interactStopEvents,
				new plyEventArg("character", chara.gameObject),
				new plyEventArg("characterData", chara.DataObject())
			);
		}

		// ============================================================================================================
	}
}
