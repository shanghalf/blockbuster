﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	// note: This looks for GameObject_Value targetChara; as a field of the Block
	public class CharaAniClipNameData : IBlockValidate
	{
		public string name = "";

		public override string ToString()
		{
			return string.IsNullOrEmpty(name) ? null : name;
		}

		public CharaAniClipNameData Copy()
		{
			CharaAniClipNameData o = new CharaAniClipNameData();
			o.name = this.name;
			return o;
		}

		public bool IsValid()
		{
			return (false == string.IsNullOrEmpty(name));
		}

		// ============================================================================================================
	}
}