﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Render", "Markers (plyRPG)", "Remove Marker", BlockType.Action, Order = 10,
		Description = "Remove a marker from an object.")]
	public class Marker_Remove_plyBlock : plyBlock
	{
		[plyBlockField("Remove marker", ShowName = true, ShowValue = true, DefaultObject = typeof(String_Value), Description = "The marker to remove. This should be the name of the marker object.")]
		public String_Value markerName;

		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The owner of the marker.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private GameObject go = null;

		public override void Created()
		{
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = markerName != null;
			if (!blockIsValid) Log(LogType.Error, "The name is invalid.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (go == null)
			{
				go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}
			}

			string s = markerName.RunAndGetString();
			if (string.IsNullOrEmpty(s))
			{
				blockIsValid = false;
				Log(LogType.Error, "The name is invalid.");
				return BlockReturn.Error;
			}

			bool found = false;
			Marker[] markers = go.GetComponentsInChildren<Marker>();
			for (int i = 0; i < markers.Length; i++)
			{
				if (markers[i].name.Equals(s))
				{
					found = true;
					Object.Destroy(markers[i].gameObject);
					break;
				}
			}

			if (!found) Log(LogType.Warning, string.Format("The Marker [{0}] was not found for the target object [{1}]", s, go.name));

			if (false == cacheTarget) go = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}