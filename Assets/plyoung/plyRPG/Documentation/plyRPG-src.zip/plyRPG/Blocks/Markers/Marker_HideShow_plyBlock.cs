﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Render", "Markers (plyRPG)", "Hide or Show Marker", BlockType.Action, Order = 10,
		Description = "Hide or Show a marker of an object.")]
	public class Marker_HideShow_plyBlock : plyBlock
	{
		[plyBlockField("Do", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public plyVisibleState2 mode = plyVisibleState2.Show;

		[plyBlockField("marker", ShowName = true, ShowValue = true, DefaultObject = typeof(String_Value), Description = "The marker to hide/ show. This should be the name of the marker object.")]
		public String_Value markerName;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The owner of the marker.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private GameObject go = null;
		private GameObject marker = null;

		public override void Created()
		{
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = markerName != null;
			if (!blockIsValid) Log(LogType.Error, "The name is invalid.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (go == null)
			{
				go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}
			}

			if (marker == null)
			{
				string s = markerName.RunAndGetString();
				if (string.IsNullOrEmpty(s))
				{
					blockIsValid = false;
					Log(LogType.Error, "The name is invalid.");
					return BlockReturn.Error;
				}

				Marker[] markers = go.GetComponentsInChildren<Marker>();
				for (int i = 0; i < markers.Length; i++)
				{
					if (markers[i].name.Equals(s))
					{
						marker = markers[i].gameObject;
						break;
					}
				}

				if (marker == null)
				{
					blockIsValid = false;
					Log(LogType.Error, string.Format("The Marker [{0}] was not found for the target object [{1}]", s, go.name));
					return BlockReturn.Error;
				}
			}

			marker.SetActive(mode == plyVisibleState2.Show);

			if (false == cacheTarget)
			{
				go = null; // do not cache
				marker = null;
			}
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}