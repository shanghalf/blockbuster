﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Items (plyRPG)", "Item Value", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return the Item's base value.")]
	public class Item_Value_plyBlock : Float_Value
	{
		[plyBlockField("Item", ShowAfterField = "value", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item.")]
		public SystemObject_Value it;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = it != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			Item item = it.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			value = item.baseValue;

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}