﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Bag (plyRPG)", "Slot Stack Size", BlockType.Variable, Order = 3,
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return the stack size of specified slot.")]
	public class Bag_GetSlotStackSize_plyBlock : Int_Value
	{
		[plyBlockField("Bag Slot", ShowAfterField = "Stack size", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot - Integer", Description = "Slot to look in.")]
		public Int_Value slot;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = slot != null;
			if (!blockIsValid) Log(LogType.Error, "The Slot must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			int i = slot.RunAndGetInt();
			ItemBag.ItemInBag iib = bag.GetItemInSlot(i);
			value = iib == null ? 0 : iib.stack;

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}