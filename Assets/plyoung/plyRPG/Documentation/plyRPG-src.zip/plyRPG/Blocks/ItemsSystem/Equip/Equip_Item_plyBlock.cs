﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Equip (plyRPG)", "Equip Item", BlockType.Action, Order = 4,
		Description = "Add Item to specified Equipment Slot. Any existing equipped Item will be removed.")]
	public class Equip_Item_plyBlock : plyBlock
	{
		[plyBlockField("Equip Item", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item to equip.")]
		public SystemObject_Value itVal;

		[plyBlockField("to Slot", CustomValueStyle = "plyBlox_BoldLabel", ShowName = true, ShowValue = true, Description = "")]
		public EquipSlotData equipSlotNfo = new EquipSlotData();

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has equip slots.")]
		public GameObject_Value target;

		[plyBlockField("drop option", ShowAfterField="existing Item", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "What should happen with the Item, in same slot, that is unequipped and when there is no space in the bag for it (or no bag on the character).")]
		public ItemBag.ItemDropOption dropOpt = ItemBag.ItemDropOption.toScene;

		[plyBlockField("failSilent", Description = "If set then visually equip will fail silently if a child/ dummy object with the correct equip slot tag name was not found in the character hierarchy. You can toggle this off to debug and turn it on when you have cases where an item should not actually appear visually (for example equipping rings)")]
		public bool failSilent = false;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private EquipmentSlots slots;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = itVal != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");

		}

		public override BlockReturn Run(BlockReturn param)
		{
			// ** Get reference to equip slots
			if (slots == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				slots = go.GetComponent<EquipmentSlots>();
				if (slots == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Equipment Slots component on it.");
					return BlockReturn.Error;
				}
			}

			Item item = itVal.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			if (false == slots.EquipItem(item, equipSlotNfo.name, failSilent, dropOpt))
			{
				Log(LogType.Error, "Failed to equip item.");
				return BlockReturn.Error;
			}

			if (!cacheTarget) slots = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}