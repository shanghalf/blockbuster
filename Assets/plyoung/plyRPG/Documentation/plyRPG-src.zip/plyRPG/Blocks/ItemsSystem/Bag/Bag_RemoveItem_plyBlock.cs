﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Bag (plyRPG)", "Remove from Bag", BlockType.Action, Order = 3,
		Description = "Removes specified Item from Bag. Will remove first copy of the Item it finds in the Bag.")]
	public class Bag_RemoveItem_plyBlock : plyBlock
	{
		[plyBlockField("Remove", ShowAfterField = "from Bag", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item to remove.")]
		public SystemObject_Value itVal;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("drop option", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "What should be done with removed Item.")]
		public ItemBag.ItemDropOption dropOpt = ItemBag.ItemDropOption.toScene;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = itVal != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{			
			// ** Get reference to Bag
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			Item item = itVal.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			if (false == bag.RemoveItemFromBag(item, dropOpt, true))
			{
				Log(LogType.Warning, "Failed to remove Item from Bag: " + item.def.screenName);
			}

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}