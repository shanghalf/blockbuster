﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Items (plyRPG)", "Item Type", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - String", ReturnValueType = typeof(String_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return the type or sub-type of an Item.")]
	public class Item_Type_plyBlock : String_Value
	{
		public enum Opt { Type, SubType }
		[plyBlockField("Get", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public Opt opt = Opt.Type;

		[plyBlockField("of Item", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item")]
		public SystemObject_Value it;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = it != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = ""; 
			Item item = it.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			if (item.itemType >= 0 && item.itemType < ItemsAsset.Instance.itemTypes.Count)
			{
				if (opt == Opt.Type) value = ItemsAsset.Instance.itemTypes[item.itemType].name;
				else
				{
					if (item.itemSubType >= 0 && item.itemSubType < ItemsAsset.Instance.itemTypes[item.itemType].subTypes.Count)
					{
						value = ItemsAsset.Instance.itemTypes[item.itemType].subTypes[item.itemSubType];
					}
				}
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}