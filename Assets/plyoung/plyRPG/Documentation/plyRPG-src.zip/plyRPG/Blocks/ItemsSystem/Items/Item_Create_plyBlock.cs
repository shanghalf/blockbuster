﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Items (plyRPG)", "Create in Scene", BlockType.Action, Order = 1,
		Description = "Create an Item in the scene.")]
	public class Item_Create_plyBlock : plyBlock
	{
		[plyBlockField("Create Item", ShowName = true, ShowValue = true, DefaultObject=typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item to create.")]
		public SystemObject_Value itVal;

		[plyBlockField("at position", SubName = "Position - Vector3", ShowName = true, ShowValue = true, EmptyValueName = "---", Description = "[Optional] Position to place the created object in world space.")]
		public Vector3_Value pos;

		[plyBlockField("with rotation", SubName = "Rotation - Vector3", ShowName = true, ShowValue = true, EmptyValueName = "---", Description = "[Optional] Optional rotation to set the created object to.")]
		public Vector3_Value rot;

		[plyBlockField("and set", SubName = "Variable", ShowName = true, ShowValue = true, EmptyValueName = "-nothing-", Description = "[Optional] Variable to set with a reference to the created GameObject.")]
		public plyVar_Value saveIn;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = itVal != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			Item item = itVal.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			Item it = Item.CreateItem(item.prefabId, Item.ItemLocation.Scene, pos == null ? Vector3.zero : pos.RunAndGetVector3(), rot == null ? Quaternion.identity : Quaternion.Euler(rot.RunAndGetVector3()), null);

			if (it == null)
			{
				Log(LogType.Error, "Failed to create the Item in the scene.");
				return BlockReturn.Error;
			}

			plyVar vr = saveIn == null ? null : saveIn.RunAndGetVariable();
			if (vr != null) vr.SetValue(it.gameObject);

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}