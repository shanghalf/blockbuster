﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Find Targetable", BlockType.Variable, Order = 5, ShowName = "in Player range, ",
		ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Find a Targetable Object via the supplied rules. This is in relation to the Player.")]
	public class Character_FindTarget_plyBlock : GameObject_Value
	{
		public enum FindType
		{
			Any, AnyActor, FriendlyActor, NeutralActor, HostileActor, RPGObject, RPGItem
		}

		[plyBlockField("type =", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "Targetable must be of this type.")]
		public FindType validType = FindType.Any;
		[plyBlockField("distance from =", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "Distance this object can be from targetable.")]
		public float buttonSelDistance = 10f;
		[plyBlockField("and angle =", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "Targetable must be within this angle of this object's forward direction.")]
		public int buttonSelAngle = 60;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			Transform _tr = Player.Instance.gameObject.transform;
			value = null;

			LayerMask selectButtonMask = 0;
			if (validType == FindType.Any || validType == FindType.AnyActor || validType == FindType.FriendlyActor || validType == FindType.NeutralActor || validType == FindType.HostileActor)
			{
				selectButtonMask |= 1 << GameGlobal.LayerMapping.NPC;
				selectButtonMask |= 1 << GameGlobal.LayerMapping.Player;
			}

			if (validType == FindType.Any || validType == FindType.RPGObject)
			{
				selectButtonMask |= 1 << GameGlobal.LayerMapping.plyObject;
			}

			if (validType == FindType.Any || validType == FindType.RPGItem)
			{
				selectButtonMask |= 1 << GameGlobal.LayerMapping.plyItem;
			}

			// find a target within range
			Collider[] colliderHits = Physics.OverlapSphere(_tr.position, buttonSelDistance, selectButtonMask);
			if (colliderHits.Length > 0)
			{	// will include only NPC, Object and item as per settings cause of selectButtonMask
				// now find the closest one that is within a specific angle if angle specified

				// create a list of all the hits and how far they are from the target point
				List<Skill.CollectedTarget> collectedTargets = new List<Skill.CollectedTarget>();
				for (int i = 0; i < colliderHits.Length; i++)
				{
					if (colliderHits[i].gameObject == _tr.gameObject) continue; // exclude self
					Targetable target = colliderHits[i].gameObject.GetComponent<Targetable>();
					if (target != null)
					{
						collectedTargets.Add(new Skill.CollectedTarget()
						{
							t = target,
							distance = Vector3.Distance(colliderHits[i].transform.position, _tr.position)
						});
					}
				}

				// sort the objects by distance from the point
				collectedTargets.Sort(delegate(Skill.CollectedTarget a, Skill.CollectedTarget b) { return a.distance.CompareTo(b.distance); });

				// find closest
				for (int i = 0; i < collectedTargets.Count; i++)
				{
					// first check if the target is of correct type if a character
					if (validType == FindType.FriendlyActor || validType == FindType.NeutralActor || validType == FindType.HostileActor)
					{
						Actor actor = collectedTargets[i].t.GetComponent<Actor>();
						if (actor != null)
						{
							StatusTowardsOther st = actor.HighestStatusToTarget(Player.Instance.actor);
							if (validType == FindType.HostileActor && st != StatusTowardsOther.Hostile) continue;
							if (validType == FindType.NeutralActor && st != StatusTowardsOther.Neutral) continue;
							if (validType == FindType.FriendlyActor && st != StatusTowardsOther.Friendly) continue;
						}
						else continue;
					}

					// check if in the specified range
					if (plyUtil.IsInRange(_tr, collectedTargets[i].t.transform.position, buttonSelDistance, buttonSelAngle))
					{
						value = collectedTargets[i].t.gameObject;
						break;
					}
				}
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}