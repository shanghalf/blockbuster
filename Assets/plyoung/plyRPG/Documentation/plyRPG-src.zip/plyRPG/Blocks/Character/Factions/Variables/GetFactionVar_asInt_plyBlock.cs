﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Factions (plyRPG)", "Get Faction Int", BlockType.Variable, Order = 15,
		ShowIcon = "faction", CustomStyle = "plyBlox_VarYellowDark",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value),
		Description = "Return the value of a faction variable as Integer. Returns 0 if the variable was not found or if value was in a type that could not be converted.")]
	public class GetFactionVar_asInt_plyBlock : Int_Value
	{
		[plyBlockField("Get", ShowAfterField = "as Integer", SubName = "Variable Name - String", ShowValue = true, ShowName = false, CustomValueStyle = "plyBlox_BoldLabel", Description = "Name of a faction variable.")]
		public string varName = "var";

		// ---

		[plyBlockField("of", ShowIfTargetFieldInvalid = "faction1", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Faction def.ident - String", Description = "The Faction from which to get the variable. You can choose to either select it from a list or to find it via an def.ident type. Select 'none' in the list to see a field on the Block into which you can put a String Block which identifies the Faction to find.")]
		public String_Value factionIdent1;

		[plyBlockField("of Faction", ShowName = false, ShowValue = false, CustomValueStyle = "plyBlox_BoldLabel")]
		public FactionFieldData faction1 = new FactionFieldData();

		[plyBlockField("Faction ident type", ShowIfTargetFieldInvalid = "faction1", Description = "What kind of value are you using to identify the Faction by? Only needed if you did not pick the Faction from a List.")]
		public plyGameObjectIdentifyingType identType1 = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("in relation to", ShowIfTargetFieldInvalid = "faction2", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", EmptyValueName = "-invalid-", SubName = "Target Faction def.ident - String", Description = "The variable should be in relation to this Faction. You can choose to either select it from a list or to find it via an def.ident type. Select 'none' in the list to see a field on the Block into which you can put a String Block which identifies the Faction to find.")]
		public String_Value factionIdent2;

		[plyBlockField("related to Faction", ShowName = false, ShowValue = false, CustomValueStyle = "plyBlox_BoldLabel")]
		public FactionFieldData faction2 = new FactionFieldData();

		[plyBlockField("Target ident type", ShowIfTargetFieldInvalid = "faction2", Description = "What kind of value are you using to identify the Target Faction by? Only needed if you did not pick the Faction from a List.")]
		public plyGameObjectIdentifyingType identType2 = plyGameObjectIdentifyingType.screenName;

		private UniqueID id1;
		private UniqueID id2;

		public override void Created()
		{
			blockIsValid = !string.IsNullOrEmpty(varName);
			if (!blockIsValid)
			{
				Log(LogType.Error, "The Variable Name must be set.");
				return;
			}

			if (string.IsNullOrEmpty(faction1.id))
			{
				if (factionIdent1 == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Faction 1 is not set.");
					return;
				}
			}
			else
			{
				id1 = new UniqueID(faction1.id);
				factionIdent1 = null; // make sure is null since I use it for test later
			}

			if (string.IsNullOrEmpty(faction2.id))
			{
				if (factionIdent2 == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Faction 2 is not set.");
					return;
				}
			}
			else
			{
				id2 = new UniqueID(faction2.id);
				factionIdent2 = null; // make sure is null since I use it for test later
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			

			ActorFaction f1 = null;
			ActorFaction f2 = null;

			if (factionIdent1 != null) f1 = ActorFactionManager.Instance.GetRuntimeByIdent(factionIdent1.RunAndGetString(), identType1);
			else f1 = ActorFactionManager.Instance.GetRuntimeById(id1);
			if (f1 == null)
			{
				Log(LogType.Error, "Faction 1 not found");
				blockIsValid = false;
				return BlockReturn.Error;
			}

			if (factionIdent2 != null) f2 = ActorFactionManager.Instance.GetRuntimeByIdent(factionIdent2.RunAndGetString(), identType2);
			else f2 = ActorFactionManager.Instance.GetRuntimeById(id2);
			if (f2 == null)
			{
				Log(LogType.Error, "Faction 2 not found");
				blockIsValid = false;
				return BlockReturn.Error;
			}

			try
			{
				value = 0;
				plyVar v = f1.GetFactionVariable(varName, f2);
				if (v != null)
				{
					if (v.TryGetInt(out value))
					{
						return BlockReturn.OK;
					}
					else Log(LogType.Error, "The variable value can't be converted [" + varName + "] [" + v.type + "]");
				}
				else Log(LogType.Error, "The variable could not be found [" + varName + "]");
			}
			catch (System.Exception e) { Log(LogType.Error, e.Message); }
			return BlockReturn.Error;
		}

		// ============================================================================================================
	}
}