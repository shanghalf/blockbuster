﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Idle: Follow", BlockType.Action, Order = 10,
		Description = "Set the target NPC to Follow a specified object when it is in 'idle' mode (not chasing something)")]
	public class NPC_SetIdle_Follow_plyBlock : plyBlock
	{
		[plyBlockField("Set", ShowAfterField = "to: Follow", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("Object to Follow",  ShowValue = true, EmptyValueName = "-invalid-", SubName = "Object to Follow - GameObject", Description = "The object to follow.")]
		public GameObject_Value followGo;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = followGo != null;
			if (!blockIsValid) Log(LogType.Error, "The Object to follow should be set.");
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (npc == null)
				{
					GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
					if (o != null) npc = o.GetComponent<NPCController>();
					if (npc == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
						return BlockReturn.Error;
					}

				}

				npc.Stop();

				GameObject go = followGo.RunAndGetGameObject();
				if (go != null)
				{
					npc.followObject = go.transform;
					npc.idleMode = NPCController.IdleMode.Follow;
				}
				else
				{
					blockIsValid = false;
					Log(LogType.Error, "The object to follow is invalid.");
					return BlockReturn.Error;
				}

				if (false == cacheTarget) npc = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}