﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Get Attribute", BlockType.Variable, Order = 4, ShowName = "Get Attribute",
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns the Attribute's Value, Consumable Value, or Bonus Value for the target Actor object.")]
	public class ActorAttribute_Get_plyBlock : Float_Value
	{
		[plyBlockField("Value Type", ShowValue = true, Description = "Choose to get the Value, ConsumableValue, or Bonus Value of the Attribute. For an attribute like Strength or Wisdom you would only be interested in the 'Value'. With attributes like Health, Experience, Mana Points, etc, the 'Value' is the current max the attribute's 'Consumable Value' can reach. So, when you want to see what the health is at currently, you would read the 'Consumable Value' and if you wanted to know what 'full health' is you would read 'Value'.")]
		public ActorAttribute.ValueType valueType = ActorAttribute.ValueType.Value;

		[plyBlockField("Attribute", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public string attribName = "";

		[plyBlockField("Ident Type", Description = "What kind of value did you enter in the previous field to identify the Attribute by?")]
		public plyGameObjectIdentifyingType identType = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ActorAttribute attrib = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		private void GetAttribute()
		{
			Actor actor = null;
			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			if (o != null)
			{
				actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
					return;
				}
			}

			attrib = actor.actorClass.GetAttribute(attribName, identType);
			if (attrib == null)
			{
				blockIsValid = false;
				Log(LogType.Error, "The Attribute [" + attribName + "] could not be found on the Actor [" + actor.ObjectPrettyName() + "]");
				return;
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (attrib == null)
			{
				GetAttribute();
				if (false == blockIsValid) return BlockReturn.Error;
			}

			//value = valueType == ActorAttribute.ValueType.Value ? attrib.Value : attrib.ConsumableValue;
			if (valueType == ActorAttribute.ValueType.ConsumableValue)
			{
				value = attrib.ConsumableValue;
			}
			else if (valueType == ActorAttribute.ValueType.Value)
			{
				value = attrib.Value;
			}
			else if (valueType == ActorAttribute.ValueType.Bonus)
			{
				value = attrib.BonusValue;
			}

			if (false == cacheTarget) attrib = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}