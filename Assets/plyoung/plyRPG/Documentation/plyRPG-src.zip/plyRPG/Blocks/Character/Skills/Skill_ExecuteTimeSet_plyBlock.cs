﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Skills (plyRPG)", "Set Execution Time", BlockType.Action, Order = 6, ShowName = "Set Execution Time",
		Description = "Set the Execution Time of the Skill on the specified Actor. Will not reset any running Execution progress.")]
	public class Skill_ExecuteTimeSet_plyBlock : Float_Value
	{
		[plyBlockField("of Skill", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to check.")]
		public SystemObject_Value val;

		[plyBlockField("on", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has an Actor component.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, EmptyValueName = "-1-", SubName = "Value - Float", Description = "Time in seconds.")]
		public Float_Value targetVal;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = val != null;
			if (!blockIsValid) Log(LogType.Error, "The Skill field should be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = val.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			Skill knownSkill = actor.GetKnownSkill(skill);
			if (knownSkill != null)
			{
				knownSkill.executionTimeout = targetVal == null ? 1f : targetVal.RunAndGetFloat();
			}
			else
			{
				Log(LogType.Error, "The Skill is not known by the Actor.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget) actor = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}