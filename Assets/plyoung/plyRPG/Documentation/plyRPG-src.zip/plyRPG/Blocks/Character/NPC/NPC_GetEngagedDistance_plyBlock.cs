﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Get Engaged Distance", BlockType.Variable, Order = 10, ShowName = "Get distance to engaged",
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns the distance of the detected character, that is at the specified index in the list of detected character, from the NPC. Detected characters are sorted from closest to furthest from the NPC. The list of detected characters is only updated when the NPC does detection so the bets place to use this is ion the `NPC > On Detected Characters` as the list is not continuously updated for other events.")]
	public class NPC_GetEngagedDistance_plyBlock : Float_Value
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (npc == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null) npc = o.GetComponent<NPCController>();
				if (npc == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
					blockIsValid = false;
					return BlockReturn.OK;
				}

			}

			if (npc.selectedTarget != null)
			{
				value = Vector3.Distance(npc.transform.position, npc.selectedTarget.transform.position);
			}
			else value = 0.0f;

			if (false == cacheTarget) npc = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}