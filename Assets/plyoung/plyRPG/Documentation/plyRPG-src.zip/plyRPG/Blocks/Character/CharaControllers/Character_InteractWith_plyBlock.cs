﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Interact With", BlockType.Action, Order = 5,
		Description = "Ask the character to interact with target interactable.")]
	public class Character_InteractWith_plyBlock : plyBlock
	{
		[plyBlockField("Request",ShowAfterField="to Interact",  ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Subject - GameObject", Description = "Should be object that has a plyGame Character Controller component.")]
		public GameObject_Value subjectVal;

		[plyBlockField("with", ShowName = true, ShowValue = true, DefaultObject = typeof(GameObject_Value), EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Targetable type like Character or Item.")]
		public GameObject_Value targetVal;

		[plyBlockField("Cache subject", Description = "Tell plyBlox if it can cache a reference to the Subject Object, if you know it will not change, improving performance a little. This is done either way when the subject is -self-")]
		public bool cacheSubject = false;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private CharacterControllerBase subject = null;
		private Targetable target = null;
		private GameObject so = null, to = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = true;
			if (subjectVal == null) cacheSubject = true;
			if (targetVal == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (subject == null)
			{
				so = subjectVal == null ? owningBlox.gameObject : subjectVal.RunAndGetGameObject();
				if (so != null)
				{
					subject = so.GetComponent<CharacterControllerBase>();
					if (subject == null)
					{
						Log(LogType.Error, "The Subject is invalid. Could not find any plyGame related Character Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			if (target == null)
			{
				to = targetVal == null ? owningBlox.gameObject : targetVal.RunAndGetGameObject();
				if (to != null)
				{
					target = to.GetComponent<Targetable>();
					if (target == null)
					{
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame Targetable related component on it.");
						return BlockReturn.Error;
					}
				}
			}

			if (so == to)
			{
				Log(LogType.Error, "The Subject and Target should not be the same object.");
				return BlockReturn.Error;
			}

			subject.SetTargetInteract(target);
			//character.RequestMoveTo(location.RunAndGetVector3(), run);

			if (false == cacheTarget) target = null;
			if (false == cacheSubject) subject = null;
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}