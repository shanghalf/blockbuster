﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Get Engaged", BlockType.Variable, Order = 10, ShowName = "Get Engaged",
		ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns the character that the NPC is engaged with (attacking/ interacting with)")]
	public class NPC_GetEngaged_plyBlock : GameObject_Value
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (npc == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null) npc = o.GetComponent<NPCController>();
				if (npc == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
					return BlockReturn.Error;
				}

			}

			value = npc.selectedTarget == null ? null : npc.selectedTarget.gameObject;

			if (false == cacheTarget) npc = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}