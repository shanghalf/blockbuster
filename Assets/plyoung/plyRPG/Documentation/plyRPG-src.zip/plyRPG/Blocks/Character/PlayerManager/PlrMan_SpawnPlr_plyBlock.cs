﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "PlayerMan (plyRPG)", "Spawn Player", BlockType.Action, Order = 2, ShowName = "Spawn Player",
		Description = "Instruct the Player Manager to spawn a Player character in the scene. This call will silently fail if there is already a player character in the scene.")]
	public class PlrMan_SpawnPlr_plyBlock : plyBlock
	{

		[plyBlockField("at", ShowName = true, ShowValue = true, EmptyValueName = "-0x0x0-", SubName = "Location - GaemObject", Description = "A target object which's position and rotation should be used when spawning the character. This can be any object in the scene.")]
		public GameObject_Value obj;

		[plyBlockField("with ident", ShowName = true, ShowValue = true, EmptyValueName = "player", SubName = "Ident - String", Description = "The 'ident' defaults to 'player' and is the key used when loading/ saving player character data. You do not normally have to change this.")]
		public String_Value ident;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (PlayerManager.Instance == null)
			{
				Log(LogType.Error, "The Player Manager is not active. Make sure you've set it up correctly.");
				return BlockReturn.Error;
			}

			GameObject go = obj == null ? null : obj.RunAndGetGameObject(); 
			PlayerManager.Instance.SpawnPlayer(ident != null ? ident.RunAndGetString() : "player", (go == null ? null : go.transform));
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}