﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "PlayerMan (plyRPG)", "Get Player Art Prefab", BlockType.Variable, Order = 2,
		ReturnValueType = typeof(GameObject_Value), ReturnValueString = "Returns - GameObject", CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return reference to the Player Art Prefab from the Player Manager.")]
	public class PlrMan_GetPlrArtPrefab_plyBlock : GameObject_Value
	{
		[plyBlockField("Get Art Prefab", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Index - Integer", Description = "The index into the list of defined Art Prefabs, starting at (0)")]
		public Int_Value idx;

		[plyBlockField("of Player", ShowAfterField = "in Player Manager", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Player Index - Integer", Description = "The index into the list of defined Player Prefabs, starting at (0)")]
		public Int_Value idxplr;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = idx != null && idxplr != null;
			if (!blockIsValid) Log(LogType.Error, "The index fields must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = PlayerManager.Instance.GetPlayerArtPrefab(idxplr.RunAndGetInt(), idx.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}