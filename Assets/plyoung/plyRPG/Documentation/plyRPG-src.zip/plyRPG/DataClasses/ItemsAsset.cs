﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> Contains the defined Items. </summary>
	[System.Serializable]
	public class ItemsAsset : ScriptableObject
	{
		[HideInInspector] public List<GameObject> itemFabs = new List<GameObject>();			//!< List of all defined item prefabs
		[HideInInspector, System.NonSerialized] public List<Item> items = new List<Item>(0);	//!< Runtime access to defined Items

		public enum StorageMethod
		{
			Unlimited, Weight, Slots
		}

		[HideInInspector] public StorageMethod storageMethod = StorageMethod.Weight;
		[HideInInspector] public float autoPickItemDisableDistance = 20f; //!< items that can be auto picked up is disabled when further than this from player

		[HideInInspector] public List<ItemType> itemTypes = new List<ItemType>(1);	//!< The defined Item Types
		[HideInInspector] public List<string> equipSlots = new List<string>(1);		//!< The defined Equip Slots names

		[HideInInspector] public bool runtimeCreatedItemsPersist = true; //!< Should Items created at runtime be restored after scene changes?

		// ============================================================================================================

		/// <summary> Provide access to asset at runtime </summary>
		public static ItemsAsset Instance
		{
			get
			{
				if (_instance == null)
				{	// try to get reference to the asset
					_instance = (ItemsAsset)GameGlobal.Instance.GetAsset<ItemsAsset>();					
					// create a fake if no real asset exist
					if (_instance == null)
					{
						Debug.LogWarning("Item System Settings not present. Using defaults.");
						_instance = ScriptableObject.CreateInstance<ItemsAsset>();
					}
				}
				return _instance;
			}
		}
		private static ItemsAsset _instance;

		public bool UpdateItemCache()
		{
			bool ret = false;

			// first check if there are "null" entries and remove them now
			if (itemFabs.Count > 0)
			{
				for (int i = itemFabs.Count - 1; i >= 0; i--)
				{
					if (itemFabs[i] == null)
					{
						ret = true;
						itemFabs.RemoveAt(i);
						continue;
					}

					if (itemFabs[i].GetComponent<Item>() == null)
					{
						ret = true;
						itemFabs.RemoveAt(i);
						continue;
					}
				}
			}

			items = new List<Item>(itemFabs.Count);
			for (int i = 0; i < itemFabs.Count; i++)
			{
				items.Add(itemFabs[i].GetComponent<Item>());
			}

			return ret;
		}

		/// <summary> Get definition by its Id. Return null if Id is invalid or definition not found. </summary>
		public Item GetDefinition(UniqueID id)
		{
			if (id.IsEmpty) return null;
			if (items.Count != itemFabs.Count) UpdateItemCache();
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].prefabId == id) return items[i];
			}
			return null;
		}

		/// <summary> Get the defined by its name, custom def.ident or def.meta data. Return null if not found. </summary>
		public Item GetDefinition(string ident, plyGameObjectIdentifyingType identType)
		{
			if (string.IsNullOrEmpty(ident)) return null;
			if (items.Count != itemFabs.Count) UpdateItemCache();
			if (identType == plyGameObjectIdentifyingType.ident)
			{
				for (int i = 0; i < items.Count; i++) if (items[i].def.ident.Equals(ident)) return items[i];
			}
			if (identType == plyGameObjectIdentifyingType.screenName)
			{
				for (int i = 0; i < items.Count; i++) if (items[i].def.screenName.Equals(ident)) return items[i];
			}
			if (identType == plyGameObjectIdentifyingType.shortName)
			{
				for (int i = 0; i < items.Count; i++) if (items[i].def.shortName.Equals(ident)) return items[i];
			}
			if (identType == plyGameObjectIdentifyingType.meta)
			{
				for (int i = 0; i < items.Count; i++) if (items[i].def.meta.Equals(ident)) return items[i];
			}
			return null;
		}

		/// <summary> Get an definition's index in the list by Id. Return -1 if not found. </summary>
		public int GetDefinitionIdx(UniqueID id)
		{
			if (id.IsEmpty) return -1;
			if (items.Count != itemFabs.Count) UpdateItemCache();
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].prefabId == id) return i;
			}
			return -1;
		}

		/// <summary> Return the screen name of an definition. Return "-invalid-" if not found. </summary>
		public string GetScreenName(UniqueID id)
		{
			if (id.IsEmpty) return "-invalid-";
			if (items.Count != itemFabs.Count) UpdateItemCache();
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].prefabId == id) return string.IsNullOrEmpty(items[i].def.screenName) ? items[i].name : items[i].def.screenName;
			}
			return "-invalid-";
		}

		/// <summary> Returns a list of names of all defined items. </summary>
		public string[] GetNames()
		{
			if (items.Count != itemFabs.Count) UpdateItemCache();
			string[] n = new string[items.Count];
			for (int i = 0; i < n.Length; i++) n[i] = string.IsNullOrEmpty(items[i].def.screenName) ? items[i].name : items[i].def.screenName;
			return n;
		}

		// ============================================================================================================
	}
}