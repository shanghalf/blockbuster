﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> Contains a list of the defined markers that where detected. </summary>
	[System.Serializable]
	public class MarkersAsset : ScriptableObject
	{
		[HideInInspector] public List<GameObject> markerFabs = new List<GameObject>(0); //!< List of detected prefabs.

		// ============================================================================================================

		[HideInInspector, System.NonSerialized]
		public List<Marker> markers = new List<Marker>(0); //!< List of the actual objects. Should call UpdateCache() or UpdateCacheIfNeeded() before using this for first time.

		/// <summary> Provide access to asset at runtime </summary>
		public static MarkersAsset Instance
		{
			get
			{
				if (_instance == null)
				{	// try to get reference to the asset
					_instance = (MarkersAsset)GameGlobal.Instance.GetAsset<MarkersAsset>();
					// create a fake if no real asset exist
					if (_instance == null) _instance = ScriptableObject.CreateInstance<MarkersAsset>();
				}
				return _instance;
			}
		}
		private static MarkersAsset _instance;

		/// <summary> Updates the list of skills from skillFabs list. </summary>
		public void UpdateCacheIfNeeded()
		{
			if (markerFabs.Count > markers.Count) UpdateCache();
		}

		/// <summary> Updates the list of skills from skillFabs list. return true if markerFabs list contained null entries. </summary>
		public bool UpdateCache()
		{
			bool ret = false;

			// first check if there are "null" entries and remove them now
			if (markerFabs.Count > 0)
			{
				for (int i = markerFabs.Count - 1; i >= 0; i--)
				{
					if (markerFabs[i] == null)
					{
						ret = true;
						markerFabs.RemoveAt(i);
						continue;
					}

					if (markerFabs[i].GetComponent<Marker>() == null)
					{
						ret = true;
						markerFabs.RemoveAt(i);
						continue;
					}
				}
			}

			markers = new List<Marker>(markerFabs.Count);
			for (int i = 0; i < markerFabs.Count; i++)
			{
				markers.Add(markerFabs[i].GetComponent<Marker>());
			}

			return ret;
		}

		/// <summary> Gets the prefab by Id. Return null if failed. </summary>
		public GameObject GetPrefab(UniqueID id)
		{
			Marker s = GetDefinition(id);
			if (s != null) return s.gameObject;
			return null;
		}

		/// <summary> Gets the prefab by name. Return null if failed. </summary>
		public GameObject GetPrefab(string name)
		{
			Marker s = GetDefinition(name);
			if (s != null) return s.gameObject;
			return null;
		}

		/// <summary> Gets the definition by Id. Return null if failed. </summary>
		public Marker GetDefinition(UniqueID id)
		{
			if (id.IsEmpty) return null;
			if (markerFabs.Count > markers.Count) UpdateCache();
			for (int i = 0; i < markers.Count; i++)
			{
				if (markers[i].id == id) return markers[i];
			}
			return null;
		}

		/// <summary> Get the defined by its name. Return null if not found. </summary>
		public Marker GetDefinition(string name)
		{
			if (string.IsNullOrEmpty(name)) return null;
			for (int i = 0; i < markers.Count; i++) if (markers[i].name.Equals(name)) return markers[i];
			return null;
		}

		/// <summary> Get the defined by its name. Return UniqueID.Empty if not found. </summary>
		public UniqueID GetDefinitionUniqueId(string name)
		{
			Marker s = GetDefinition(name);
			if (s != null) return s.id;
			return UniqueID.Empty;
		}

		/// <summary> Get the defined by its index in list. Return UniqueID.Empty if not found. </summary>
		public UniqueID GetDefinitionUniqueId(int idx)
		{
			if (idx < 0 || idx >= markers.Count) return UniqueID.Empty;
			return markers[idx].id;
		}

		/// <summary> Get the definition index into the list by its Id. Return -1 if not found. </summary>
		public int GetDefinitionIdx(UniqueID id)
		{
			if (id == null) return -1;
			if (id.IsEmpty) return -1;
			if (markerFabs.Count > markers.Count) UpdateCache();
			for (int i = 0; i < markers.Count; i++)
			{
				if (markers[i].id == id) return i;
			}
			return -1;
		}

		/// <summary> Get name by Id. Return "-invalid-" if not found. </summary>
		public string GetScreenName(UniqueID id)
		{
			if (id.IsEmpty) return "-invalid-";
			if (markerFabs.Count > markers.Count) UpdateCache();
			for (int i = 0; i < markers.Count; i++)
			{
				if (markers[i].id == id) return markers[i].name;
			}
			return "-invalid-";
		}

		/// <summary> Get a list of names of all defined. </summary>
		public string[] GetNames()
		{
			if (markerFabs.Count > markers.Count) UpdateCache();
			string[] n = new string[markers.Count];
			for (int i = 0; i < n.Length; i++) n[i] = markers[i].name;
			return n;
		}

		// ============================================================================================================
	}
}