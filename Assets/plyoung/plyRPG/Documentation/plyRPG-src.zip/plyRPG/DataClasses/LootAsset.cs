﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Contains the loot tables. </summary>
	[System.Serializable]
	public class LootAsset : ScriptableObject
	{

		[System.Serializable]
		public class Loot
		{
			public enum LootType { Item = 1, Attribute = 2, EventTrigger = 3 }
			public LootType type = LootType.Item;
			public int count = 1;
			public UniqueID id = UniqueID.Empty; // ID of the Item or Attribute
			public float chance = 100f;	// 0% to 100%
			public bool lookatNpcLevel = false;
			public int npcLevelCheck = 1;
			public int group = 0;

			public string eventName = "";
			public string param1 = "";
			public int bloxOf = 0; // 0: player, 1: subject object that was send

			[System.NonSerialized] public string _nameCache = "";

			public Loot Copy()
			{
				Loot l = new Loot();
				l.type = this.type;
				l.count = this.count;
				l.id = this.id.Copy();
				l.chance = this.chance;
				l.lookatNpcLevel = this.lookatNpcLevel;
				l.npcLevelCheck = this.npcLevelCheck;
				l.group = this.group;
				l.eventName = this.eventName;
				l.param1 = this.param1;
				l.bloxOf = this.bloxOf;
				return l;
			}
		}

		[System.Serializable]
		public class LootTable
		{
			public string name;
			public List<Loot> loot = new List<Loot>();

			public LootTable Copy()
			{
				LootTable lt = new LootTable();
				lt.name = this.name;
				lt.loot = new List<Loot>(this.loot.Count);
				for (int i = 0; i < this.loot.Count; i++) lt.loot.Add(this.loot[i].Copy());
				return lt;
			}

			public override string ToString()
			{
				return name;
			}
		}

		public List<LootTable> lootTables = new List<LootTable>();

		// ============================================================================================================

		/// <summary> Provide access to asset at runtime </summary>
		public static LootAsset Instance
		{
			get
			{
				if (_instance == null)
				{	// try to get reference to the asset
					_instance = (LootAsset)GameGlobal.Instance.GetAsset<LootAsset>();					
					// create a fake if no real asset exist
					if (_instance == null)
					{
						Debug.LogWarning("Loot Tables not defined. Using defaults.");
						_instance = ScriptableObject.CreateInstance<LootAsset>();
					}
				}
				return _instance;
			}
		}
		private static LootAsset _instance;

		// ============================================================================================================

		public bool DropLoot(string name, Vector3 fromPos, GameObject subject)
		{
			if (string.IsNullOrEmpty(name))
			{
				Debug.LogError("No Loot Table name specified.");
				return false;
			}

			LootTable lt = null;
			for (int i = 0; i < lootTables.Count; i++)
			{
				if (name.Equals(lootTables[i].name))
				{
					lt = lootTables[i]; break;
				}
			}

			if (lt == null)
			{
				Debug.LogError("The named Loot Table could not be found: " + name);
				return false;
			}

			// group up rewards
			Dictionary<int, List<int>> groups = new Dictionary<int, List<int>>();
			for (int i = 0; i < lt.loot.Count; i++)
			{
				if (lt.loot[i].group != 0)
				{
					if (!groups.ContainsKey(lt.loot[i].group))
					{
						List<int> rg = new List<int>();
						rg.Add(i);
						groups.Add(lt.loot[i].group, rg);
					}
					else
					{
						groups[lt.loot[i].group].Add(i);
					}
				}
			}

			// drop grouped rewards
			if (groups.Count > 0)
			{
				foreach (List<int> g in groups.Values)
				{
					int i = g.Count > 1 ? Random.Range(0, g.Count) : 0;
					Drop(lt, lt.loot[i], fromPos, subject, false);
				}
			}

			// drop ungrouped rewards
			for (int i = 0; i < lt.loot.Count; i++)
			{
				if (lt.loot[i].group == 0)
				{
					Drop(lt, lt.loot[i], fromPos, subject, false);
				}
			}

			return true;
		}

		public bool DropLootToPlayerBag(string name, GameObject subject)
		{
			if (string.IsNullOrEmpty(name))
			{
				Debug.LogError("No Loot Table name specified.");
				return false;
			}

			LootTable lt = null;
			for (int i = 0; i < lootTables.Count; i++)
			{
				if (name.Equals(lootTables[i].name))
				{
					lt = lootTables[i]; break;
				}
			}

			if (lt == null)
			{
				Debug.LogError("The named Loot Table could not be found: " + name);
				return false;
			}

			// group up rewards
			Dictionary<int, List<int>> groups = new Dictionary<int, List<int>>();
			for (int i = 0; i < lt.loot.Count; i++)
			{
				if (lt.loot[i].group != 0)
				{
					if (!groups.ContainsKey(lt.loot[i].group))
					{
						List<int> rg = new List<int>();
						rg.Add(i);
						groups.Add(lt.loot[i].group, rg);
					}
					else
					{
						groups[lt.loot[i].group].Add(i);
					}
				}
			}

			// drop grouped rewards
			if (groups.Count > 0)
			{
				foreach (List<int> g in groups.Values)
				{
					int i = g.Count > 1 ? Random.Range(0, g.Count) : 0;
					Drop(lt, lt.loot[i], Vector3.zero, subject, true);
				}
			}

			// drop ungrouped rewards
			for (int i = 0; i < lt.loot.Count; i++)
			{
				if (lt.loot[i].group == 0)
				{
					Drop(lt, lt.loot[i], Vector3.zero, subject, true);
				}
			}

			return true;
		}

		private void Drop(LootTable table, Loot lt, Vector3 pos, GameObject subject, bool toBag)
		{
			if (lt.id == UniqueID.Empty && lt.type != Loot.LootType.EventTrigger)
			{
				Debug.LogError("No Attribute or Item selected for the reward defined in Loot Table: " + table.name);
				return;
			}

			// check if NPC level valid
			if (lt.lookatNpcLevel)
			{
				Actor ac = subject != null ? subject.GetComponent<Actor>() : null;
				int lv = ac == null ? 0 : ac.actorClass.currLevel;
				if (lv < lt.npcLevelCheck) return;
			}

			// check if chance to drop
			if (!CanSpawnOnChance(lt.chance)) return;

			// give the reward
			if (lt.type == Loot.LootType.Attribute)
			{
				ActorAttribute att = Player.Instance.actor.actorClass.GetAttribute(lt.id);
				if (att != null)
				{
					att.ChangeBaseValueBy(lt.count);
				}
				else
				{
					Debug.LogError("Attribute not found on Player. Defined as reward in Loot Table: " + table.name);
					return;
				}
			}

			// drop the loot
			else if (lt.type == Loot.LootType.Item && lt.count > 0)
			{
				Item itFab = ItemsAsset.Instance.GetDefinition(lt.id);
				if (itFab != null)
				{
					if (toBag)
					{
						ItemBag bag = Player.Instance.gameObject.GetComponent<ItemBag>();
						if (bag != null)
						{
							bag.AddItemToBag(itFab, lt.count);
						}
						else
						{
							Debug.LogError("The Player has no Item Bag component to drop loot items into.");
							return;
						}
					}
					else
					{
						for (int i = 0; i < lt.count; i++)
						{
							Vector2 v2 = Random.insideUnitCircle;
							Vector3 v = new Vector3(v2.x, 0f, v2.y);
							Item it = Item.CreateItem(itFab.prefabId, Item.ItemLocation.Scene, pos, Quaternion.identity, null, true, v);
							if (it == null)
							{
								Debug.LogError("Error while trying to create Item [" + itFab.ToString() + "]. Defined as reward in Loot Table: " + table.name);
								return;
							}
						}
					}
				}
				else
				{
					Debug.LogError("Item Definition not found. It might have been removed and the loot tables where not updated. Defined as reward in Loot Table: " + table.name);
					return;
				}
			}

			// trigger event
			else if (lt.type == Loot.LootType.EventTrigger)
			{
				GameObject target = lt.bloxOf == 0 ? Player.Instance.gameObject : subject;
				if (target != null)
				{
					plyBlox blox = target.GetComponent<plyBlox>();
					if (blox != null)
					{
						plyEvent ev = blox.GetEvent(lt.eventName);
						if (ev != null)
						{
							ev.SetTempVarValue("param1", lt.param1);
							blox.RunEvent(ev);
						}
						else
						{
							Debug.LogError("The Target for the Event Trigger does not have an Event named: " + lt.eventName);
							return;
						}
					}
					else
					{
						Debug.LogError("The Target for the Event Trigger has no Blox.");
						return;
					}
				}
				else
				{
					Debug.LogError("The Target for the Event Trigger is invalid.");
					return;
				}
			}

		}
	
		private static bool CanSpawnOnChance(float chance)
		{
			if (chance == 0f) return false;
			if (chance == 100f) return true;
			if (Random.Range(0f, 100f) <= chance) return true;
			return false;
		}

		// ============================================================================================================
	}
}