﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/NPC/Movement/Pro-Move (navmesh)")]
	[RequireComponent(typeof(NavMeshAgent))]
	public class NPCMovePro : NPCMoveBase
	{
		public NavMeshAgent agent;

		// ============================================================================================================

		private Transform _tr;
		private bool forceTurning = false;
		private Vector3 targetDirection = Vector3.zero;
		private Vector3 forward = Vector3.zero;
		private float turnSpeed = 0f;
		private bool isMoving = false;
		private int navLayer = 0;

		// ============================================================================================================

		protected void Reset()
		{
			Setup();
			if (agent)
			{
				agent.acceleration = 60f;
				agent.speed = 0f;
				agent.angularSpeed = 0f;
				agent.stoppingDistance = 1f;
			}
		}

		protected void Awake()
		{
		}

		protected void Start()
		{
			Setup();

			if (agent == null)
			{
				Debug.LogError("[NPCMovePro] No NavMeshAgent assigned.");
				enabled = false;
				return;
			}

#if UNITY5
			navLayer = (1 << NavMesh.GetAreaFromName("Default"));
#else
			navLayer = (1 << NavMesh.GetNavMeshLayerFromName("Default"));
#endif
			_tr = agent.transform;
		}

		private void Setup()
		{
			if (agent == null) agent = GetComponent<NavMeshAgent>();
		}

		protected void OnEnable()
		{
			if (agent) agent.enabled = true;
		}

		protected void OnDisable()
		{
			if (agent) agent.enabled = false;
		}

		protected void Update()
		{
			if (GameGlobal.Paused)
			{
				if (isMoving) Stop();
				return;
			}

			if (null == agent) return;
			if (false == agent.enabled) return;

			if (forceTurning)
			{
				forward = Vector3.RotateTowards(_tr.forward, targetDirection, turnSpeed * Time.deltaTime, 0.0f);
				_tr.rotation = Quaternion.LookRotation(forward);
				if (Vector3.Dot(_tr.forward, targetDirection) > 0.98f) forceTurning = false;
			}

			if (isMoving)
			{
				if (false == agent.pathPending && agent.remainingDistance <= agent.stoppingDistance)
				{
					Stop();
				}
			}
		}

		// ============================================================================================================

		public override void MoveTo(Vector3 pos, float moveSpeed, float turnSpeed)
		{
			forceTurning = false;
			if (agent == null) return;
			if (agent.enabled)
			{
				// check if target pos will be on the navmesh, else get closest point
				NavMeshHit n;
				if (NavMesh.SamplePosition(pos, out n, 5f, navLayer))
				{
					// issue move
					isMoving = true;
					agent.speed = moveSpeed;
					agent.angularSpeed = turnSpeed;
					agent.destination = n.position;
					agent.SetDestination(pos);
				}
				else
				{
					Debug.LogError("The NPC was asked to move to a point that is not near or on the navmesh: " + pos);
				}
			}
		}

		public override void FaceDirection(Vector3 direction, float turnSpeed)
		{
			this.turnSpeed = turnSpeed / 100f; // this speed might be set quite high to work with NavAgent, so div it
			targetDirection = direction;
			forceTurning = true;
		}

		public override void Stop()
		{
			isMoving = false;
			forceTurning = false;
			if (agent == null) return;
			if (agent.enabled)
			{
				agent.Stop();
				agent.ResetPath();
			}
		}

		public override Vector3 Velocity()
		{
			if (!isMoving) return Vector3.zero;
			return agent.velocity;
		}

		public override Vector3 DesiredVelocity()
		{
			if (!isMoving) return Vector3.zero;
			return agent.desiredVelocity;
		}

		public override void UpdateVelocity(Vector3 v)
		{
			agent.velocity = v;
		}

		public override bool Grounded()
		{
			return true;
		}

		public override bool IsMovingOrPathing()
		{
			return isMoving;
			//if (agent == null) return false;
			//if (!agent.enabled) return false;
			//return (agent.pathPending || agent.remainingDistance > agent.stoppingDistance);
		}

		public override bool InControlledTurn()
		{
			return forceTurning;
		}

		// ============================================================================================================
	}
}