﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Player character controller base class. You can choose to either derive from this or
	///  CharacterControllerbase. This class contain some useful helpers that you would have to re-
	///  implement if deriving a player controller from CharacterControllerbase. </summary>
	[AddComponentMenu("")]
	public class PlayerBaseController : CharacterControllerBase
	{
		public bool canMouseSelect = true;		//!< can the player make selections with the mouse
		public bool canMouseSelActor = true;	//!< can the player select characters/ actors with the mouse
		public bool canMouseSelItem = true;		//!< can the player select items with the mouse
		public bool canMouseSelObject = true;   //!< can the player select objects with the mouse
		public float mouseSelDistance = 100f;   //!< how far from the character mouse selection be performed
		public int mouseSelAngle = 360;			//!< at what angle from character's forward can selection be done? (0 to 360) ( <=0 || >=360 will assume 360 )
		public bool clearSelectedOnFloorClick = true; //!< Clear selected when click on floor

		public bool canButtonSelect = true;		//!< can the player make selection with buttons (like TAB)
		public bool canButtonSelActor = true;   //!< can the player select/ target characters (actors) with a button
		public bool canButtonSelItem = true;	//!< can the player select an item with a button
		public bool canButtonSelObject = true;  //!< can the player select an object with a button
		public float buttonSelDistance = 10f;   //!< how far from the character can button selection be performed
		public int buttonSelAngle = 60;			//!< at what angle from character's forward can selection be done? (0 to 360) (<=0 || >= 360 will assume 360)

		public bool autoMoveToInteract = true;	//!< should character move closer to target selected to interact with?
		public bool movementCanStopInteraction = true; //!< Can movement call the Interact Stop events?

		public bool itemSelectInteract = true;	//!< is item selection the same as interaction?

		public bool persistActionSlotBinds = true;	//!< auto restore the skill and item binds of action bar?
		public int actionSlotCount = 10;		//!< how many action slots there are

		// ============================================================================================================

		protected LayerMask floorClickMask;		//!< used when detecting a floor click (it is set up such to ignore certain layers while not allowing click-through others so must still check if was actually Floor layer that was clicked)
		protected LayerMask selectClickMask;	//!< used when detecting click on targetable
		protected LayerMask selectButtonMask;	//!< used when finding targetable(s) around character

		private List<Targetable> prevButtonSelected = new List<Targetable>(0);

		protected FollowTargetObject selNPCFriendly = null;
		protected FollowTargetObject selNPCNeutral = null;
		protected FollowTargetObject selNPCHostile = null;
		protected FollowTargetObject selObject = null;
		protected FollowTargetObject selItem = null;
		protected FollowTargetObject activeSelector = null;

		protected int Key_ClickSelectTarget = -1;
		protected int Key_SelectNextTarget = -1;
		protected int Key_TargetClear = -1;
		protected int Key_ClickInteract = -1;
		protected int Key_Interact = -1;

		private int waitFrame = 2;

		public ActionSlots actionSlots { get; private set; }

		// ============================================================================================================

		protected void Reset()
		{
			gameObject.layer = GameGlobal.LayerMapping.Player;

			// make sure actor is set correctly (i do this in actor.reset too but it seems to get missed sometimes)
			Actor a = GetComponent<Actor>();
			if (a != null)
			{
				a.objectDestroyer.method = ObjectDestroyerHandler.DestroyMethod.DoNothing;
				a.persistActorData = true;
				a.persistClass = true;
				a. persistKnowSkills = true;
			}

			// check if the persistence object is present and set it up if so
			PersistableObject p = gameObject.GetComponent<PersistableObject>();
			if (p != null)
			{
				p.persistDestroyedState = false;
				p.persistActiveState = false;
			}
		}

		new protected void Awake()
		{
			base.Awake();
			gameObject.layer = GameGlobal.LayerMapping.Player;
			Player.Instance = this; // Tell Global that this is the Player
			waitFrame = 2;
			actionSlots = new ActionSlots();
			actionSlots.Init(actionSlotCount, actor);
		}

		new protected void Start()
		{
			base.Start();

			gameObject.layer = GameGlobal.LayerMapping.Player;

			// set the floor mask so that player can't click through NPCs or plyObjects. Clicks on these layers will be caught but ignored
			// by the click check code since it will only respond to floor click. Thus preventing click-through on the layers inserted here.
			floorClickMask = (1 << GameGlobal.LayerMapping.Floor | 1 << GameGlobal.LayerMapping.NPC | 1 << GameGlobal.LayerMapping.plyObject);
			if (autoMoveToInteract) floorClickMask |= 1 << GameGlobal.LayerMapping.plyItem;
			//floorClickMask = ~(1 << GameGlobal.LayerMapping.Player | 1 << GameGlobal.LayerMapping.plyTrigger | 1 << GameGlobal.LayerMapping.Wall);

			// setup selection options
			selectClickMask = 0;
			if (canMouseSelActor) selectClickMask = selectClickMask.IncludeLayer(GameGlobal.LayerMapping.NPC);
			if (canMouseSelItem) selectClickMask = selectClickMask.IncludeLayer(GameGlobal.LayerMapping.plyItem);
			if (canMouseSelObject) selectClickMask = selectClickMask.IncludeLayer(GameGlobal.LayerMapping.plyObject);

			selectButtonMask = 0;
			if (canButtonSelActor) selectButtonMask = selectButtonMask.IncludeLayer(GameGlobal.LayerMapping.NPC);
			if (canButtonSelItem) selectButtonMask = selectButtonMask.IncludeLayer(GameGlobal.LayerMapping.plyItem);
			if (canButtonSelObject) selectButtonMask = selectButtonMask.IncludeLayer(GameGlobal.LayerMapping.plyObject);

			// create the selection markers
			PlayerSelectorsAsset sa = (PlayerSelectorsAsset)GameGlobal.Instance.GetAsset<PlayerSelectorsAsset>();
			if (sa != null)
			{
				GameObject[] fabs = new GameObject[]
				{
					MarkersAsset.Instance.GetPrefab(sa.friendlyNPC),
					MarkersAsset.Instance.GetPrefab(sa.neutralNPC),
					MarkersAsset.Instance.GetPrefab(sa.hostileNPC),
					MarkersAsset.Instance.GetPrefab(sa.interactObject),
					MarkersAsset.Instance.GetPrefab(sa.item),
				};

				FollowTargetObject[] sels = new FollowTargetObject[fabs.Length];

				for (int i = 0; i < fabs.Length; i++)
				{
					if (fabs[i] == null) continue;

					// first check if the marker not already created for another marker and simply reuse that
					for (int j = 0; j < i; j++)
					{
						if (fabs[i] == fabs[j])
						{
							sels[i] = sels[j];
							break;
						}
					}

					// create marker object
					if (sels[i] == null)
					{
						GameObject go = (GameObject)Instantiate(fabs[i]);
						go.SetActive(false);
						go.name = "Player_Selector_" + i;
						sels[i] = go.AddComponent<FollowTargetObject>();
					}
				}

				if (sels[0] != null) selNPCFriendly = sels[0];
				if (sels[1] != null) selNPCNeutral = sels[1];
				if (sels[2] != null) selNPCHostile = sels[2];
				if (sels[3] != null) selObject = sels[3];
				if (sels[4] != null) selItem = sels[4];
			}

			//Cache input idx
			Key_ClickSelectTarget = plyInput.GetInputIdx("Player/ClickSelectTarget");
			Key_SelectNextTarget = plyInput.GetInputIdx("Player/SelectNextTarget");
			Key_TargetClear = plyInput.GetInputIdx("Player/ClearTarget");
			Key_ClickInteract = plyInput.GetInputIdx("Player/ClickInteract");
			Key_Interact = plyInput.GetInputIdx("Player/Interact");
			actionSlots.InitDefaultBinds();
		}

		new protected void OnDestroy()
		{
			Player.IsReady = false;
			Player.Instance = null;
			base.OnDestroy();
			if (selectedTarget != null)
			{
				selectedTarget.onDestroy -= OnTargetedDestroyed;

				if (selectedTarget.TargetableType() == Type.Character)
				{
					CharacterControllerBase c = selectedTarget as CharacterControllerBase;
					if (c != null)
					{
						if (false == c.IsPlayer()) c.onDeath -= OnNPCDeath;
					}
				}
			}
		}

		protected void Update()
		{
			if (waitFrame > 0)
			{	
				waitFrame--;
				if (waitFrame <= 0)
				{
					// do stuff here that needs to wait one frame
					Player.IsReady = true;
				}
			}

			if (GameGlobal.Paused) return;
			UpdateActions();
		}

		private void UpdateActions()
		{
			if (false == controlEnabled) return;

			// check if an action slot input bind was used
			actionSlots.Update();

			// check if target select key was pressed
			if (canButtonSelect)
			{
				HandleButtonSelect(false);
				HandleButtonInteract(false);
			}

			// check if clicked on a selectable target
			if (canMouseSelect)
			{
				HandleClickSelect();
				HandleClickInteract();
			}
		}

		public void HandleButtonSelect(bool forced)
		{
			if (plyInput.GetButtonDown(Key_TargetClear))
			{
				ClearTarget();
			}

			if (plyInput.GetButtonDown(Key_SelectNextTarget) || forced)
			{
				// find a target within range
				Collider[] colliderHits = Physics.OverlapSphere(_tr.position, buttonSelDistance, selectButtonMask);
				if (colliderHits.Length > 0)
				{	// will include only NPC, Object and item as per settings cause of selectButtonMask
					// now find the closest one that is within a specific angle if angle specified

					// create a list of all the hits and how far they are from the target point
					List<Skill.CollectedTarget> collectedTargets = new List<Skill.CollectedTarget>();
					for (int i = 0; i < colliderHits.Length; i++)
					{
						Targetable target = colliderHits[i].gameObject.GetComponent<Targetable>();
						if (target != null)
						{
							collectedTargets.Add(new Skill.CollectedTarget()
							{
								t = target,
								distance = Vector3.Distance(colliderHits[i].transform.position, _tr.position)
							});
						}
					}

					// sort the objects by distance from the point
					collectedTargets.Sort(delegate(Skill.CollectedTarget a, Skill.CollectedTarget b) { return a.distance.CompareTo(b.distance); });

					if (selectedTarget == null && prevButtonSelected.Count > 0)
					{	// clear the list of previously selected when nothing is selected
						// cause stepping through targets needs to start anew
						prevButtonSelected = new List<Targetable>(0);
					}

					Targetable firstValid = null;
					Targetable chosenValid = null;
					Targetable prevSel = selectedTarget;
					
					ClearTarget();

					// grab next valid targetable if current target is selected
					// this is done by checking the prevButtonSelected list
					for (int i = 0; i < collectedTargets.Count; i++)
					{
						if (plyUtil.IsInRange(_tr, collectedTargets[i].t.transform.position, buttonSelDistance, buttonSelAngle))
						{
							if (firstValid == null) firstValid = collectedTargets[i].t;
							if (chosenValid == null && collectedTargets[i].t != prevSel) chosenValid = collectedTargets[i].t;

							if (false == prevButtonSelected.Contains(collectedTargets[i].t))
							{
								prevButtonSelected.Add(collectedTargets[i].t);
								SelectTarget(collectedTargets[i].t);
								break;
							}
						}
					}

					if (chosenValid == null) chosenValid = firstValid;

					// it could happen that all possible targets where in the prevButtonSelected list
					// in that case no target would now be selected so I need to force one
					if (selectedTarget == null && chosenValid != null)
					{
						SelectTarget(chosenValid);
					}
				}
			}
		}

		public void HandleButtonInteract(bool forced)
		{
			if (plyInput.GetButtonDown(Key_Interact) || forced)
			{
				// find a valid target in range if none selected
				if (selectedTarget == null) HandleButtonSelect(true);

				if (selectedTarget != null)
				{
					if (autoMoveToInteract)
					{	// can auto move to range
						SetTargetInteract(selectedTarget.transform.gameObject);
					}
					else
					{	// must be in range, else do not bother
						if (plyUtil.IsInRange(_tr, selectedTarget.transform.position, maxInteractDistance, buttonSelAngle))
						{
							SetTargetInteract(selectedTarget.transform.gameObject);
						}
					}
				}
			}
		}

		private void HandleClickSelect()
		{
			if (plyInput.GetButtonDown(Key_ClickSelectTarget))
			{
				if (clearSelectedOnFloorClick)
				{
					Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
					RaycastHit hit;
					if (Physics.Raycast(ray, out hit, Mathf.Infinity, floorClickMask))
					{
						if (hit.transform.gameObject.layer == GameGlobal.LayerMapping.Floor)
						{
							ClearTarget();
						}
						else
						{
							if (selectClickMask.HasLayer(hit.transform.gameObject.layer))
							{
								if (plyUtil.IsInRange(_tr, hit.transform.position, mouseSelDistance, mouseSelAngle))
								{
									SelectTarget(hit.transform.gameObject);
								}
							}
						}
					}
				}
				else
				{
					Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
					RaycastHit hit;
					if (Physics.Raycast(ray, out hit, Mathf.Infinity, selectClickMask))
					{	// the selectClickMask will allow only NPC, Item and Object to be clicked (depending on settings)
						if (plyUtil.IsInRange(_tr, hit.transform.position, mouseSelDistance, mouseSelAngle))
						{
							SelectTarget(hit.transform.gameObject);
						}
					}
				}
			}
		}

		private void HandleClickInteract()
		{
			if (plyInput.GetButtonDown(Key_ClickInteract))
			{
				Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
				RaycastHit hit;
				if (Physics.Raycast(ray, out hit, Mathf.Infinity, selectClickMask))
				{	
					if (autoMoveToInteract)
					{	// can auto move to range
						SetTargetInteract(hit.transform.gameObject);
					}
					else
					{	// must be in range, else do not bother
						if (plyUtil.IsInRange(_tr, hit.transform.position, maxInteractDistance, mouseSelAngle))
						{
							SetTargetInteract(hit.transform.gameObject);
						}
					}
				}
			}
		}

		// ============================================================================================================

		public override void Save(string key)
		{
			base.Save(key);
			if (persistActionSlotBinds) actionSlots.Save(key);
		}

		public override void Load(string key)
		{
			base.Load(key);
			if (persistActionSlotBinds) actionSlots.Load(key);
		}

		public override void DeleteSaveData(string key)
		{
			base.DeleteSaveData(key);
			if (persistActionSlotBinds) actionSlots.DeleteSaveData(key);
		}

		public override void DisablePersistence() 
		{
			base.DisablePersistence();
			persistActionSlotBinds = false;  
		}

		// ============================================================================================================

		/// <summary> Return true if the character may accept input to generate movement. </summary>
		public override bool MovementControlAllowed()
		{
			return (controlEnabled && !hint_DoNotMove && (!Interacting || movementCanStopInteraction));
		}

		/// <summary> Override to tell plyGame this is a player character controller </summary>
		public override bool IsPlayer()
		{
			return true;
		}

		public override void SelectTarget(Targetable t)
		{
			if (selectedTarget == t) return;
			base.SelectTarget(t);

			selectedTarget.onDestroy += OnTargetedDestroyed;

			// Show the Selector
			if (t.TargetableType() == Type.Character)
			{
				CharacterControllerBase c = t as CharacterControllerBase;
				if (c != null)
				{
					if (false == c.IsPlayer())
					{
						c.onDeath += OnNPCDeath;

						//StatusTowardsOther s = actor.HighestFactionStatusToTargetBiDirectional(c.actor);
						StatusTowardsOther s = actor.HighestStatusToTarget(c.actor);
						if (s == StatusTowardsOther.Friendly) activeSelector = selNPCFriendly;
						else if (s == StatusTowardsOther.Neutral) activeSelector = selNPCNeutral;
						else if (s == StatusTowardsOther.Hostile) activeSelector = selNPCHostile;
					}
				}
			}
			else if (t.TargetableType() == Type.Object)
			{
				if (selObject != null) activeSelector = selObject;
			}
			else if (t.TargetableType() == Type.Item)
			{
				if (selItem != null) activeSelector = selItem;

				if (itemSelectInteract)
				{
					if (autoMoveToInteract)
					{	// can auto move to range
						SetTargetInteract(t.gameObject);
					}
					else
					{	// must be in range, else do not bother
						if (plyUtil.IsInRange(_tr, t.transform.position, maxInteractDistance, 0))
						{
							SetTargetInteract(t.gameObject);
						}
					}
				}
			}

			if (activeSelector != null)
			{
				activeSelector.target = t.transform;
				activeSelector.gameObject.SetActive(true);
				activeSelector.enabled = true; // just in case it auto-disabled itself cause of a target that became null previously
			}

		}

		public override void ClearTarget()
		{
			if (selectedTarget != null)
			{
				selectedTarget.onDestroy -= OnTargetedDestroyed;

				if (selectedTarget.TargetableType() == Type.Character)
				{
					CharacterControllerBase c = selectedTarget as CharacterControllerBase;
					if (c != null)
					{
						if (false == c.IsPlayer()) c.onDeath -= OnNPCDeath;
					}
				}
			}

			base.ClearTarget();

			// Hide the selector
			if (activeSelector != null)
			{
				activeSelector.gameObject.SetActive(false);
				activeSelector.target = null;
				activeSelector = null;
			}
		}

		private void OnTargetedDestroyed(object obj, object[] args)
		{
			Targetable t = obj as Targetable;
			if (selectedTarget == t && selectedTarget != null)
			{
				ClearTarget();
			}
		}

		private void OnNPCDeath(object npc, object[] args)
		{
			Targetable t = npc as Targetable;
			if (selectedTarget == t && selectedTarget != null)
			{
				ClearTarget();
			}
		}

		// ============================================================================================================
		#region debug

		protected void OnDrawGizmosSelected()
		{
			if (selectedTarget != null)
			{
				Gizmos.color = Color.magenta;
				Gizmos.DrawWireSphere(selectedTarget.transform.position, 1f);
			}
		}

		#endregion
		// ============================================================================================================	
	}
}
