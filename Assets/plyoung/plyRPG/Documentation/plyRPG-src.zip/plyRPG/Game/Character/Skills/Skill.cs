﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> A Skill, something an Actor can perform. This can be a lot of things and can range
	///  from attack skills like the swing of a sword or a fireball to the use or a pick to mine for
	///  some ore. The plyBlox system does most of the work when events related to the Skill is
	///  triggered. </summary>
	[AddComponentMenu("")]
	[RequireComponent(typeof(plyBlox))]
	public class Skill : MonoBehaviour
	{
		#region properties

		public bool showDebugInfo = false;
		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data

		[HideInInspector] public UniqueID id = new UniqueID();			//!< Unique id
		[HideInInspector] public plyBlox blox;							//!< The blox object of this skill

		/// <summary> How a skill is activated </summary>
		public enum Activation
		{
			User=0,					//!< Use() must be called to activate the skill
			//Auto=1,					//!< Skill will activate as response on something
			Passive=2					//!< Skill is simply a data entry that can be checked. Example use: Skill to 'Wear Plate Armour'
		}
		
		/// <summary> In what direction or location the skill is executed </summary>
		public enum TargetLocation
		{
			ActorDirection,			//!< Execution is in direction the character faces
			MouseDirection,			//!< Execution is, for Player - in direction from character to mouse, for NPC - from character to its selected target
			SelectedDirection,		//!< Execution is, in direction of selected target
			AtClickPosition,		//!< Need the player to click on a spot where the skill will collect targets in a specified radius
			AtSelected,				//!< Skill can only be used if a target is selected
			MouseOver,				//!< This works like typical ARPG where mouse click on valid enemy would cast spell on it (in this case hover with mouse over and press 1,2,3 would also allow the skill to execute)
			CameraForward,			//!< Executed in exact forward direction of camera
			CameraDirection,		//!< In direction of camera on the XZ plane, ignoring camera's tilt (up/down)
		}

		/// <summary> How the skill's effect is delivered </summary>
		public enum DeliveryMethod
		{
			Instant,				//!< Used for Melee, Self-Heals, ranged-non-projectile skills
			Projectile,				//!< Projectile(s) should be created that should hit target(s) before applying effects
			//Pathing				// Similar to projectile some object(s) will be created that needs to move around on floor to find target(s) before effect applied
		}

		/// <summary> How does skill collect possible targets </summary>
		public enum TargetingMethod
		{
			Self = 1,				//!< Skill should include character performing the skill as target possible target
			Selected = 2,			//!< Skill should include the selected object/ character as possible target
			Auto = 4,				//!< Skill should auto select from valid targets in range
		}

		/// <summary> What are valid targets for the skill's effect </summary>
		[System.Flags]
		public enum ValidTargets
		{
			Player = 1,				//!< Player can be targeted, regardless the status of the user's faction towards the player
			FriendlyActor = 2,		//!< Any Actor that the user of Skill is Friendly towards. The status of Factions of the user towards the target Actor is used in the check. For NPCs towards the Player the NPC's status towards the player is also checked
			NeutralActor = 4,		//!< Any Actor that the user of Skill is Neutral towards. See 'friendly' , above, for more info.
			HostileActor = 8,		//!< Any Actor that the user of Skill is Hostile towards. See 'friendly' , above, for more info.
			RPGObject = 16,		//!< An object can be targeted
		}

		/// <summary> How does a projectile move </summary>
		public enum ProjectileMoveMethod
		{
			ActorFaceDirection,		//!< Projectile move straight from user till it hits or fizzle
			AngledFromEach,			//!< Only useful when creating more than one projectile where they should shoot in face direction but at random angles
			DirectToTarget,			//!< Projectile will find a target first and move towards it. Heat-seeking (moveMethod_b_opt = true) can be set for this else the projectile will move to the position the target was at, at time of creation of projectile
		}

		[HideInInspector] public float executionTimeout = 0f;		//!< (seconds) how long it takes to execute the skill. In this time the actor can't start a new skill
		[HideInInspector] public float cooldownTimeout = 1f;		//!< (seconds) how long before the skill can be used again after being used
		[HideInInspector] public bool mayPerformWhileMove = true;	//!< Actor may perform skill while moving?
		[HideInInspector] public bool forceStop = true;				//!< Only used when Perform While Move is set to False. This will force the character to stop so it can perform the skill.
		[HideInInspector] public bool canBeQueued = true;			//!< Set to false to prevent this skill from being queued. It can then only be used if the Actor is not currently using another Skill
		[HideInInspector] public bool autoQueue = false;			//!< Should the skill auto-queue when used? Only available when canBeQueued = true

		[HideInInspector] public Activation activation = Activation.User;						//!< How a skill is activated
		[HideInInspector] public DeliveryMethod deliveryMethod = DeliveryMethod.Instant;		//!< How the skill's effect is delivered
		[HideInInspector] public TargetingMethod targetingMethodMask = TargetingMethod.Auto;	//!< How does skill collect possible targets
		[HideInInspector] public ValidTargets validTargetsMask = 0;								//!< What are valid targets for the skill's effect
		[HideInInspector] public TargetLocation targetLocation = TargetLocation.ActorDirection; //!< In what direction or location the skill is executed

		[HideInInspector] public int maxEffects = 1;		//!< for instant this is max targets to select. for projectiles this will be the max projectiles that can be created (and targets that would be selected if in that mode)
		[HideInInspector] public float targetingDistance = 2; //!< (meters) how far to select targets from self (also used for how far projectile will move before fizzle)
		[HideInInspector] public int targetingAngle = 45;	//!< (degrees) at hat angle from self's forward may targets be selected
		[HideInInspector] public int targetingRadius = 5;	//!< (meters) used with the detection circle when AtClickPosition used
		
		[HideInInspector] public LayerMask obstacleCheckMask = 0;	//!< check if something is between target and skill user?
		[HideInInspector] public float obstacbleCheckHeight = 1.5f;	//!< Ray is cast from this height

		[HideInInspector] public float instantHitDelay = 0f; //!< Set to have DeliveryMethod.Instant delay before creating its Hit Event 

		[HideInInspector] public int secondaryMaxTargets = 0;						//!< could be used for splash damage (disabled when set to 0)
		[HideInInspector] public int secondaryRadius = 5;							//!< detection radius in meters
		[HideInInspector] public LayerMask secondaryObstacleCheckMask = 0;			//!< check if something is between target and effect execution position?
		[HideInInspector] public float secondaryObstacbleCheckHeight = 1.5f;		//!< Ray is cast from this height

		[HideInInspector] public GameObject[] projectileFabs = new GameObject[5];	//!< prefabs of projectile. Will choose randomly from these.
		[HideInInspector] public float projectileCreateDelay = 0f;					//!< how long to wait before creating the (1st) projectile
		[HideInInspector] public float projectileCreateDelayBetween = 0f;			//!< how long to delay between creating projectiles
		[HideInInspector] public ProjectileMoveMethod projectileMoveMethod = ProjectileMoveMethod.ActorFaceDirection; //!< How does a projectile move
		[HideInInspector] public bool moveMethod_b_opt = false;						//!< ProjectileMoveMethod.DirectToTarget: heat-seeking? ProjectileMoveMethod.AngledFromEach: random angle?

		[HideInInspector] public bool useVectorOffset = true;						//!< if true, use projectileCreateOffset else projectileCreateAtTagged
		[HideInInspector] public Vector3 projectileCreateOffset = new Vector3(0f, 1f, 0.5f); //!< default is little up and in front of user of skill
		[HideInInspector] public string projectileCreateAtTagged = "";				//!< Name of Tag to look for to identify mount/dummy object to create projectile at

		[HideInInspector] public int hitHeightPercentage = 50;						//!< 0=at feet, 50=middle, 100=head/top
		[HideInInspector] public int maxFlightDistance = 10;						//!< (meter) how far the projectile will move before it fizzle
		[HideInInspector] public float maxLiveTime = 0;								//!< (seconds) how long it can live before fizzle
		[HideInInspector] public float projectileMoveSpeed = 10f;					//!< How fast projectile moves
		[HideInInspector] public bool triggerSecondaryOnFizzle = false;				//!< Should the secondary effect trigger when the projectile fizzled?
		[HideInInspector] public bool triggerSecondaryOnFizzleOnlyIfObstacle = true;//!< Should the secondary only trigger if the fizzle was cause by the projectile colliding with an obstacle?
		[HideInInspector] public float collisionRayWidth = 0.0f;					//!< Used by projectile to check when it hits something. 0 = ray cast is used, else a spherical cast is used
		[HideInInspector] public bool destroyProjectileOnHit = true;				//!< Normally true for projectiles but can be set false if doing something special like beam weapon

		#endregion
		// ============================================================================================================
		#region runtime

		/// <summary> The actor that owns this Skill. Skills area created as actual GameObjects placed
		///  inside the character that it belongs to at run-time. </summary>
		/// <value> The owner. </value>
		public Actor owner { get; set; }

		public PersistableObject persistObj { get; protected set; }

		protected EventHandler_Skills eventHandler = null;
		

		protected int projectileFabCount = 0;
		[System.NonSerialized] public float executeTimer = 0.0f;
		[System.NonSerialized] public float cooldownTimer = 0.0f;

		public class CollectedTarget
		{
			public Targetable t;
			public float distance;
		}

		public class DelayedHit
		{
			public Targetable selectedObject;
			public Vector3 selectedPosition;
			public Vector3 mousePosition;
			public float timer = 0f;
		}

		protected List<DelayedHit> delayedHits = new List<DelayedHit>(0);

		#endregion
		// ============================================================================================================
		#region copy

		public override string ToString()
		{
			return string.IsNullOrEmpty(def.screenName) ? name : def.screenName;
		}

		public void CopyTo(Skill o)
		{
			o.id = this.id.Copy();
			o.def = this.def.Copy();

			o.executionTimeout = this.executionTimeout;
			o.cooldownTimeout = this.cooldownTimeout;
			o.mayPerformWhileMove = this.mayPerformWhileMove;
			o.forceStop = this.forceStop;
			o.canBeQueued = this.canBeQueued;
			o.autoQueue = this.autoQueue;

			o.activation = this.activation;
			o.deliveryMethod = this.deliveryMethod;
			o.targetingMethodMask = this.targetingMethodMask;
			o.validTargetsMask = this.validTargetsMask;
			o.targetLocation = this.targetLocation;

			o.maxEffects = this.maxEffects;
			o.targetingDistance = this.targetingDistance;
			o.targetingAngle = this.targetingAngle;
			o.targetingRadius = this.targetingRadius;

			o.obstacleCheckMask = this.obstacleCheckMask;
			o.obstacbleCheckHeight = this.obstacbleCheckHeight;

			o.secondaryMaxTargets = this.secondaryMaxTargets;
			o.secondaryRadius = this.secondaryRadius;
			o.secondaryObstacleCheckMask = this.secondaryObstacleCheckMask;
			o.secondaryObstacbleCheckHeight = this.secondaryObstacbleCheckHeight;

			o.projectileFabs = new GameObject[this.projectileFabs.Length];
			for (int i = 0; i < this.projectileFabs.Length; i++) o.projectileFabs[i] = this.projectileFabs[i];

			o.projectileMoveMethod = this.projectileMoveMethod;
			o.projectileCreateDelay = this.projectileCreateDelay;
			o.projectileCreateDelayBetween = this.projectileCreateDelayBetween;
			o.moveMethod_b_opt = this.moveMethod_b_opt;

			o.useVectorOffset = this.useVectorOffset;
			o.projectileCreateOffset = this.projectileCreateOffset;
			o.projectileCreateAtTagged = this.projectileCreateAtTagged;

			o.hitHeightPercentage = this.hitHeightPercentage;
			o.maxFlightDistance = this.maxFlightDistance;
			o.maxLiveTime = this.maxLiveTime;
			o.projectileMoveSpeed = this.projectileMoveSpeed;
			o.triggerSecondaryOnFizzle = this.triggerSecondaryOnFizzle;
			o.triggerSecondaryOnFizzleOnlyIfObstacle = this.triggerSecondaryOnFizzleOnlyIfObstacle;
			o.collisionRayWidth = this.collisionRayWidth;
			o.destroyProjectileOnHit = this.destroyProjectileOnHit;

			this.blox.CopyTo(o.blox);
		}

		#endregion
		// ============================================================================================================
		#region init/start

		protected void Reset()
		{
			showDebugInfo = false;
			if (blox == null) blox = GetComponent<plyBlox>();
		}

		protected void Awake()
		{
			persistObj = GetComponent<PersistableObject>();
			if (blox == null) blox = GetComponent<plyBlox>();
		}

		protected void Start()
		{
			showDebugInfo = false;
			executeTimer = 0.0f;
			cooldownTimer = 0.0f;

			// event handlers will only be available after Awake(), so grab it in Start()
			eventHandler = GetComponent<EventHandler_Skills>();

			// order the projectile prefabs so they follow on each other
			projectileFabCount = 0;
			if (deliveryMethod == DeliveryMethod.Projectile)
			{
				for (int i = 0; i < projectileFabs.Length; i++)
				{
					if (projectileFabs[i] == null)
					{
						for (int j = i + 1; j < projectileFabs.Length; j++)
						{
							if (projectileFabs[j] != null)
							{
								projectileFabs[i] = projectileFabs[j];
								projectileFabs[j] = null;
								break;
							}
						}
					}

					if (projectileFabs[i] != null) projectileFabCount++;
				}
			}

			if (blox.NeedObjectActive == false) gameObject.SetActive(false); // no need for the object to be active
		}

		#endregion
		// ============================================================================================================
		#region update

		protected void Update()
		{
			// run down the execute timer
			if (executeTimer > 0.0f)
			{
				executeTimer -= Time.deltaTime;
				if (executeTimer <= 0.0f) executeTimer = 0.0f;
			}

			// then the cool-down timer
			else if (cooldownTimer > 0.0f)
			{
				cooldownTimer -= Time.deltaTime;
				if (cooldownTimer <= 0.0f) cooldownTimer = 0.0f;
			}

			// update delayed hits
			if (delayedHits.Count > 0)
			{
				if (owner == null)
				{
					delayedHits.Clear();
					return;
				}

				if (owner.IsDead())
				{
					delayedHits.Clear();
					return;
				}

				for (int i = delayedHits.Count - 1; i >= 0; i--)
				{
					delayedHits[i].timer -= Time.deltaTime;
					if (delayedHits[i].timer <= 0.0f)
					{
						//DoHitsOn(delayedHits[i].targets);	// do the hits
						DoDelayedHit(delayedHits[i]);
						delayedHits.RemoveAt(i);			// done with this delayed hit event
					}
				}
			}
		}

		protected void LateUpdate()
		{
			if (executeTimer <= 0.0f && cooldownTimer <= 0.0f && showDebugInfo == false &&
				blox.NeedObjectActive == false && delayedHits.Count == 0 && gameObject.activeSelf)
			{	// can go back to sleep, don't need you
				gameObject.SetActive(false);
			}
		}

		#endregion
		// ============================================================================================================
		#region workers

		// Collects targets in a radius around point up to max, filtered to fall within angle
		protected List<Targetable> CollectTargets(Targetable selectedObject, int max, Vector3 aroundPoint, Vector3 direction, int angle, float radius)
		{
			if (validTargetsMask == 0) return new List<Targetable>(0); // return nothing when valid targets are set to nothing

			List<Targetable> targets = new List<Targetable>();
			if ((targetingMethodMask & TargetingMethod.Self) == TargetingMethod.Self)
			{
				if (owner.character != null)
				{
					if (IsValidTargetable(owner.character, owner.transform, owner.transform.position, obstacbleCheckHeight, obstacleCheckMask))
					{
						targets.Add(owner.character);
						if (targets.Count == max) return targets;
					}
				}
			}

			if ((targetingMethodMask & TargetingMethod.Selected) == TargetingMethod.Selected)
			{
				if (IsValidTargetable(selectedObject, owner.transform, owner.transform.position, obstacbleCheckHeight, obstacleCheckMask))
				{
					if (!targets.Contains(selectedObject)) targets.Add(selectedObject);
					if (targets.Count == max) return targets;
				}
			}

			if ((targetingMethodMask & TargetingMethod.Auto) == TargetingMethod.Auto)
			{
				// First find all valid targets within radius around point
				// Then select those that falls within a certain angle
				// and from those the ones closest to the point will
				// have priority in making the final list

				LayerMask mask = 0;
				if ((validTargetsMask & ValidTargets.Player) == ValidTargets.Player) mask |= 1 << GameGlobal.LayerMapping.Player;
				if ((validTargetsMask & ValidTargets.RPGObject) == ValidTargets.RPGObject) mask |= 1 << GameGlobal.LayerMapping.plyObject;
				if ((validTargetsMask & ValidTargets.FriendlyActor) == ValidTargets.FriendlyActor ||
					(validTargetsMask & ValidTargets.NeutralActor) == ValidTargets.NeutralActor ||
					(validTargetsMask & ValidTargets.HostileActor) == ValidTargets.HostileActor
					//(validTargetsMask & ValidTargets.ReversedFriendlyActor) == ValidTargets.ReversedFriendlyActor ||
					//(validTargetsMask & ValidTargets.ReversedNeutralActor) == ValidTargets.ReversedNeutralActor ||
					//(validTargetsMask & ValidTargets.ReversedHostileActor) == ValidTargets.ReversedHostileActor
				){
					mask |= 1 << GameGlobal.LayerMapping.Player;
					mask |= 1 << GameGlobal.LayerMapping.NPC;
				}

				Collider[] colliderHits = Physics.OverlapSphere(aroundPoint, radius, mask);
				if (colliderHits.Length > 0)
				{
					// create a list of all the hits and how far they are from the target point
					List<CollectedTarget> collectedTargets = new List<CollectedTarget>();
					for (int i = 0; i < colliderHits.Length; i++)
					{
						Targetable target = colliderHits[i].gameObject.GetComponent<Targetable>();
						if (target != null)
						{
							collectedTargets.Add(new CollectedTarget()
							{
								t = target,
								distance = Vector3.Distance(colliderHits[i].transform.position, aroundPoint)
							});
						}
					}

					// sort the objects by distance from the point
					collectedTargets.Sort(delegate(CollectedTarget a, CollectedTarget b) { return a.distance.CompareTo(b.distance); });

					if (angle < 5 || angle > 355)
					{	// assume 360 degrees
						for (int i = 0; i < collectedTargets.Count; i++)
						{
							if (IsValidTargetable(collectedTargets[i].t, owner.transform, owner.transform.position, obstacbleCheckHeight, obstacleCheckMask))
							{
								if (!targets.Contains(collectedTargets[i].t)) targets.Add(collectedTargets[i].t);
								if (targets.Count == max) return targets;
							}
						}
					}

					else
					{
						float maxAngle = angle / 2f;
						float minAngle = -maxAngle;

						for (int i = 0; i < collectedTargets.Count; i++)
						{
							if (IsValidTargetable(collectedTargets[i].t, owner.transform, owner.transform.position, obstacbleCheckHeight, obstacleCheckMask))
							{
								// first check if within the angle before adding
								float res = plyUtil.AngleSigned(direction, (collectedTargets[i].t.transform.position - aroundPoint), Vector3.up);
								if (res >= minAngle && res <= maxAngle)
								{
									if (!targets.Contains(collectedTargets[i].t)) targets.Add(collectedTargets[i].t);
									if (targets.Count == max) return targets;
								}
							}
						}
					}
				}
			}
			
			return targets;
		}

		protected List<Targetable> CollectSecondaryTargets(Targetable mainTarget, Vector3 aroundPoint)
		{
			List<Targetable> targets = new List<Targetable>();
			LayerMask mask = 0;
			if ((validTargetsMask & ValidTargets.Player) == ValidTargets.Player) mask |= 1 << GameGlobal.LayerMapping.Player;
			if ((validTargetsMask & ValidTargets.RPGObject) == ValidTargets.RPGObject) mask |= 1 << GameGlobal.LayerMapping.plyObject;
			if ((validTargetsMask & ValidTargets.FriendlyActor) == ValidTargets.FriendlyActor ||
				(validTargetsMask & ValidTargets.NeutralActor) == ValidTargets.NeutralActor ||
				(validTargetsMask & ValidTargets.HostileActor) == ValidTargets.HostileActor
				//(validTargetsMask & ValidTargets.ReversedFriendlyActor) == ValidTargets.ReversedFriendlyActor ||
				//(validTargetsMask & ValidTargets.ReversedNeutralActor) == ValidTargets.ReversedNeutralActor ||
				//(validTargetsMask & ValidTargets.ReversedHostileActor) == ValidTargets.ReversedHostileActor
			){
				mask |= 1 << GameGlobal.LayerMapping.Player;
				mask |= 1 << GameGlobal.LayerMapping.NPC;
			}

			Collider[] colliderHits = Physics.OverlapSphere(aroundPoint, secondaryRadius, mask);
			if (colliderHits.Length > 0)
			{
				// create a list of all the hits and how far they are from the target point
				List<CollectedTarget> collectedTargets = new List<CollectedTarget>();
				for (int i = 0; i < colliderHits.Length; i++)
				{
					Targetable target = colliderHits[i].gameObject.GetComponent<Targetable>();
					if (target != null)
					{
						if (target == mainTarget) continue;
						collectedTargets.Add(new CollectedTarget()
						{
							t = target,
							distance = Vector3.Distance(colliderHits[i].transform.position, aroundPoint)
						});
					}
				}

				// sort the objects by distance from the point
				collectedTargets.Sort(delegate(CollectedTarget a, CollectedTarget b) { return a.distance.CompareTo(b.distance); });

				for (int i = 0; i < collectedTargets.Count; i++)
				{
					if (IsValidTargetable(collectedTargets[i].t, mainTarget == null ? null : mainTarget.transform, aroundPoint, secondaryObstacbleCheckHeight, secondaryObstacleCheckMask))
					{
						if (!targets.Contains(collectedTargets[i].t)) targets.Add(collectedTargets[i].t);
						if (targets.Count == secondaryMaxTargets) return targets;
					}
				}

			}

			return targets;
		}

		// The main collector of targets. Will make calls to CollectTargets() as needed
		protected List<Targetable> CollectTargetsBasedOnTargetingLocation(Targetable selectedObject, Vector3 selectedPosition, Vector3 mousePosition)
		{
			List<Targetable> targets = new List<Targetable>();
			if (targetLocation == TargetLocation.ActorDirection)
			{
				targets = CollectTargets(selectedObject, maxEffects, transform.position, transform.forward, targetingAngle, targetingDistance);				
			}
			else if (targetLocation == TargetLocation.MouseDirection)
			{
				if (owner.character.IsPlayer())
				{
					Vector3 direction = (mousePosition - transform.position).normalized;
					targets = CollectTargets(selectedObject, maxEffects, transform.position, direction, targetingAngle, targetingDistance);
				}
				else
				{
					if (selectedObject != null)
					{
						Vector3 direction = (selectedPosition - transform.position).normalized; //(selectedObject.transform.position - transform.position).normalized;
						targets = CollectTargets(selectedObject, maxEffects, transform.position, direction, targetingAngle, targetingDistance);
					}
				}
			}
			else if (targetLocation == TargetLocation.SelectedDirection)
			{
				if (selectedObject != null)
				{
					Vector3 direction = (selectedPosition - transform.position).normalized; //(selectedObject.transform.position - transform.position).normalized;
					targets = CollectTargets(selectedObject, maxEffects, transform.position, direction, targetingAngle, targetingDistance);
				}
			}
			else if (targetLocation == TargetLocation.AtSelected || targetLocation == TargetLocation.MouseOver)
			{
				if (selectedObject != null)
				{	// do 360 selection
					targets = CollectTargets(selectedObject, maxEffects, selectedObject.transform.position, Vector3.zero, 0, targetingRadius);
				}
			}
			else if (targetLocation == TargetLocation.AtClickPosition)
			{
				// do 360 selection
				targets = CollectTargets(selectedObject, maxEffects, mousePosition, Vector3.zero, 0, targetingRadius);
			}
			else if (targetLocation == TargetLocation.CameraForward || targetLocation == TargetLocation.CameraDirection)
			{
				if (owner.character.IsPlayer())
				{
					Transform tr = Player.Camera == null ? transform : Player.Camera.transform;
					Vector3 direction = Player.Camera == null ? tr.forward : tr.forward;
					if (targetLocation == TargetLocation.CameraDirection) direction.y = 0;
					targets = CollectTargets(selectedObject, maxEffects, transform.position, direction, targetingAngle, targetingDistance);
				}
				else
				{
					if (selectedObject != null)
					{
						Vector3 direction = (selectedPosition - transform.position).normalized;
						targets = CollectTargets(selectedObject, maxEffects, transform.position, direction, targetingAngle, targetingDistance);
					}
				}
			}

			return targets;
		}

		protected virtual void ExecuteInstant(Targetable selectedObject, Vector3 selectedPosition, Vector3 mousePosition)
		{
			if (instantHitDelay == 0.0f)
			{
				List<Targetable> targets = CollectTargetsBasedOnTargetingLocation(selectedObject, selectedPosition, mousePosition);				
				if (targets.Count > 0)
				{
					// trigger the OnEffect event on each target
					if (eventHandler != null)
					{
						for (int i = 0; i < targets.Count; i++)
						{
							eventHandler.OnEffect(owner, this, targets[i].transform.position, targets[i].gameObject, Vector3.zero);
						}
					}

					DoHitsOn(targets);
				}
			}
			else
			{
				if (eventHandler != null)
				{
					List<Targetable> targets = CollectTargetsBasedOnTargetingLocation(selectedObject, selectedPosition, mousePosition);
					if (targets.Count > 0)
					{
						// trigger the OnEffect event on each target
						for (int i = 0; i < targets.Count; i++)
						{
							eventHandler.OnEffect(owner, this, targets[i].transform.position, targets[i].gameObject, Vector3.zero);
						}
					}
				}

				if (!gameObject.activeSelf) gameObject.SetActive(true);
				delayedHits.Add(new DelayedHit() { timer = instantHitDelay, selectedObject = selectedObject, selectedPosition = selectedPosition, mousePosition = mousePosition });
			}
		}

		protected void DoDelayedHit(DelayedHit dh)
		{
			List<Targetable> targets = CollectTargetsBasedOnTargetingLocation(dh.selectedObject, dh.selectedPosition, dh.mousePosition);
			if (targets.Count > 0)
			{
				DoHitsOn(targets);
			}
		}

		protected void DoHitsOn(List<Targetable> targets)
		{
			for (int i = 0; i < targets.Count; i++)
			{
				if (targets[i] == null) continue; // need to check null in case it becomes null while loop was running
				if (eventHandler != null)
				{
					Vector3 hitPos = targets[i].gameObject.transform.position;
#if UNITY5
					Collider collider = targets[i].GetComponent<Collider>();
					if (collider != null)
					{
						float hitOffs = (float)hitHeightPercentage / 100f;
						hitPos.y += (collider.bounds.size.y * hitOffs);
					}
#else
					if (targets[i].collider != null)
					{
						float hitOffs = (float)hitHeightPercentage / 100f;
						hitPos.y += (targets[i].collider.bounds.size.y * hitOffs);
					}
#endif

					eventHandler.OnHit(owner, this, targets[i], hitPos);
				}

				if (secondaryMaxTargets > 0)
				{
					List<Targetable> secondaryTargets = CollectSecondaryTargets(targets[i], targets[i].transform.position);
					for (int j = 0; j < secondaryTargets.Count; j++)
					{
						if (secondaryTargets[j] == null) continue; // need to check null in case it becomes null while loop was running
						if (eventHandler != null)
						{
							Vector3 hitPos = secondaryTargets[j].gameObject.transform.position;
#if UNITY5
							Collider col = secondaryTargets[j].GetComponent<Collider>();
							if (col != null)
							{
								float hitOffs = (float)hitHeightPercentage / 100f;
								hitPos.y += (col.bounds.size.y * hitOffs);
							}
#else
							if (secondaryTargets[j].collider != null)
							{
								float hitOffs = (float)hitHeightPercentage / 100f;
								hitPos.y += (secondaryTargets[j].collider.bounds.size.y * hitOffs);
							}
#endif
							eventHandler.OnSecondaryHit(owner, this, secondaryTargets[j], hitPos);
						}
					}
				}
			}
		}

		// ============================================================================================================

		protected GameObject ChooseProjectilePrefab()
		{
			int r = projectileFabCount > 1 ? Random.Range(0, projectileFabCount) : 0;
			return projectileFabs[r];
		}

		protected virtual void CreateProjectile(int i, float waitTime, Vector3 projectileForward, Vector3 targetLocation, Transform targetTr, Vector3 followOffset)
		{
			// trigger the event in the skill blox
			if (eventHandler != null) eventHandler.OnEffect(owner, this, targetLocation, (targetTr != null ? targetTr.gameObject : null), projectileForward);

			// create the projectile
			if (projectileFabCount > 0)
			{
				LayerMask validTargetLayerMask = 0;
				if ((validTargetsMask & Skill.ValidTargets.Player) == Skill.ValidTargets.Player) validTargetLayerMask |= 1 << GameGlobal.LayerMapping.Player;
				if ((validTargetsMask & Skill.ValidTargets.RPGObject) == Skill.ValidTargets.RPGObject) validTargetLayerMask |= 1 << GameGlobal.LayerMapping.plyObject;
				if ((validTargetsMask & Skill.ValidTargets.FriendlyActor) == Skill.ValidTargets.FriendlyActor ||
					(validTargetsMask & Skill.ValidTargets.NeutralActor) == Skill.ValidTargets.NeutralActor ||
					(validTargetsMask & Skill.ValidTargets.HostileActor) == Skill.ValidTargets.HostileActor)
				{
					validTargetLayerMask |= 1 << GameGlobal.LayerMapping.Player;
					validTargetLayerMask |= 1 << GameGlobal.LayerMapping.NPC;
				}

				Transform dummy = null;
				if (useVectorOffset == false)
				{
					projectileCreateOffset = Vector3.zero;
					if (false == string.IsNullOrEmpty(projectileCreateAtTagged))
					{
						dummy = owner.transform.GetFirstChildWithTag(projectileCreateAtTagged);
					}
				}

				Vector3 createPos = dummy != null ? dummy.position : (owner.transform.position + (projectileForward * projectileCreateOffset.z));
				if (dummy == null)
				{
					createPos.y += projectileCreateOffset.y;
					createPos = createPos + (owner.transform.right * projectileCreateOffset.x);
				}

				GameObject go = (GameObject)Instantiate(ChooseProjectilePrefab());
				go.name = def.screenName + "-projectile-" + i.ToString();
				go.transform.position = createPos;
				go.transform.forward = projectileForward;

				// first check if the Prefab do not already have the SkillProjectile (or derived) component on it
				// this allows the designer to use his own projectile component if he wants to
				SkillProjectile p = go.GetComponent<SkillProjectile>();
				if (p == null) p = go.AddComponent<SkillProjectile>();

				p.owner = this;
				p.moveSpeed = projectileMoveSpeed;
				p.targetLocation = targetLocation;
				p.targetTr = targetTr;
				p.followOffset = followOffset;
				p.maxLiveTime = maxLiveTime <= 0f ? 9999f : maxLiveTime;
				p.validTargetsLayerMask = validTargetLayerMask;
				p.obstacleCheckMask = obstacleCheckMask;
				p.triggerSecondaryOnFizzle = triggerSecondaryOnFizzle;
				p.triggerSecondaryOnFizzleOnlyIfObstacle = triggerSecondaryOnFizzleOnlyIfObstacle;
				p.collisionRayWidth = collisionRayWidth;
				p.destroyProjectileOnHit = destroyProjectileOnHit;
				p.createAtDummy = dummy;

				p.Invoke("MakeActive", waitTime);
			}
		}

		protected virtual void ExecuteProjectile(Targetable selectedObject, Vector3 selectedPosition, Vector3 mousePosition)
		{
			//if (projectileFabCount == 0) { Debug.LogError("[Skill: "+def.screenName+"] No projectile prefabs specified. The Skill can't execute."); return; }

			if (projectileMoveMethod == ProjectileMoveMethod.ActorFaceDirection)
			{
				Vector3 forward = owner.transform.forward; // might not facing exactly in wanted direction, so decide on true direction here
				if (targetLocation == TargetLocation.MouseDirection || targetLocation == TargetLocation.AtClickPosition)
				{
					forward = mousePosition - owner.transform.position;
					forward.y = 0f; forward.Normalize();
				}
				else if (targetLocation == TargetLocation.SelectedDirection || targetLocation == TargetLocation.AtSelected || targetLocation == TargetLocation.MouseOver)
				{
					forward = selectedPosition - owner.transform.position; //selectedObject.transform.position - owner.transform.position;
					forward.y = 0f; forward.Normalize();
				}
				if (targetLocation == TargetLocation.CameraDirection || targetLocation == TargetLocation.CameraForward)
				{
					Transform tr = Player.Camera == null ? transform : Player.Camera.transform;
					forward = Player.Camera == null ? tr.forward : tr.forward;
					forward.y = 0;
				}

				Vector3 tl = owner.transform.position + (forward * maxFlightDistance);
				tl.y += projectileCreateOffset.y;

				float waitTime = projectileCreateDelay;
				for (int i = 0; i < maxEffects; i++)
				{
					CreateProjectile(i, waitTime, forward, tl, null, Vector3.zero);
					waitTime += projectileCreateDelayBetween;
				}
			}
			else if (projectileMoveMethod == ProjectileMoveMethod.AngledFromEach)
			{
				Vector3 forward = owner.transform.forward; // might not facing exactly in wanted direction, so decide on true direction here
				if (targetLocation == TargetLocation.MouseDirection || targetLocation == TargetLocation.AtClickPosition)
				{
					forward = mousePosition - owner.transform.position;
					forward.y = 0f; forward.Normalize();
				}
				else if (targetLocation == TargetLocation.SelectedDirection || targetLocation == TargetLocation.AtSelected || targetLocation == TargetLocation.MouseOver)
				{
					forward = selectedPosition - owner.transform.position; //selectedObject.transform.position - owner.transform.position;
					forward.y = 0f; forward.Normalize();
				}
				if (targetLocation == TargetLocation.CameraDirection || targetLocation == TargetLocation.CameraForward)
				{
					Transform tr = Player.Camera == null ? transform : Player.Camera.transform;
					forward = Player.Camera == null ? tr.forward : tr.forward;
					forward.y = 0;
				}

				if (maxEffects == 1)
				{
					Vector3 tl = owner.transform.position + (forward * maxFlightDistance);
					tl.y += projectileCreateOffset.y;
					CreateProjectile(0, 0f, forward, tl, null, Vector3.zero);
				}
				else
				{
					float angleUnit = targetingAngle / (maxEffects - 1);
					float maxAngle = (targetingAngle / 2);
					float minAngle = -maxAngle;
					float angle = minAngle;
					float waitTime = projectileCreateDelay;

					Vector3 pos = owner.transform.position;
					pos += (owner.transform.right * projectileCreateOffset.x);
					pos += (owner.transform.up * projectileCreateOffset.y);
					pos += (owner.transform.forward * projectileCreateOffset.z);

					for (int i = 0; i < maxEffects; i++)
					{
						if (moveMethod_b_opt) angle = Random.Range(minAngle, maxAngle);
						Vector3 tl = pos + (Quaternion.AngleAxis(+angle, Vector3.up) * forward * maxFlightDistance);
						CreateProjectile(i, waitTime, forward, tl, null, Vector3.zero);
						waitTime += projectileCreateDelayBetween;
						angle += angleUnit;
					}
				}
			}
			else if (projectileMoveMethod == ProjectileMoveMethod.DirectToTarget)
			{
				// the following call will use maxEffects as max for number of targets to collect. Same value used to determine how many projectiles can be created
				List<Targetable> targets = CollectTargetsBasedOnTargetingLocation(selectedObject, selectedPosition, mousePosition);

				if (targets.Count > 0)
				{
					float waitTime = projectileCreateDelay;
					float hitOffs = (float)hitHeightPercentage / 100f;
					for (int i = 0; i < targets.Count; i++)
					{
						if (targets[i] == null) continue; // need to check null in case it becomes null while loop was running

						// calc height to hit at
						float y = 1f;
#if UNITY5
						Collider col = targets[i].GetComponent<Collider>();
						if (col != null) y = col.bounds.size.y;
#else
						if (targets[i].collider != null) y = targets[i].collider.bounds.size.y;
#endif
						Vector3 followOffset = new Vector3(0f, y * hitOffs, 0f);

						if (moveMethod_b_opt) // follow?
						{
							CreateProjectile(i, waitTime, owner.transform.forward, targets[i].transform.position, targets[i].transform, followOffset);
						}
						else
						{
							Vector3 pos = targets[i].transform.position + followOffset;
							CreateProjectile(i, waitTime, owner.transform.forward, pos, null, followOffset);
						}
						waitTime += projectileCreateDelayBetween;
					}
				}

				// shoot what is left off in random direction
				int leftToCreate = maxEffects - targets.Count;
				if (leftToCreate > 0)
				{
					Vector3 forward = owner.transform.forward;
					float maxAngle = (targetingAngle / 2);
					float minAngle = -maxAngle;
					float angle = minAngle;
					float waitTime = projectileCreateDelay;

					Vector3 pos = owner.transform.position;
					pos += (owner.transform.right * projectileCreateOffset.x);
					pos += (owner.transform.up * projectileCreateOffset.y);
					pos += (owner.transform.forward * projectileCreateOffset.z);

					for (int i = 0; i < leftToCreate; i++)
					{
						angle = Random.Range(minAngle, maxAngle);
						Vector3 tl = pos + (Quaternion.AngleAxis(+angle, Vector3.up) * forward * maxFlightDistance);
						CreateProjectile(i, waitTime, forward, tl, null, Vector3.zero);
						waitTime += projectileCreateDelayBetween;
					}
				}
			}
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> Tell Skill to execute now </summary>
		public virtual void Execute(Targetable selectedObject, Vector3 selectedPosition, Vector3 mousePosition)
		{
			// check if there is a validate event set for this skill and call it first
			if (eventHandler != null)
			{
				if (eventHandler.OnValidateSkill(owner, this) == false) return;
			}

			gameObject.SetActive(true);
			executeTimer = executionTimeout;
			cooldownTimer = cooldownTimeout;
		
			if (eventHandler != null) eventHandler.OnActivate(owner, this, selectedPosition, mousePosition);
			if (canBeQueued && autoQueue) owner.QueueSkillForExecution(this, true, selectedObject, selectedPosition, mousePosition);
			
			if (validTargetsMask != 0)
			{
				if (deliveryMethod == DeliveryMethod.Instant) ExecuteInstant(selectedObject, selectedPosition, mousePosition);
				else if (deliveryMethod == DeliveryMethod.Projectile) ExecuteProjectile(selectedObject, selectedPosition, mousePosition);
				//else if (deliveryMethod == DeliveryMethod.Pathing) ExecutePathed(selectedObject, mousePosition);
			}

			if (executeTimer <= 0.0f && cooldownTimer <= 0.0f && showDebugInfo == false &&
				blox.NeedObjectActive == false && delayedHits.Count == 0)
			{	// can go back to sleep, don't need you
				gameObject.SetActive(false);
			}
		}

		/// <summary> Return true if the Skill is busy being executed. All skills are "instant" in creating
		///  their effects and only executionTime govern the Executing status. </summary>
		public bool IsExecuting()
		{
			return executeTimer > 0.0f;
		}

		/// <summary> Return true if busy with cool-down </summary>
		public bool CoolingDown()
		{
			return cooldownTimer > 0.0f;
		}

		/// <summary> Return true if ready to execute and not on some cool down or being prevented in some
		///  other way. </summary>
		public bool IsReady()
		{
			return (IsExecuting() == false && CoolingDown() == false);
		}

		/// <summary> Return true if the facing is within acceptable range. The returned wantedDirection
		///  can be used to turn character to correct facing if needed. </summary>
		public bool FacingAcceptable(Vector3 currForward, Vector3 targetPos, Vector3 mousePos, out Vector3 wantedDirection)
		{
			currForward.y = 0f;
			wantedDirection = currForward;

			if (targetLocation == TargetLocation.ActorDirection)
			{
				return true;
			}
			else
			{
				if (targetLocation == TargetLocation.MouseDirection || targetLocation == TargetLocation.AtClickPosition)
				{
					wantedDirection = mousePos - owner.transform.position;
				}
				else if (targetLocation == TargetLocation.SelectedDirection || targetLocation == TargetLocation.AtSelected || targetLocation == TargetLocation.MouseOver)
				{
					wantedDirection = targetPos - owner.transform.position;
				}
				if (targetLocation == TargetLocation.CameraDirection || targetLocation == TargetLocation.CameraForward)
				{
					Transform tr = Player.Camera == null ? transform : Player.Camera.transform;
					wantedDirection = Player.Camera == null ? tr.forward : tr.forward;
					wantedDirection.y = 0;
				}

				// check if facing close enough to wanted direction, within about 30* or less
				wantedDirection.y = 0; wantedDirection.Normalize();
				if (Vector3.Dot(currForward, wantedDirection) > 0.97f)
				{
					return true;
				}
			}
			return false;
		}

		/// <summary> Return true if the distance from target/ point is fine and skill can be executed.
		///  wantedPos is the target point that should be moved towards while continuously calling this
		///  function to check if in range yet. </summary>
		public bool DistanceAcceptable(Vector3 currPos, Vector3 targetPos, Vector3 mousePos, out Vector3 wantedPos)
		{
			wantedPos = currPos;

			if (targetLocation == TargetLocation.ActorDirection ||
				targetLocation == TargetLocation.MouseDirection ||
				targetLocation == TargetLocation.CameraForward ||  
				targetLocation == TargetLocation.CameraDirection)
			{
				return true;
			}

			else if (targetLocation == TargetLocation.AtClickPosition)
			{
				//if ((mousePos - currPos).magnitude <= targetingDistance) return true;
				//else wantedPos = mousePos;

				Vector3 dir = (mousePos - currPos);
				if (dir.magnitude <= targetingDistance) return true;
				else
				{	// try and get closer but not too close
					wantedPos = mousePos - (dir.normalized * (targetingDistance * 0.9f));
				}
			}

			else if (targetLocation == TargetLocation.MouseOver)
			{
				// use TARGETPOS rather than MOUSEPOS cause Mouse Over should have selected a target
				// and now the character should run up to/ follow this target to perform skill on it
				Vector3 dir = (targetPos - currPos);
				if (dir.magnitude <= targetingDistance) return true;
				else
				{	// try and get closer but not too close
					wantedPos = targetPos - (dir.normalized * (targetingDistance * 0.9f));
				}
			}

			else if (targetLocation == TargetLocation.AtSelected ||
				targetLocation == TargetLocation.SelectedDirection)
			{
				Vector3 dir = (targetPos - currPos);
				if (dir.magnitude <= targetingDistance) return true;
				else
				{	// try and get closer but not too close
					wantedPos = targetPos - (dir.normalized * (targetingDistance * 0.9f));
				}
			}

			return false;
		}

		/// <summary> Trigger the Skill's secondary effect at specified location. Can also specify a a
		///  targetable object to ignore when finding targets. </summary>
		public void ExecuteSecondary(Vector3 atLocation, Targetable ignore)
		{
			if (secondaryMaxTargets > 0)
			{
				List<Targetable> secondaryTargets = CollectSecondaryTargets(ignore, atLocation);
				for (int j = 0; j < secondaryTargets.Count; j++)
				{
					if (secondaryTargets[j] == null) continue; // need to check null in case it becomes null while loop was running
					if (eventHandler != null)
					{
						Vector3 hitPos = secondaryTargets[j].gameObject.transform.position;
#if UNITY5
						Collider col = secondaryTargets[j].GetComponent<Collider>();
						if (col != null)
						{
							float hitOffs = (float)hitHeightPercentage / 100f;
							hitPos.y += (col.bounds.size.y * hitOffs);
						}
#else
						if (secondaryTargets[j].collider != null)
						{
							float hitOffs = (float)hitHeightPercentage / 100f;
							hitPos.y += (secondaryTargets[j].collider.bounds.size.y * hitOffs);
						}
#endif
						eventHandler.OnSecondaryHit(owner, this, secondaryTargets[j], hitPos);
					}
				}
			}
		}

		/// <summary> Ask Skill to call the Fizzle event in plyBlox </summary>
		public void ExecuteFizzleEvent(Vector3 pos, bool wasObstacle)
		{
			if (eventHandler != null)
			{
				eventHandler.OnFizzle(owner, this, pos, wasObstacle);
			}
		}

		/// <summary> Called by Projectile to attempt hit on object. Return false if was invalid target. </summary>
		public bool AttemptHit(GameObject onObject, Vector3 hitPos)
		{
			if (owner.character.controlEnabled == false)
			{
				return false;
			}

			Targetable t = onObject.GetComponent<Targetable>();
			if (t != null)
			{
				if (IsValidTargetableType(t))
				{
					if (eventHandler != null) eventHandler.OnHit(owner, this, t, hitPos);
					if (secondaryMaxTargets > 0)
					{
						List<Targetable> secondaryTargets = CollectSecondaryTargets(t, onObject.transform.position);
						for (int j = 0; j < secondaryTargets.Count; j++)
						{
							if (secondaryTargets[j] == null) continue; // need to check null in case it becomes null while loop was running
							if (eventHandler != null) eventHandler.OnSecondaryHit(owner, this, secondaryTargets[j], hitPos);
						}
					}
					return true;
				}
			}
			return false;
		}

		/// <summary> Try and find first valid target that falls in the ray. Normally the ray comes from a
		///  mouse position to check if there is a valid target under the mouse cursor. </summary>
		public Targetable FindValidTargetAt(Ray ray)
		{
			LayerMask mask = 0;
			if ((validTargetsMask & ValidTargets.Player) == ValidTargets.Player) mask |= 1 << GameGlobal.LayerMapping.Player;
			if ((validTargetsMask & ValidTargets.RPGObject) == ValidTargets.RPGObject) mask |= 1 << GameGlobal.LayerMapping.plyObject;
			if ((validTargetsMask & ValidTargets.FriendlyActor) == ValidTargets.FriendlyActor ||
				(validTargetsMask & ValidTargets.NeutralActor) == ValidTargets.NeutralActor ||
				(validTargetsMask & ValidTargets.HostileActor) == ValidTargets.HostileActor
				//(validTargetsMask & ValidTargets.ReversedFriendlyActor) == ValidTargets.ReversedFriendlyActor ||
				//(validTargetsMask & ValidTargets.ReversedNeutralActor) == ValidTargets.ReversedNeutralActor ||
				//(validTargetsMask & ValidTargets.ReversedHostileActor) == ValidTargets.ReversedHostileActor
			){
				mask |= 1 << GameGlobal.LayerMapping.Player;
				mask |= 1 << GameGlobal.LayerMapping.NPC;
			}

			RaycastHit hit;
			if (Physics.Raycast(ray, out hit, mask))
			{
				//check if in range
				// !! do not do this as it is supposed to find a target at spot, not do the distance checks
				//if ((hit.transform.position - owner.transform.position).magnitude <= targetingDistance)
				{
					// check if targetable (should be except if something strange wrong)
					Targetable t = hit.transform.GetComponent<Targetable>();
					if (t != null)
					{
						// check if valid type of targetable, else considered just another obstacle
						if (IsValidTargetable(t, owner.transform, owner.transform.position, obstacbleCheckHeight, obstacleCheckMask))
						{
							return t;
						}
					}
				}
			}
			return null;
		}

		/// <summary> Return true of the target is a valid targetable type for the skill, according to the
		///  skill's settings. </summary>
		public bool IsValidTargetableType(Targetable target)
		{
			if (target == null) return false;

			// check if target is of correct type
			if (target.TargetableType() == Targetable.Type.Character)
			{
				CharacterControllerBase chara = target as CharacterControllerBase;
				if (chara == null) return false; // should not happen

				// Is the target a player?
				if ((validTargetsMask & ValidTargets.Player) == ValidTargets.Player)
				{
					if (chara.IsPlayer()) return true;
				}

				if (chara.actor == null) return false; // should not happen

				// only bother to continue if the Friendly, Neutral or Hostile checks are to be done
				if ((validTargetsMask & ValidTargets.FriendlyActor) == ValidTargets.FriendlyActor ||
					(validTargetsMask & ValidTargets.NeutralActor) == ValidTargets.NeutralActor ||
					(validTargetsMask & ValidTargets.HostileActor) == ValidTargets.HostileActor
					//(validTargetsMask & ValidTargets.ReversedFriendlyActor) == ValidTargets.ReversedFriendlyActor ||
					//(validTargetsMask & ValidTargets.ReversedNeutralActor) == ValidTargets.ReversedNeutralActor ||
					//(validTargetsMask & ValidTargets.ReversedHostileActor) == ValidTargets.ReversedHostileActor
				){
					// Check the status of the user towards the target
					StatusTowardsOther st = owner.HighestStatusToTarget(chara.actor);
					if (st == StatusTowardsOther.Friendly && (validTargetsMask & ValidTargets.FriendlyActor) == ValidTargets.FriendlyActor)
					{
						return true;
					}
					if (st == StatusTowardsOther.Neutral && (validTargetsMask & ValidTargets.NeutralActor) == ValidTargets.NeutralActor)
					{
						return true;
					}
					if (st == StatusTowardsOther.Hostile && (validTargetsMask & ValidTargets.HostileActor) == ValidTargets.HostileActor)
					{
						return true;
					}
				}

				//// Check the status of the target towards the user?
				//if ((validTargetsMask & ValidTargets.ReversedFriendlyActor) == ValidTargets.ReversedFriendlyActor ||
				//	(validTargetsMask & ValidTargets.ReversedNeutralActor) == ValidTargets.ReversedNeutralActor ||
				//	(validTargetsMask & ValidTargets.ReversedHostileActor) == ValidTargets.ReversedHostileActor
				//){
				//	StatusTowardsOther st = chara.actor.HighestStatusToTarget(owner);
				//	if (st >= StatusTowardsOther.Friendly && (validTargetsMask & ValidTargets.ReversedFriendlyActor) == ValidTargets.ReversedFriendlyActor)
				//	{
				//		return true;
				//	}
				//	if (st >= StatusTowardsOther.Neutral && (validTargetsMask & ValidTargets.ReversedNeutralActor) == ValidTargets.ReversedNeutralActor)
				//	{
				//		return true;
				//	}
				//	if (st >= StatusTowardsOther.Hostile && (validTargetsMask & ValidTargets.ReversedHostileActor) == ValidTargets.ReversedHostileActor)
				//	{
				//		return true;
				//	}
				//}
			}

			else if (target.TargetableType() == Targetable.Type.Object)
			{
				if ((validTargetsMask & ValidTargets.RPGObject) == ValidTargets.RPGObject) return true;
			}

			// not valid if reached here
			return false;
		}

		/// <summary> First call IsValidTargetableType() and if that is fine it will check if there is an
		///  obstacle between the target and the checkTr position or checkFrom position of checkTr is
		///  null. The checkHeight is an offset from the checkTr or checkFrom positions and checkMask is
		///  the layers considered to be obstacles. </summary>
		public bool IsValidTargetable(Targetable target, Transform checkTr, Vector3 checkFrom, float checkHeight, LayerMask checkMask)
		{
			if (IsValidTargetableType(target))
			{
				if (checkMask != 0)
				{
					// now check if there is an obstacle in way
					Vector3 startPos = checkFrom; startPos.y += checkHeight;
					Vector3 endPos = target.transform.position; endPos.y += checkHeight;
					Vector3 direction = endPos - startPos;
					RaycastHit hit;
					if (Physics.Raycast(startPos, direction, out hit, direction.magnitude, checkMask))
					{
						if (hit.transform != target.transform &&
							hit.transform != checkTr) return false; // hit something other than target and skill's user
					}
				}
				return true;
			}
			return false;
		}

		#endregion
		// ============================================================================================================
		#region debug

		protected void OnDrawGizmosSelected()
		{
			if (!showDebugInfo || owner == null) return;
			Gizmos.color = Color.yellow - new Color(0, 0, 0, 0.3f);
			plyUtil.GizmoDrawArc(transform.position + Vector3.up * 0.3f, transform.forward, targetingAngle, targetingDistance);

			// Show additional info when it is projectile
			if (deliveryMethod == DeliveryMethod.Projectile)
			{
				Gizmos.color = Color.red;
				Vector3 pos = owner.transform.position;
				pos += (owner.transform.right * projectileCreateOffset.x);
				pos += (owner.transform.up * projectileCreateOffset.y);
				pos += (owner.transform.forward * projectileCreateOffset.z);

				float r = collisionRayWidth > 0.0f ? collisionRayWidth : 0.05f;
				if (projectileMoveMethod == ProjectileMoveMethod.ActorFaceDirection || (maxEffects == 1 && projectileMoveMethod == ProjectileMoveMethod.AngledFromEach))
				{
					Vector3 targetLocation = owner.transform.position + (owner.transform.forward * maxFlightDistance);
					targetLocation.y += projectileCreateOffset.y;
					Gizmos.DrawLine(pos, targetLocation);
					Gizmos.DrawSphere(targetLocation, r);
				}

				else if (projectileMoveMethod == ProjectileMoveMethod.AngledFromEach)
				{
					float angleUnit = targetingAngle / (maxEffects - 1);
					float angle = -(targetingAngle / 2);

					for (int i = 0; i < maxEffects; i++)
					{
						Vector3 targetLocation = pos + (Quaternion.AngleAxis(+angle, Vector3.up) * owner.transform.forward * maxFlightDistance);
						Gizmos.DrawLine(pos, targetLocation);
						Gizmos.DrawSphere(targetLocation, r);
						angle += angleUnit;
					}
				}

				else if (projectileMoveMethod == ProjectileMoveMethod.DirectToTarget)
				{
					Vector3 targetLocation = owner.transform.position + (owner.transform.forward * targetingDistance);
					targetLocation.y += projectileCreateOffset.y;
					Gizmos.DrawLine(pos, targetLocation);
					Gizmos.DrawSphere(targetLocation, r);
				}

				if (collisionRayWidth > 0.0f) Gizmos.DrawSphere(pos, r);
			}
		}

		#endregion
		// ============================================================================================================
	}
}