﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/NPC/Movement/Simple")]
	[RequireComponent(typeof(CharacterController))]
	public class NPCMoveSimple : NPCMoveBase
	{
		public CharacterController characterController;
		public float stopDistance = 1f;
		public float gravity = 20f;
		public bool canMove = true;
		public bool canTurn = true;

		// ============================================================================================================

		private Transform _tr;
		private float moveSpeed;
		private float turnSpeed;
		private Vector3 destinition;
		
		private Vector3 targetDirection;
		private Vector3 forward;
		private Vector3 movement;
		private Vector3 gravityVec = Vector3.zero;

		private bool turning = false;
		private bool moving = false;
		private bool lastWasGrounded = false;

		// ============================================================================================================

		protected void Reset()
		{
			Setup();
		}

		protected void Start()
		{
			Setup();

			if (characterController == null)
			{
				Debug.LogError("[NPCMoveSimple] No character controller assigned.");
				enabled = false;
				return;
			}

			lastWasGrounded = false;
			_tr = characterController.transform;
		}

		private void Setup()
		{
			if (characterController == null) characterController = GetComponent<CharacterController>();
		}

		protected void Update()
		{
			if (GameGlobal.Paused)
			{
				if (moving) Stop();
				return;
			}

			UpdateRotation();
			UpdateMovement();
		}

		private void UpdateRotation()
		{
			if (!canTurn) return;
			if (moving || turning)
			{
				if (!turning)
				{
					targetDirection = destinition - _tr.position; targetDirection.y = 0f;
					targetDirection.Normalize();
				}

				forward = Vector3.RotateTowards(_tr.forward, targetDirection, turnSpeed * Time.deltaTime, 0.0f);
				_tr.rotation = Quaternion.LookRotation(forward);
				if (Vector3.Dot(_tr.forward, targetDirection) > 0.98f) turning = false;
			}
		}

		private void UpdateMovement()
		{
			if (!canMove) return;
			if (lastWasGrounded)
			{
				if (moving)
				{
					movement = _tr.forward * moveSpeed;
					characterController.Move((movement + gravityVec) * Time.deltaTime);
					lastWasGrounded = characterController.isGrounded;
				}
				else
				{
					movement = Vector3.zero;
					characterController.Move((movement + gravityVec) * Time.deltaTime);
					lastWasGrounded = characterController.isGrounded;
					if (lastWasGrounded) gravityVec = Vector3.zero;
					else gravityVec.y -= gravity * Time.deltaTime;
				}
			}

			else
			{
				characterController.Move((movement + gravityVec) * Time.deltaTime);
				lastWasGrounded = characterController.isGrounded;
				if (lastWasGrounded) gravityVec = Vector3.zero;
				else gravityVec.y -= gravity * Time.deltaTime;
			}
		}

		protected void LateUpdate()
		{
			if (!canMove) return;
			if (moving)
			{
				// reached destination?
				Vector3 curr = new Vector3(_tr.position.x, 0.0f, _tr.position.z);
				if (Vector3.Distance(destinition, curr) < stopDistance)
				{					
					moving = false;
					movement = Vector3.zero;
					characterController.Move(movement);
					return;
				}
			}
		}

		// ============================================================================================================

		public override void MoveTo(Vector3 pos, float moveSpeed, float turnSpeed)
		{
			this.moving = true;
			this.moveSpeed = moveSpeed;
			this.turnSpeed = turnSpeed;
			this.destinition = pos; this.destinition.y = 0.0f;
			this.targetDirection = (this.destinition - _tr.position);
			this.targetDirection.y = 0f; this.targetDirection.Normalize();
		}

		public override void FaceDirection(Vector3 direction, float turnSpeed)
		{
			Stop();
			this.turning = true;
			this.turnSpeed = turnSpeed;
			this.targetDirection = direction;
		}

		public override void Stop()
		{
			destinition = _tr.position;
			moving = false;
			movement = Vector3.zero;
			characterController.Move(movement);
		}

		public override Vector3 Velocity()
		{
			return characterController.velocity;
		}

		public override bool Grounded()
		{
			return lastWasGrounded; // characterController.isGrounded;
		}

		public override bool IsMovingOrPathing()
		{
			return moving;
		}


		public override bool InControlledTurn()
		{
			return turning;
		}

		// ============================================================================================================
	}
}