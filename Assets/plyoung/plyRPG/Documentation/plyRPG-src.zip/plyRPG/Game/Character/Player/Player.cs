﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;

namespace plyGame
{
	/// <summary>
	/// Shortcut to some common player related object references
	/// </summary>
	public class Player
	{
		/// <summary> The active player character. It can be either set in Awake or Start of the
		/// Player controller so you should not depend on it being ready in Start. </summary>
		public static PlayerBaseController Instance = null;

		/// <summary> This can be used to check if the player is actually ready. This will not only 
		/// return false while the Instance is null but also while the player is not in a 'ready'
		/// state. The Player character is considered ready when the Awake, Start, and Loading 
		/// (if persistence is on) is done and the Update loop was entered. </summary>
		public static bool IsReady
		{
			get
			{
				if (Instance == null) return false;
				return _ready;
			}

			set
			{
				_ready = value;
			}
		}
		private static bool _ready = false;

		/// <summary> The active player camera. It can be either set in Awake or Start of the
		/// camera controller so you should not depend on it being ready in Start.  </summary>
		public static Camera Camera = null;
	}

	// ============================================================================================================
}
