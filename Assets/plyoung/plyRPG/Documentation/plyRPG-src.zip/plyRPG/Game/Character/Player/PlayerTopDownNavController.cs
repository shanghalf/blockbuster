﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/Player/Top-Down Nav Controller")]
	[RequireComponent(typeof(NavMeshAgent))]
	public class PlayerTopDownNavController : PlayerBaseController
	{
		public NavMeshAgent agent;
		public bool holdMoveAllowed = false;
		public GameObject clickMarkerFab;

		// ============================================================================================================

		private Vector3 targetFacing = Vector3.zero;
		private Vector3 forward = Vector3.zero;

		private bool forcedTurning = false;
		private bool forcedTurningCompleting = false;
		private float forcedTurnTimeout = 0f;
		private bool isMoving = false;
		private int clickInput = 0; // 0:none, 1:held, 2:down, 3:up
		private GameObject clickMarker;

		private int Key_ClickMove = -1;

		// ============================================================================================================

		new protected void Reset()
		{
			base.Reset();
			moveSpeed = 7.0f;
			turnSpeed = 700f;
			mouseSelDistance = 100f;
			mouseSelAngle = 360;
			buttonSelDistance = 20f;
			buttonSelAngle = 360;

			if (agent == null) agent = GetComponentInChildren<NavMeshAgent>();
			if (agent != null)
			{
				agent.acceleration = 60f;
				agent.speed = 0f;
				agent.angularSpeed = 0f;
				agent.stoppingDistance = 1f;
			}
		}

		new protected void Awake()
		{
			base.Awake();
			if (agent == null) agent = GetComponentInChildren<NavMeshAgent>();
			if (agent == null)
			{
				Debug.LogError("[Top-Down Controller] No NavMeshAgent assigned. Character will now be disabled.");
				enabled = false;
				return;
			}

			_tr = agent.transform;
		}

		new protected void Start()
		{
			base.Start();

			if (clickMarkerFab != null)
			{
				clickMarker = (GameObject)Instantiate(clickMarkerFab);
				clickMarker.name = "Player Click-Marker";
				clickMarker.SetActive(false);
			}

			Key_ClickMove = plyInput.GetInputIdx("Player Top-Down NAV/ClickMove");

		}

		protected void OnEnable()
		{
			if (agent != null)
			{
				forcedTurning = false;
				agent.updateRotation = true;
			}
		}

		new protected void Update()
		{
			base.Update();

			if (GameGlobal.Paused) return;
			UpdateMovement();
			if (isMoving)
			{
				if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance)
				{
					Stop();
				}
			}
		}

		private void UpdateMovement()
		{
			//if (controlEnabled && !hint_DoNotMove && (!Interacting || movementCanStopInteraction))
			if (MovementControlAllowed())
			{

				// 0:none, 1:held, 2:went-down
				if (holdMoveAllowed) clickInput = plyInput.GetButtonDown(Key_ClickMove) ? 2 : plyInput.GetButton(Key_ClickMove) ? 1 : 0;
				else clickInput = plyInput.GetButtonDown(Key_ClickMove) ? 2 : 0;
				if (clickInput != 0)
				{
					Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
					RaycastHit hit;
					if (Physics.Raycast(ray, out hit, Mathf.Infinity, floorClickMask))
					{
						// first thing clicked must be a floor layer, else ignore the click
						// I use floorClickMask so that clicks can be set to pass only through certain things
						// for example, it should pass through Player but not NPCs
						if (hit.transform.gameObject.layer == GameGlobal.LayerMapping.Floor)
						{
							StopInteract();
							forcedTurning = false;
							RequestMoveTo(hit.point, false);

							if (clickMarker != null && clickInput == 2)
							{
								clickMarker.transform.position = hit.point;
								clickMarker.SetActive(false); // just in case it was still active so that things that triggers in OnEnable will work
								clickMarker.SetActive(true);
							}

							actor.ReceivedMoveCommand();
						}
					}
				}

				//if (plyInput.GetButtonUp(Key_ClickMove) || (holdMoveAllowed && plyInput.GetButton(Key_ClickMove)))
				//{
				//	Ray ray = Player.Camera.ScreenPointToRay(Input.mousePosition);
				//	RaycastHit hit;
				//	if (Physics.Raycast(ray, out hit, Mathf.Infinity, clickIgnoreMask))
				//	{
				//		// first thing clicked must be a floor layer, else ignore the click
				//		// clickIgnoreMask was set to ignore player character so that
				//		// player can click through the character
				//		if (hit.transform.gameObject.layer == GameGlobal.LayerMapping.Floor)
				//		{
				//			RequestMoveTo(hit.point, false);
				//		}
				//	}
				//}
			}

			if (forcedTurning)
			{
				forward = Vector3.Lerp(_tr.forward, targetFacing, Time.deltaTime * (turnSpeed / 100f));
				if (forward != Vector3.zero) _tr.rotation = Quaternion.LookRotation(forward, Vector3.up);
				if (forcedTurningCompleting)
				{
					forcedTurnTimeout -= Time.deltaTime;
					if (forcedTurnTimeout <= 0.0f)
					{
						forcedTurning = false;
						if (agent != null) agent.updateRotation = true;
					}
				}
				else
				{
					if (Vector3.Dot(_tr.forward, targetFacing) > 0.98f) forcedTurningCompleting = true;
				}
			}
		}
		
		// ============================================================================================================

		public override void SetMoveSpeed(float speed)
		{
			base.SetMoveSpeed(speed);
			if (agent != null) agent.speed = speed;
		}

		public override void SetTurnSpeed(float speed)
		{
			base.SetTurnSpeed(speed);
			if (agent != null) agent.angularSpeed = speed;
		}

		public override bool RequestFaceDirection(Vector3 direction, float delayAfter)
		{
			Stop();
			forcedTurning = true;
			if (agent != null) agent.updateRotation = false;
			forcedTurningCompleting = false;
			targetFacing = direction;
			forcedTurnTimeout = delayAfter;
			return true;
		}

		public override bool RequestMoveTo(Vector3 position, bool useFasterMovement)
		{
			//forcedTurning = false;
			if (agent == null) return false;
			if (agent.enabled)
			{
				isMoving = true;
				agent.speed = moveSpeed;
				agent.angularSpeed = turnSpeed;
				agent.destination = position;
				agent.SetDestination(position);
				return true;
			}
			return false;
		}

		public override void Stop()
		{
			isMoving = false;
			//forcedTurning = false;
			if (agent == null) return;
			if (agent.enabled)
			{
				agent.Stop();
				agent.ResetPath();
			}
		}

		public override bool Grounded()
		{
			return true;
		}

		public override Vector3 Velocity()
		{
			if (!isMoving) return Vector3.zero;
			return agent.velocity;
		}

		public override float MoveSpeed()
		{
			if (!isMoving) return 0f;
			float f = agent.desiredVelocity.magnitude;
			if (f > moveSpeed) return moveSpeed;
			else return f;
		}

		public override Vector3 Movement()
		{
			if (!isMoving) return Vector3.zero;

			//if (agent == null) return Vector3.zero;
			//if (agent.enabled == false) return Vector3.zero;
			return agent.desiredVelocity;
		}

		public override void OnDeath()
		{
			Stop();
			base.OnDeath();
			if (agent) agent.enabled = false;
		}

		// ============================================================================================================
	}
}