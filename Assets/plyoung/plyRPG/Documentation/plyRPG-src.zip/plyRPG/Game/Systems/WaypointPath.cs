﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class Waypoint
	{
		public Vector3 localPosition = Vector3.zero; // Patrol Points positions should be read as relative to the path's "center"
		public Quaternion rotation = Quaternion.identity;

		public Vector3 position { get; private set; }

		public Waypoint() { }
		public Waypoint(Vector3 position)
		{
			this.localPosition = position;
		}

		public void Init(WaypointPath path)
		{
			position = path._tr.position + localPosition;
		}
	}

	[AddComponentMenu("plyGame/Systems/Waypoint Path")]
	public class WaypointPath : MonoBehaviour
	{
		public List<Waypoint> points = new List<Waypoint>();

		// ================================================================================================================

		public Waypoint this[int index]
		{
			get
			{
				if (points == null) return null;
				if (index < 0) return null;
				if (index >= points.Count) return null;
				return points[index];
			}
		}

		public int Length
		{
			get
			{
				if (points == null) return 0;
				return points.Count;
			}
		}

		public Transform _tr { get; private set; }

		// ================================================================================================================

		protected void Reset()
		{
			if (points.Count == 0)
			{
				points.Add(new Waypoint(new Vector3(-2f, 0.1f, 0f)));
				points.Add(new Waypoint(new Vector3(2f, 0.1f, 2f)));
				points.Add(new Waypoint(new Vector3(2f, 0.1f, -2f)));
			}
		}

		protected void Awake()
		{
			_tr = this.transform;

			for (int i = 0; i < points.Count; i++)
			{
				points[i].Init(this);
			}
		}

		/// <summary>get the proper position of the patrol point</summary>
		public Vector3 GetPointPosition(int index)
		{
			if (index >= 0 && index < points.Count)
			{
				return _tr.position + points[index].localPosition;
			}
			return _tr.position;
		}

		// ================================================================================================================

		void OnDrawGizmos()
		{
			Gizmos.color = Color.white;
			Gizmos.DrawLine(transform.position - Vector3.up * 0.1f, transform.position + Vector3.up * 1.7f);
			Gizmos.DrawCube(transform.position - Vector3.up * 0.1f, new Vector3(0.1f, 0.1f, 0.1f));
			Gizmos.DrawIcon(transform.position + Vector3.up * 2f, "plygame/path.png");
		}

		// ============================================================================================================
	}
}