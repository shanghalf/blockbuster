﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("plyGame/Systems/Spawn Point")]
	public class SpawnPoint : MonoBehaviour, IPersistable
	{
		[System.Serializable]
		public class SpawnInfo
		{
			public int max = 1;			// (0 = endless) how many can be spawned, ever (not how many are spawned at one time when group is spawned)
			public GameObject fab;		// prefab of character to spawn
			public int initLevel = 0;	// (0 to use whatever the prefab is atm) initial level to set character to (overwritten by actor when it adjust self to player level)
			public NPCController.IdleMode idleMode = NPCController.IdleMode.Wander;
			public NPCController.WanderArea wanderArea = NPCController.WanderArea.Circular; // Type of wander area
			public float wanderRadius = 10f;			// [IdleMode.Wander] Radius around spawn point. With WanderArea.Rectangular this is angle of rectangle
			public Vector2 wanderWH = Vector2.one;		// [IdleMode.Wander] Width & Height of wander area when WanderArea.Rectangular
			public float wanderDelayMin = 0.5f;			// [IdleMode.Wander] Min time, in Randomiser, to wait before choosing a new spot to move to
			public float wanderDelayMax = 2.0f;			// [IdleMode.Wander] Max time, in Randomiser, to wait before choosing a new spot to move to
			public WaypointPath path;					// [IdleMode.Patrol] Path to follow
			public Transform followObject;				// [IdleMode.Follow] Object to follow around
			public float minFollowDistance = 5f;		// Do not get too close
			public float maxFollowDistance = 10f;		// Get closer when too far

			[System.NonSerialized] public int spawnCount = 0;		// how many has been spawned of this over life time
			[System.NonSerialized] public int deaths = 0;			// how many has died (needed by save system to determine what to init spawnCount to when loading)
			[System.NonSerialized] public bool wantsToSpawn = true;	// set true at start and when NPC from this spawn dies
		}

		public bool persistenceOn = true;

		public int ident = 0;
		public string notes;

		public float activePlayerDistance = 50f;		// the max distance the player can be from spawn point for it to be actively spawning NPCs
		public float activeCheckTimout = 5f;			// check how far the player is from the spawn point at this rate (seconds)

		public float spawnWhenPlayerDistance = 20f;		// only spawn while the player is at this distance or closer
		public float plrDistanceCheckInterval = 0.5f;	// it will check the player's distance at this rate

		public enum SpawnMethod { IndividualRespawn, GroupRespawn, GroupContinues }
		public SpawnMethod spawnMethod = SpawnMethod.IndividualRespawn;

		public float spawnRate = 10f;			// minimum time to wait before doing any spawning, no matter the spawnMethod
		public float rateBetweenSpawn = 0.2f;	// this is the rate at which individuals from group is spawned (happens after the spawnRate timeout)

		public List<SpawnInfo> spawnGroup = new List<SpawnInfo>(0);

		// ============================================================================================================

		private Transform _tr;
		private float activePlayerDistanceSqr;
		private float spawnWhenPlayerDistanceSqr;
		private float playerDistance = 0f;
		private float activeCheckTime = 0f;
		private float plrDistanceCheckTime = 0f;
		private bool shouldCheckSpawn = true;

		private float spawnRateTime = 0f;			// the next Time.time that a group can start spawning while in State.Ready
		private float rateBetweenSpawnTime = 0f;	// the next Time.time that character from a group can be spawned while in State.Spawning
		private List<int> toSpawn = new List<int>(0);

		enum State { Loading, MustWait, Idle, Ready, Spawning, Closed }
		private State state = State.Loading;

		private EventHandler_SpawnPoint eventHandler = null;

		// ============================================================================================================

		protected void Reset()
		{
			persistenceOn = true;
			PersistableObject p = gameObject.GetComponent<PersistableObject>();
			if (p == null) p = gameObject.AddComponent<PersistableObject>();
			p.objectStartsActive = true;
			p.persistBloxLocalVars = true;
			p.persistPosition = false;
			p.persistRotation = false;
			p.persistScale = false;
			p.persistActiveState = true;
			p.persistDestroyedState = false;
		}

		protected void Awake()
		{
			PersistableObject p = gameObject.GetComponent<PersistableObject>();
			if (persistenceOn)
			{
				if (p == null)
				{
					p = gameObject.AddComponent<PersistableObject>();
					p.objectStartsActive = true;
					p.persistBloxLocalVars = true;
					p.persistPosition = false;
					p.persistRotation = false;
					p.persistScale = false;
					p.persistActiveState = true;
					p.persistDestroyedState = false;
				}
			}
			else
			{
				if (p != null)
				{	// disable persistence if persist object present
					PersistableObject.DisablePersistenceOn(gameObject);
				}
			}

			activePlayerDistanceSqr = activePlayerDistance * activePlayerDistance;
			spawnWhenPlayerDistanceSqr = spawnWhenPlayerDistance * spawnWhenPlayerDistance;
			_tr = transform;
			shouldCheckSpawn = true;
		}

		protected void Start()
		{
			shouldCheckSpawn = true;
			state = State.Loading; // wait for loading to complete
			eventHandler = GetComponent<EventHandler_SpawnPoint>();
		}

		// ============================================================================================================

		public void Save(string key)
		{
			if (!persistenceOn) return;

			string data = "";
			for (int i = 0; i < spawnGroup.Count; i++)
			{
				if (spawnGroup[i].max > 0)
				{	// only save if max is bigger than 0 else it is endless anyway
					// save the deaths as that is what the spawnCount must init to when loading
					data += i.ToString() + ((char)30) + spawnGroup[i].deaths.ToString() + ((char)31);
				}
			}
			GameGlobal.SetStringKey(key, data);
		}

		public void Load(string key)
		{
			if (!persistenceOn) return;
			string data = GameGlobal.GetStringKey(key, "");
			string[] groupsData = data.Split((char)31);
			for (int i = 0; i < groupsData.Length; i++)
			{
				if (string.IsNullOrEmpty(groupsData[i])) continue;
				string[] v = groupsData[i].Split((char)30);
				if (v.Length == 2)
				{
					int idx = int.Parse(v[0]);
					if (idx >= 0 && idx < spawnGroup.Count)
					{
						int cnt = int.Parse(v[1]);
						spawnGroup[idx].spawnCount = spawnGroup[idx].deaths = cnt;
						spawnGroup[idx].wantsToSpawn = (spawnGroup[idx].spawnCount < spawnGroup[idx].max || spawnGroup[idx].max <= 0);
					}
				}
			}
		}

		public void DeleteSaveData(string key)
		{
			if (!persistenceOn) return;
			GameGlobal.DeleteKey(key);
		}

		public void DisablePersistence()
		{
			persistenceOn = false;
		}

		// ============================================================================================================

		protected void LateUpdate()
		{
			if (state == State.Loading)
			{	// skip the first frame so that loading can complete
				state = State.Idle;
				return;
			}

			if (state == State.Closed) return;		// no need to continue. there is nothing more that can be spawned by this spawn point
			if (state == State.MustWait) return;	// must wait before can spawn again. for example, waiting for whole group to be killed

			if (Player.Instance == null)
			{
				// no player to check distance against, disable now and check again later
				Invoke("CheckIfShouldEnable", activeCheckTimout);
				gameObject.SetActive(false);
				return;
			}

			// check if should disable
			if (Time.time > activeCheckTime)
			{
				activeCheckTime = Time.time + activeCheckTimout;
				playerDistance = (Player.Instance.transform.position - _tr.position).sqrMagnitude;
				if (playerDistance >= activePlayerDistanceSqr)
				{	// player is too far from object, disable the object
					// setup an invoke to check when object should become active again
					Invoke("CheckIfShouldEnable", activeCheckTimout);
					gameObject.SetActive(false);
				}
			}

			if (state == State.Spawning)
			{
				UpdateSpawning();
			}

			else
			{
				// check if spawning mode should be disabled/ enabled
				if (Time.time > plrDistanceCheckTime)
				{
					plrDistanceCheckTime = Time.time + plrDistanceCheckInterval;
					playerDistance = (Player.Instance.transform.position - _tr.position).sqrMagnitude;
					if (playerDistance >= spawnWhenPlayerDistanceSqr) state = State.Idle;
					else state = State.Ready;
				}

				if (shouldCheckSpawn && state == State.Ready && Time.time > spawnRateTime)
				{
					DetermineWhatToSpawn();
				}
			}

		}

		private void CheckIfShouldEnable()
		{
			if (Player.Instance == null)
			{	// no player object, will check again a bit later
				Invoke("CheckIfShouldEnable", activeCheckTimout);
				return;
			}

			playerDistance = (Player.Instance.transform.position - _tr.position).sqrMagnitude;
			if (playerDistance < activePlayerDistanceSqr)
			{
				activeCheckTime = Time.time + activeCheckTimout;
				gameObject.SetActive(true);
			}
			else
			{	// not in range, wait some more
				Invoke("CheckIfShouldEnable", activeCheckTimout);
			}
		}

		private void UpdateSpawning()
		{
			if (toSpawn.Count == 0)
			{	// done with batch. wait till one is killed, in which case the state will be updated to Ready if appropriate
				state = State.MustWait;

				// check if should be in 'ready' state
				if (spawnMethod == SpawnMethod.IndividualRespawn)
				{
					// spawn characters as they are killed. check if one was not killed while was spawning group
					for (int i = 0; i < spawnGroup.Count; i++) if (spawnGroup[i].wantsToSpawn)
						{
							state = State.Ready; break;
						}
				}
				else if (spawnMethod == SpawnMethod.GroupContinues)
				{
					// just spawned a group. ready to spawn another.
					state = State.Ready;
				}
				else if (spawnMethod == SpawnMethod.GroupRespawn)
				{
					// unlikely that whole group will already be killed but check anyway
					bool foundOneAlive = false;
					for (int i = 0; i < spawnGroup.Count; i++) if (spawnGroup[i].wantsToSpawn == false)
						{
							foundOneAlive = true; break;
						}
					if (!foundOneAlive) state = State.Ready;
				}
			}
			else if (Time.time > rateBetweenSpawnTime)
			{
				rateBetweenSpawnTime = Time.time + rateBetweenSpawn;
				Spawn(toSpawn[0]);
				toSpawn.RemoveAt(0);
			}
		}

		private void DetermineWhatToSpawn()
		{
			// create a list of things to spawn
			toSpawn = new List<int>(0);
			spawnRateTime = Time.time + spawnRate;

			for (int i = 0; i < spawnGroup.Count; i++)
			{
				if (spawnGroup[i].wantsToSpawn || spawnMethod == SpawnMethod.GroupContinues)
				{
					if (spawnGroup[i].spawnCount < spawnGroup[i].max && spawnGroup[i].max > 0 && spawnGroup[i].fab != null)
					{	// found one to spawn
						toSpawn.Add(i);
					}
					else
					{	// can't spawn any more of this character
						spawnGroup[i].wantsToSpawn = false;
					}
				}
			}

			if (toSpawn.Count > 0)
			{	// should start spawning characters from list
				state = State.Spawning;
				rateBetweenSpawnTime = 0;
			}
			else
			{	// did not find anything to spawn, so this spawn point reached its end
				state = State.Closed;
				toSpawn = null;
			}
		}

		private void Spawn(int idx)
		{
			spawnGroup[idx].spawnCount++;
			spawnGroup[idx].wantsToSpawn = false;

			GameObject go = (GameObject)Instantiate(spawnGroup[idx].fab);
			go.transform.position = transform.position;

			// Turn off persistence for spawned character
			PersistableObject.DisablePersistenceOn(go);

			// Setup the NPC
			NPCController npc = go.GetComponent<NPCController>();
			npc.spawnGroupIdx = idx;
			npc.spawnPoint = this;
			npc.spawnLocation = transform.position;

			npc.idleMode = spawnGroup[idx].idleMode;
			npc.wanderArea = spawnGroup[idx].wanderArea;
			npc.wanderRadius = spawnGroup[idx].wanderRadius;
			npc.wanderWH = spawnGroup[idx].wanderWH;
			npc.wanderDelayMin = spawnGroup[idx].wanderDelayMin;
			npc.wanderDelayMax = spawnGroup[idx].wanderDelayMax;
			npc.path = spawnGroup[idx].path;
			npc.followObject = spawnGroup[idx].followObject;
			npc.minFollowDistance = spawnGroup[idx].minFollowDistance;
			npc.maxFollowDistance = spawnGroup[idx].maxFollowDistance;

			if (spawnGroup[idx].initLevel > 0) npc.actor.startLevel = spawnGroup[idx].initLevel;

			if (eventHandler != null)
			{
				eventHandler.OnCreatedNPC(npc);
			}
		}

		public void OnCharacterKilled(int idx)
		{
			spawnGroup[idx].wantsToSpawn = true;
			spawnGroup[idx].deaths++;

			// check if should be in 'ready' state
			if (spawnMethod == SpawnMethod.IndividualRespawn)
			{
				// spawn characters as they are killed. check if one was not killed while was spawning group
				state = State.Ready;
			}
			else if (spawnMethod == SpawnMethod.GroupContinues)
			{
				// NPC getting killed does not influence this
			}
			else if (spawnMethod == SpawnMethod.GroupRespawn)
			{
				// ready once whole group is killed
				bool foundOneAlive = false;
				for (int i = 0; i < spawnGroup.Count; i++) if (spawnGroup[i].wantsToSpawn == false)
					{
						foundOneAlive = true; break;
					}
				if (!foundOneAlive) state = State.Ready;
			}
		}

		// ============================================================================================================

		public int _edHlp = 1;
		protected void OnDrawGizmos()
		{
			string ico = "plygame/spawn1.png";

			if (_edHlp == 2)
			{
				ico = "plygame/spawn2.png";
				Gizmos.color = Color.green;
			}
			else if (_edHlp == 3)
			{
				ico = "plygame/spawn3.png";
				Gizmos.color = Color.yellow;
			}
			else Gizmos.color = Color.blue;

			Gizmos.DrawLine(transform.position - Vector3.up * 0.1f, transform.position + Vector3.up * 1.75f);
			Gizmos.DrawCube(transform.position - Vector3.up * 0.1f, new Vector3(0.1f, 0.1f, 0.1f));
			Gizmos.DrawIcon(transform.position + Vector3.up * 2f, ico);
		}

		// ============================================================================================================
	}
}