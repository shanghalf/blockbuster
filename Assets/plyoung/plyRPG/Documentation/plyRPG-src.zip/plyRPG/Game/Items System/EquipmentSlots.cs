﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Items are things that characters can pick up and use. Some can also be 
	/// 'equipped' and this class handles that for the object it is on. </summary>
	[System.Serializable]
	[AddComponentMenu("plyGame/Item System/Equipment Slots")]
	public class EquipmentSlots : MonoBehaviour, IPersistable
	{
		public bool persistenceOn = true;

		// ============================================================================================================

		public class EquippedItem
		{
			public Item item;			// instance of equipped item
			public int slot;			// slot the item is in (index into list as defined in Items editor)
		}

		public List<EquippedItem> items { get; set; }
		private EventHandler_Item eventHandler;
		private Transform equipTR = null;
		private ItemBag bag = null;

		// ============================================================================================================

		protected void Awake()
		{
			items = new List<EquippedItem>(0);
		}

		protected void Start()
		{
			// event handlers are grabbed during Start since they do not yet exist during Awake
			eventHandler = GetComponent<EventHandler_Item>();
		}

		// ============================================================================================================

		public void Save(string key)
		{
			if (!persistenceOn) return;
			string data = "";
			for (int i = 0; i < items.Count; i++)
			{
				data += items[i].item.prefabId.ToString() + (char)30 + items[i].slot.ToString() + (char)31;
			}

			key = key + ".equip";
			GameGlobal.SetStringKey(key, data);
			
			DeleteVarKeys(key);

			// save variable data for each item that has such variables to save
			for (int i = 0; i < items.Count; i++)
			{	// item vars are only saved when they do not stack
				if (items[i].item.maxStack <= 1 && items[i].item.blox != null)
				{
					string bagKey = key + "." + items[i].slot.ToString();
					string varData = items[i].item.blox.EncodeLocalVariables(false);
					if (false == string.IsNullOrEmpty(varData)) GameGlobal.SetStringKey(bagKey, varData);
				}
			}
		}

		public void Load(string key)
		{
			if (!persistenceOn) return;
			key = key + ".equip";
			string data_s = GameGlobal.GetStringKey(key, null);

			// note, test for null and not empty string since if there was an empty string 
			// entry it simply means there is nothing equipped
			if (data_s != null)
			{
				// unequip all
				for (int i = 0; i < items.Count; i++)
				{
					if (items[i] != null)
					{
						if (items[i].item != null)
						{
							if (items[i].item.persistObj) items[i].item.persistObj.persistDestroyedState = false;
							Destroy(items[i].item.gameObject);
						}
					}
				}

				items = new List<EquippedItem>();

				// now restore what should be equipped
				string[] data = data_s.Split((char)31);
				for (int i = 0; i < data.Length; i++)
				{
					if (string.IsNullOrEmpty(data[i])) continue;
					string[] v = data[i].Split((char)30);
					if (v.Length == 2)
					{
						Item it = ItemsAsset.Instance.GetDefinition(new UniqueID(v[0]));
						int slot = int.Parse(v[1]);
						EquippedItem iib = LoadItemToEquipSlot(it, slot);
						if (iib != null)
						{	// only bother if maxStack < 1 since this is only kind of item that can save vars
							if (iib.item.maxStack <= 1)
							{
								// decode variables if any
								string equipKey = key + "." + slot.ToString();
								string varData = GameGlobal.GetStringKey(equipKey, null);
								if (iib.item.blox != null) iib.item.blox.DecodeLocalVariables(varData);
							}
						}
					}
				}
			}
		}

		public void DeleteSaveData(string key)
		{
			if (!persistenceOn) return;
			key = key + ".equip";
			GameGlobal.DeleteKey(key);
			DeleteVarKeys(key);
		}

		public void DisablePersistence()
		{
			persistenceOn = false;
		}

		private void DeleteVarKeys(string key)
		{
			for (int i = 0; i < ItemsAsset.Instance.equipSlots.Count; i++)
			{
				string equipKey = key + "." + i.ToString();
				GameGlobal.DeleteKey(equipKey);
			}
		}

		private EquippedItem LoadItemToEquipSlot(Item itemPrefab, int slot)
		{
			if (itemPrefab == null)
			{
				Debug.LogWarning("[EquipmentSlots] Load error: Item definition could not be found.");
				return null;
			}

			EquippedItem iib = new EquippedItem();
			iib.slot = slot;

			Transform tr = gameObject.transform.GetFirstChildWithTag("EquipSlot " + ItemsAsset.Instance.equipSlots[slot]);
			if (tr == null)
			{
				iib.item = Item.CreateItem(itemPrefab.prefabId, Item.ItemLocation.Equipped, Vector3.zero, Quaternion.identity, null);
				if (equipTR == null)
				{
					GameObject go = new GameObject("Equipped Items");
					equipTR = go.transform;
					equipTR.parent = gameObject.transform;
				}
				iib.item.transform.parent = equipTR;
				iib.item.transform.position = Vector3.zero;
			}
			else
			{
				iib.item = Item.CreateItem(itemPrefab.prefabId, Item.ItemLocation.Equipped, tr.position, tr.rotation, null);
				iib.item.transform.parent = tr;
			}

			items.Add(iib);
			return iib;
		}

		// ============================================================================================================

		public bool EquipItem(Item it, bool visualEquipFailSilent, ItemBag.ItemDropOption dropOpt)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("Equipping Item failed. No equip slots defined.");
				return false;
			}

			if (it == null)
			{
				Debug.LogWarning("Equipping Item failed. Item invalid.");
				return false;
			}

			if (it.equipSlot < 0)
			{
				Debug.LogWarning("Equipping Item failed. Item do not have any Equip Slot set in its definition.");
				return false;
			}

			return EquipItem(it, it.equipSlot, visualEquipFailSilent, dropOpt);
		}

		public bool EquipItem(Item it, string toEquipSlot, bool visualEquipFailSilent, ItemBag.ItemDropOption dropOpt)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("Equipping Item failed. No equip slots defined.");
				return false;
			}

			if (it == null)
			{
				Debug.LogWarning("Equipping Item failed. Item invalid.");
				return false;
			}

			if (string.IsNullOrEmpty(toEquipSlot))
			{
				Debug.LogWarning("Equipping Item failed. Equip Slot name invalid.");
				return false;
			}

			int idx = ItemsAsset.Instance.equipSlots.IndexOf(toEquipSlot);
			if (idx < 0)
			{
				Debug.LogWarning("Equipping Item failed. Equip Slot not defined: " + toEquipSlot);
				return false;
			}

			return EquipItem(it, idx, visualEquipFailSilent, dropOpt);
		}

		public bool EquipItem(Item it, int toEquipSlotIdx, bool visualEquipFailSilent, ItemBag.ItemDropOption dropOpt)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("Equipping Item failed. No equip slots defined.");
				return false;
			}

			if (it == null)
			{
				Debug.LogWarning("Equipping Item failed. Item invalid.");
				return false;
			}

			if (toEquipSlotIdx < 0 || toEquipSlotIdx >= ItemsAsset.Instance.equipSlots.Count)
			{
				Debug.LogWarning("Equipping Item failed. Slot index invalid.");
				return false;
			}

			// first unequip if anything in way
			UnEquipItem(toEquipSlotIdx, dropOpt);

			// now equip new item
			EquippedItem iib = null;
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot == toEquipSlotIdx)
				{
					iib = items[i];
					break;
				}
			}

			if (iib == null)
			{
				iib = new EquippedItem();
				iib.slot = toEquipSlotIdx;
				items.Add(iib);
			}

			Item replaced = iib.item;

			// Create the new Equipped Item
			Transform tr = gameObject.transform.GetFirstChildWithTag("EquipSlot " + ItemsAsset.Instance.equipSlots[iib.slot]);
			if (tr == null)
			{
				if (!visualEquipFailSilent) Debug.LogError("[EquipmentSlots] An object with tag [EquipSlot " + ItemsAsset.Instance.equipSlots[iib.slot] + "] could not be found on the character. Item object could not be equipped.");
				iib.item = Item.CreateItem(it.prefabId, Item.ItemLocation.Equipped, Vector3.zero, Quaternion.identity, null);
				if (equipTR == null)
				{
					GameObject go = new GameObject("Equipped Items");
					equipTR = go.transform;
					equipTR.parent = gameObject.transform;
				}
				iib.item.transform.parent = equipTR;
				iib.item.transform.position = Vector3.zero;
			}
			else
			{
				iib.item = Item.CreateItem(it.prefabId, Item.ItemLocation.Equipped, tr.position, tr.rotation, null);
				iib.item.transform.parent = tr;
			}

			// check if should restore the item's local variables
			if (it.maxStack <= 1 && iib.item.blox != null && it.blox != null)
			{
				foreach (plyVar v in it.blox.LocalVars.Values)
				{
					iib.item.blox.SetLocalVarValue(v.name, v.GetValue());
				}
			}

			// Queue Equip event to be triggered
			EventHandler_Item.Message msg = new EventHandler_Item.Message()
			{
				slot = toEquipSlotIdx,
				item = iib.item,
				owner = gameObject
			};

			StartCoroutine("TriggeEquipEvent", msg);

			return true;
		}

		public bool UnEquipItem(string equipSlot, ItemBag.ItemDropOption dropOpt)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("UnEquipping Item failed. No equip slots defined.");
				return false;
			}

			if (string.IsNullOrEmpty(equipSlot))
			{
				Debug.LogWarning("UnEquipping Item failed. Equip Slot name invalid.");
				return false;
			}

			int idx = ItemsAsset.Instance.equipSlots.IndexOf(equipSlot);
			if (idx < 0)
			{
				Debug.LogWarning("UnEquipping Item failed. Equip Slot not defined: " + equipSlot);
				return false;
			}

			return UnEquipItem(idx, dropOpt);
		}

		public bool UnEquipItem(int slot, ItemBag.ItemDropOption dropOpt)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("UnEquipping Item failed. No equip slots defined.");
				return false;
			}

			if (slot < 0 || slot >= ItemsAsset.Instance.equipSlots.Count)
			{
				Debug.LogWarning("UnEquipping Item failed. Slot index invalid.");
				return false;
			}

			EquippedItem iib = null;
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot == slot)
				{
					iib = items[i];

					// remove the item from equip slot
					// will destroy gameObject later
					items.RemoveAt(i);

					break;
				}
			}

			if (iib != null)
			{
				if (iib.item != null)
				{
					// trigger the unequip events
					EventHandler_Item.Message msg = new EventHandler_Item.Message()
					{
						slot = iib.slot,
						item = iib.item,
						owner = gameObject
					};

					// call event on Bag
					if (eventHandler) eventHandler.OnItemUnEquipped(msg);

					// call event on Item
					if (msg.item.eventHandler) msg.item.eventHandler.OnItemUnEquipped(msg);
				
					// try to add the object to bag
					bool addedToBag = false;

					if (dropOpt != ItemBag.ItemDropOption.alwaysDestroy && dropOpt != ItemBag.ItemDropOption.alwaysToScene)
					{
						if (bag == null) bag = gameObject.GetComponent<ItemBag>();
						if (bag != null)
						{
							addedToBag = bag.AddItemToBag(iib.item);
						}
					}

					if (!addedToBag)
					{	// if failed to add to bag then drop
						if (dropOpt == ItemBag.ItemDropOption.toScene || dropOpt == ItemBag.ItemDropOption.alwaysToScene)
						{
							// create dropped item in scene
							Vector3 startPos = transform.position + (Vector3.up * 1.5f);
							Item droppedItem = Item.CreateItem(iib.item.prefabId, Item.ItemLocation.Scene, startPos, Quaternion.identity, null, true, transform.forward);

							// restore variables to dropped
							if (iib.item.maxStack <= 1 && iib.item.blox != null && droppedItem.blox != null)
							{
								foreach (plyVar v in iib.item.blox.LocalVars.Values)
								{
									droppedItem.blox.SetLocalVarValue(v.name, v.GetValue());
								}
							}
						}
					}

					// destroy game object
					Destroy(iib.item.gameObject);
				}
			}

			return true;
		}

		public bool ItemIsEquipped(Item it)
		{
			if (it == null) return false;
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].item != null)
				{
					if (items[i].item.prefabId == it.prefabId) return true;
				}
			}
			return false;
		}

		private IEnumerator TriggeEquipEvent(EventHandler_Item.Message msg)
		{
			// skip two frames to give Item chance to init properly
			yield return null;
			yield return null;

			// call event on Bag
			if (eventHandler) eventHandler.OnItemEquipped(msg);

			// call event on item
			if (msg.item.eventHandler) msg.item.eventHandler.OnItemEquipped(msg);
		}

		public Item ItemInSlot(int slot)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("Can't find Item in Equip Slots. No equip slots defined.");
				return null;
			}

			if (slot < 0 || slot >= ItemsAsset.Instance.equipSlots.Count)
			{
				Debug.LogWarning("Can't find Item in Equip Slots. Slot index invalid.");
				return null;
			}

			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot == slot)
				{
					return items[i].item;
				}
			}

			return null;
		}

		public Item ItemInSlot(string slotName)
		{
			if (ItemsAsset.Instance.equipSlots.Count == 0)
			{
				Debug.LogWarning("Can't find Item in Equip Slots. No equip slots defined.");
				return null;
			}

			if (string.IsNullOrEmpty(slotName))
			{
				Debug.LogWarning("Can't find Item in Equip Slots. Equip Slot name invalid.");
				return null;
			}

			int idx = ItemsAsset.Instance.equipSlots.IndexOf(slotName);
			if (idx < 0)
			{
				Debug.LogWarning("Can't find Item in Equip Slots. Equip Slot not defined: " + slotName);
				return null;
			}
			for (int i = 0; i < items.Count; i++)
			{
				if (items[i].slot == idx)
				{
					return items[i].item;
				}
			}

			return null;
		}

		// ============================================================================================================
	}
}
