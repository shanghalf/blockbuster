﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Items are things that characters can pick up and use </summary>
	[AddComponentMenu("plyGame/Item System/Item")]
	public class Item : MonoBehaviour, IPersistable
	{
		// ============================================================================================================
		#region properties

		public bool persistenceOn = true; //!< Indicate if this Item will take part in LodSave or not

		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data

		public UniqueID prefabId = new UniqueID();//!< Unique id. All same Items will share the same ID as this is unique per Item definition/ prefab, not per placed Item.

		public int itemType = -1;		//!< Type of this Item, as defined in Items  System settings. Sword, Armour, etc.
		public int itemSubType = -1;	//!< Sub-type of the Item ,as defined in settings. Axe, Sword, etc.

		public GameObject floorArt;		//!< The art shown while item is not held by a character (for example when item is laying on floor)
		public GameObject heldArt;		//!< The art used when the item is held by character

		public int maxStack = 1;		//!< how many of this item can be stacked in same slot in bag
		public float weight = 0f;		//!< weight of the item when weight based system is used
		public int hSlots = 1;			//!< number of horizontal slots the item takes up when slots based system is used
		public int vSlots = 1;			//!< number of vertical slots the item takes up when slots based system is used

		public float autoPickupDist = 0f; //!< auto-pickup within this distance
		public int baseValue = 1;		//!< base value (in currency)

		public bool isCurrency = false;	//!< if true then this item is currency. when the player pick it up it will add a certain amount of currency rather than going into the bag like a normal item.
		public int minCurrency = 1;		//!< when picked up a random amount can be generated between min and max
		public int maxCurrency = 1;		//!< when picked up a random amount can be generated between min and max

		public bool canEquip = false;			//!< can the item be equipped? For example, Sword
		public bool consumeOnUse = false;		//!< is the item consumed when used? For example, Potions.

		public int equipSlot = -1;				//!< indicates to which slot this can be equipped by default

		public bool freezeRotWhenDrop = false;	//<! should rigidbody freeze rotation be true when this item is dropped? This is used by bag when dropping items from it

		#endregion
		// ============================================================================================================
		#region runtime vars

		public enum ItemLocation { Scene, Bag, Equipped }
		public ItemLocation location { get; private set; } // this helps the Item determine which model to show. by default scene is assumed. equipped must be explicitly set when this item is equipped.

		private float distanceCheckTime = 0.0f;
		public plyBlox blox { get; private set; } // can be null
		public PersistableObject persistObj { get; private set; } // can be null
		public EventHandler_Item eventHandler { get; private set; } // can be null
		private bool isRuntimeItem = false;

#if UNITY5
		new Collider collider;
		new Rigidbody rigidbody;
#endif

		#endregion
		// ============================================================================================================
		#region start/ init

		protected void Reset()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyItem;
			prefabId = UniqueID.Create(prefabId);
			PersistableObject p = gameObject.GetComponent<PersistableObject>();
			if (p == null) p = gameObject.AddComponent<PersistableObject>();
			p.objectStartsActive = true;	// starts active i assume
			p.persistBloxLocalVars = false; // normally do not need to save these as they will not change
			p.persistPosition = false;		// position wont change
			p.persistRotation = false;		// rotation wont change
			p.persistScale = false;			// scale wont change
			p.persistActiveState = false;	// active state should not change
			p.persistDestroyedState = true;	// need to know if the item was destroyed from scene before, when loading
		}

		protected void Awake()
		{
#if UNITY5
			collider = GetComponent<Collider>();
			rigidbody = GetComponent<Rigidbody>();
#endif
			location = ItemLocation.Scene;
			gameObject.layer = GameGlobal.LayerMapping.plyItem;
			blox = gameObject.GetComponent<plyBlox>();
			persistObj = gameObject.GetComponent<PersistableObject>();
		}

		protected void Start()
		{
			eventHandler = gameObject.GetComponent<EventHandler_Item>();

			// there should be no collider on the Item object itself
			if (collider != null)
			{
				Debug.LogWarning("You should not place a collider on the Item object. The Item's Floor model object should have a collider set as a trigger. Now Destroying the collider on the Item object.");
				Destroy(collider);
			}

			if (location == ItemLocation.Bag)
			{
				// remove PersistableObject
				if (persistObj != null)
				{
					persistObj.persistDestroyedState = false;
					Destroy(persistObj);
				}

				// delete all child objects as I want no art in this case
				for (int i = transform.childCount - 1; i >= 0; i--) Destroy(transform.GetChild(i).gameObject);

				// remove unwanted components
				if (rigidbody != null) Destroy(rigidbody);

				// object does not need to be active as it is only used to carry information
				gameObject.SetActive(false);
			}
			else if (location == ItemLocation.Equipped)
			{
				// remove PersistableObject
				if (persistObj != null)
				{
					persistObj.persistDestroyedState = false;
					Destroy(persistObj);
				}

				// delete the model that is not used
				if (floorArt != null && floorArt != heldArt)
				{
					Destroy(floorArt);
				}

				// set "held" model active
				if (heldArt != null)
				{
					heldArt.SetActive(true);
					Collider c = heldArt.GetComponent<Collider>();
					if (c != null) Destroy(c); // remove collider from object as it will cause problems
				}
			}
			else
			{
				// delete the model that is not used
				if (heldArt != null && heldArt != floorArt) Destroy(heldArt);

				// set "floor" model active as item is laying in scene
				if (floorArt != null)
				{
					floorArt.SetActive(true);

					// make sure object has collider and is in correct layer
					floorArt.layer = GameGlobal.LayerMapping.plyItem;
					Collider c = floorArt.GetComponent<Collider>();
					if (c == null)
					{
						Debug.LogWarning("The Item's Floor model object should have a collider on it. Adding a default one now.");
						c = floorArt.AddComponent<BoxCollider>();
					}
					c.isTrigger = true;

					// add the ItemInScene component which will react to player interaction
					ItemInScene iis = floorArt.AddComponent<ItemInScene>();
					iis.owner = this;
				}

				// add distance based activation so that object is only active when player close enough
				if (ItemsAsset.Instance.autoPickItemDisableDistance > 0.0f)
				{
					DistanceBasedActivation dba = gameObject.AddComponent<DistanceBasedActivation>();
					dba.inactivePlayerDistance = ItemsAsset.Instance.autoPickItemDisableDistance;
				}

				// finally, check if auto-pickup enabled. if not then set this component disabled so LaterUpdate do not call
				if (autoPickupDist <= 0.0f) enabled = false;
			}
		}

		public override string ToString()
		{
			return (string.IsNullOrEmpty(def.screenName) ? name : def.screenName);
		}

		#endregion
		// ============================================================================================================
		#region persistance
		
		// called by LoadSave System when the Item should recreate itself in the scene
		public static void LoadCreate(string key)
		{
			// load the data needed to recreate item
			string id = GameGlobal.GetStringKey(key + ".it", null);
			if (string.IsNullOrEmpty(id))
			{
				Debug.LogError("Failed to create Item from saved data. The Item's definition ID could not be read: " + key + ".it");
				return;
			}

			Item it = ItemsAsset.Instance.GetDefinition(new UniqueID(id));
			if (it == null)
			{
				Debug.LogError("Failed to find the Item definition from provided ID: " + id);
				return;
			}

			CreateItem(it.prefabId, Item.ItemLocation.Scene, Vector3.zero, Quaternion.identity, new UniqueID(key));
		}

		public void Save(string key)
		{
			if (!persistenceOn) return;
			GameGlobal.SetStringKey(key + ".it", prefabId.ToString());
		}

		public void Load(string key)
		{
			// nothing here
			// LoadCreate handles it as needed
		}

		public void DeleteSaveData(string key)
		{
			if (!persistenceOn) return;
			GameGlobal.DeleteKey(key + ".it");
			GameGlobal.RemoveCreateLoadKey(typeof(Item), key);

			// for runtime item i need to remove the destroyed state entry that was just created by persistObject
			if (isRuntimeItem) GameGlobal.DeleteKey(key + ".destroyed");
		}

		public void DisablePersistence()
		{
			persistenceOn = false;
		}

		#endregion
		// ============================================================================================================
		#region system

		protected void LateUpdate()
		{
			// LateUpdate will only run if auto pickup enabled since
			// this component will be disabled in Start() if not

			if (Time.time > distanceCheckTime && location == ItemLocation.Scene)
			{
				if (autoPickupDist <= 0.0f) { enabled = false; return; }
				if (false == Player.IsReady) return;
				distanceCheckTime = Time.time + 0.2f;

				// check if player close enough for auto-pickup to work
				if (Vector3.Distance(Player.Instance.transform.position, transform.position) <= autoPickupDist)
				{
					PerformPickup();
				}
			}
		}

		public void PerformPickup()
		{
			if (Player.Instance.actor.bag == null)
			{
				// no point in going on if payer does not even have a bag
				Debug.LogError("Item pickup can only be performed if the player object has an ItemBag component on it.");
				return;
			}

			bool done = false;

			if (isCurrency)
			{
				Player.Instance.actor.bag.AddCurrency(Random.Range(minCurrency, maxCurrency));
				done = true;
			}
			else
			{
				done = Player.Instance.actor.bag.AddItemToBag(this);
			}

			if (done)
			{	// item was picked up. simply destroy it
				Destroy(gameObject);
			}
		}

		#endregion
		// ============================================================================================================
		#region pub

		public static Item CreateItem(UniqueID prefabId, ItemLocation location, Vector3 pos, Quaternion rot, UniqueID withSaveKey)
		{
			return CreateItem(prefabId, location, pos, rot, withSaveKey, false, Vector3.zero);
		}

		public static Item CreateItem(UniqueID prefabId, ItemLocation location, Vector3 pos, Quaternion rot, UniqueID withSaveKey, bool dropEffect, Vector3 dropForward)
		{
			Item itemFab = ItemsAsset.Instance.GetDefinition(prefabId);
			if (itemFab == null)
			{
				Debug.LogError("[CreateItemInScene] An Item with the specified ItemPrefab ID does not exist in the database.");
				return null;
			}

			GameObject newObj = (GameObject)Object.Instantiate(itemFab.gameObject);
			newObj.name = string.IsNullOrEmpty(itemFab.def.screenName) ? itemFab.name : itemFab.def.screenName;
			newObj.transform.position = pos;
			newObj.transform.rotation = rot;

			GameObject parent = GameObject.Find("Items");
			if (!parent) parent = new GameObject("Items");
			newObj.transform.parent = parent.transform;

			Item it = newObj.GetComponent<Item>();
			it.isRuntimeItem = true;
			it.location = location;

			if (ItemsAsset.Instance.runtimeCreatedItemsPersist && location == ItemLocation.Scene)
			{
				PersistableObject prefabPersistsNfo = itemFab.gameObject.GetComponent<PersistableObject>();
				PersistableObject p = newObj.GetComponent<PersistableObject>();
				if (p == null) p = newObj.AddComponent<PersistableObject>();
				p.id = withSaveKey == null ? UniqueID.Create() : withSaveKey.Copy();

				// new item created in scene and will have to be restored
				it.persistenceOn = true;
				p.objectStartsActive = true;
				p.persistBloxLocalVars = (prefabPersistsNfo == null ? true : prefabPersistsNfo.persistBloxLocalVars);
				p.persistPosition = true;		// need to know where item should be placed after recreating it
				p.persistRotation = true;		// should restore rotation after recreating item
				p.persistScale = false;			// scale wont change
				p.persistActiveState = false;	// active state should not change
				p.persistDestroyedState = true;	// so that DeleteSaveData() will be called

				GameGlobal.AddCreateLoadKey(typeof(Item), p.id.ToString());
			}

			if (dropEffect)
			{
				// add controller that will make the item seem to jump out from player towards some random direction and fall on ground
				FallToFloor ftf = newObj.AddComponent<FallToFloor>();
				ftf.freezeRotation = itemFab.freezeRotWhenDrop;
				ftf.giveRandomPush = false;

				// this calculates a velocity that will throw the item in a 80* area in front of the character
				ftf.forwardVelocity = (Quaternion.Euler(0f, Random.Range(-40f, 40f), 0f) * dropForward).normalized * Random.Range(1.8f, 2.5f) + new Vector3(0f, 2f, 0f);
			}

			return it;
		}

		#endregion
		// ============================================================================================================
	}
}
