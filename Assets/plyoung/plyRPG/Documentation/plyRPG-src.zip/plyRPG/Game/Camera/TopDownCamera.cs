﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	// The default Top-Down player camera 
	[AddComponentMenu("plyGame/Camera/Top-Down Camera")]
	public class TopDownCamera : MonoBehaviour
	{

		#region properties

		public CharacterControllerBase targetCharacter;
		public Camera targetCamera;									// The camera to control
		public Vector3 targetOffset = new Vector3(0f, 1.7f, 0f);	// Target Offset to look at from target object's pivot
		public LayerMask obstacleLayers = (1 << GameGlobal.LayerMapping.Floor);	// Which layers should count as obstructing the view and is ground? The target object's collider(s) should not be in any of these layers.

		public float followDamping = 0.1f;

		public bool allowRotation = true;			// Is rotation allowed or should camera stick the the initial angle only?
		public float initRotation = 45f;			// Initial angle around target
		public float limitedRotAngle = 0.0f;		// 
		public float rotationSpeed = 0.3f;
		public float rotationDamping = 0.1f;

		public bool allowTilting = true;
		public float initTilt = 45f;				// At what angle to look down at character
		public float minTiltAngle = 0.0f;
		public float maxTiltAngle = 60.0f;
		public float tiltSpeed = 0.3f;
		public float tiltDamping = 0.1f;
	
		public bool allowZooming = true;			// Is zooming allowed?
		public float minZoomDistance = 2f;			// How close to target the cam can come
		public float maxZoomDistance = 10.0f;		// How far out from the target the cam can be zoomed
		public float zoomSpeed = 1f;				// How fast zooming happens
		public float zoomSmoothing = 10.0f;			// How smooth/ fast camera respond to changes in its distance from target object

		public bool requireCursorLock = false;		// Turn this off if the camera should be controllable even without cursor lock
		public bool controlCursorLock = false;		// Turn this off if you want mouse lock controlled elsewhere (for example via a key bind that show or hide the mouse cursor)

		public float gamepadRotateMulti = 1f;		// Multiplier applied to rotationUpdateSpeed & lookUpSpeed when using gamepad
		public float gamepadZoomMulti = 0.1f;		// Multiplier applied to zoomSpeed when using gamepad


		#endregion 
		// ============================================================================================================
		#region vars

		private Transform camTr;
		private Collider targetCollider;
		private Transform targetObject; // transform of target character

		private const float movementThreshold = 0.1f;	// These helps when detecting if there was enough
		private const float rotationThreshold = 0.1f;	// change to warrant updates in the camera

		private Vector3 targetPosition;
		private Vector3 targetSmoothedPosition;

		private float optimalDistance;
		private float targetDistance;
		private float distanceSmooth;

		private float zAxis;
		private float hAxis;
		private float vAxis;
		//private float targetAngle;
		private Quaternion rot;

		private Vector3 inverseLineOfSight;
		private RaycastHit hit;
		private float fieldOfViewRadius;
		private float characterRadius;

		private int Key_HoldToControl = -1;
		private int Key_RotateAxis = -1;
		private int Key_TiltAxis = -1;
		private int Key_Zoom = -1;
		private int Key_GamepadRotate = -1;
		private int Key_GamepadTilt = -1;
		private int Key_GamepadZoom = -1;

		private float yRot = 0f;
		private float xRot = 0f;
		private float yRotSmooth = 0f;
		private float xRotSmooth = 0f;
		private float xVelocity = 0f;
		private float yVelocity = 0f;
		private Vector3 posSmooth = Vector3.zero;
		private Vector3 posVelocity = Vector3.zero;
		private float minRotAngle = 0.0f;
		private float maxRotAngle = 0.0f;

		#endregion
		// ============================================================================================================
		#region init/ start

		protected void Reset()
		{
			obstacleLayers = (1 << GameGlobal.LayerMapping.Floor);
			if (targetCharacter == null) targetCharacter = GetComponent<CharacterControllerBase>();
			if (targetCamera == null) targetCamera = Camera.main;
		}

		protected void Awake()
		{
			GameGlobal.Create(); // make sure global is available, in case user is running scene via Unity play button.

			if (targetCharacter == null) targetCharacter = GetComponent<CharacterControllerBase>();
			if (targetCamera == null) targetCamera = Camera.main;

			if (targetCharacter == null)
			{
				Debug.LogError("[Top-Down Camera] No target character assigned.");
				enabled = false;
				return;
			}

			if (targetCamera == null)
			{
				Debug.LogError("[Top-Down Camera] No target camera assigned.");
				enabled = false;
				return;
			}

			if (limitedRotAngle != 0.0f)
			{
				if (limitedRotAngle < 0.0f) limitedRotAngle *= -1.0f; // force positive number
				minRotAngle = initRotation - limitedRotAngle;
				maxRotAngle = initRotation + limitedRotAngle;
			}

			targetObject = targetCharacter.transform;
			Player.Camera = targetCamera;
			camTr = targetCamera.transform;
		}

		protected void Start()
		{
			if (obstacleLayers != 0)
			{
				targetCollider = targetObject.GetComponent<Collider>();
				if (targetCollider == null)
				{
					obstacleLayers = 0;
					Debug.LogWarning("[Top-Down Camera] Target object has no collider. Camera will ignore obstacle collision.");
				}
			}

			targetPosition = targetSmoothedPosition = targetObject.position;
			distanceSmooth = targetDistance = optimalDistance = Mathf.Clamp(minZoomDistance + (maxZoomDistance - minZoomDistance) / 2f, minZoomDistance, maxZoomDistance);
			
			//targetPosition += targetOffset;
			// calculate offset according to the target's direction
			Vector3 offset = targetObject.right * targetOffset.x + targetObject.up * targetOffset.y + targetObject.forward * targetOffset.z;
			targetPosition += offset;

			//targetAngle = initRotation;

			camTr.position = targetPosition; // start camera at the target so it do not fly in from 0x0x0

			posSmooth = targetObject.position + offset;
			yRotSmooth = yRot = initRotation;
			xRotSmooth = xRot = initTilt;

			// Cache the input bind indexes
			Key_HoldToControl = plyInput.GetInputIdx("Camera Top-Down/Hold to Control");
			Key_RotateAxis = plyInput.GetInputIdx("Camera Top-Down/Rotate Axis");
			Key_TiltAxis = plyInput.GetInputIdx("Camera Top-Down/Tilt Axis");
			Key_Zoom = plyInput.GetInputIdx("Camera Top-Down/Zoom");
			Key_GamepadRotate = plyInput.GetInputIdx("Camera Top-Down/GamepadRotateCam");
			Key_GamepadTilt = plyInput.GetInputIdx("Camera Top-Down/GamepadTiltCam");
			Key_GamepadZoom = plyInput.GetInputIdx("Camera Top-Down/GamepadZoomCam");
		}

		protected void OnEnable()
		{
			targetPosition = targetSmoothedPosition = targetObject.position;
			distanceSmooth = targetDistance = optimalDistance = Mathf.Clamp(minZoomDistance + (maxZoomDistance - minZoomDistance) / 2f, minZoomDistance, maxZoomDistance);

			Vector3 offset = targetObject.right * targetOffset.x + targetObject.up * targetOffset.y + targetObject.forward * targetOffset.z;
			targetPosition += offset;

			camTr.position = targetPosition;

			posSmooth = targetObject.position + offset;
			yRotSmooth = yRot = initRotation;
			xRotSmooth = xRot = initTilt;
		}

		protected void OnDestroy()
		{
			if (Player.Camera == this) Player.Camera = null;
		}

		#endregion
		// ============================================================================================================
		#region update

		protected void FixedUpdate()
		{
			if (GameGlobal.Paused) return;

			targetPosition = targetObject.position + (targetObject.up * targetOffset.y);

			// Cast a sphere from the target towards the camera - using the view radius - checking against the obstacle layers
			if (obstacleLayers != 0)
			{
				inverseLineOfSight = camTr.position - targetPosition;
				if (Physics.SphereCast(targetPosition, ViewRadius, inverseLineOfSight, out hit, optimalDistance, obstacleLayers))
				{	// If something is hit, set the target distance to the hit position
					targetDistance = Mathf.Min((hit.point - targetPosition).magnitude, optimalDistance);
				}
				else
				{	// If nothing is hit, target the optimal distance
					targetDistance = optimalDistance;
				}
			}
			else targetDistance = optimalDistance;
		}

		protected void Update()
		{
			if (GameGlobal.Paused) return;

			if (targetCharacter.controlEnabled)
			{	// only allow cam input if character controller disabled

				if (allowRotation || allowTilting)
				{
#if UNITY5
					if (plyInput.GetButton(Key_HoldToControl) && (!requireCursorLock || controlCursorLock || Cursor.lockState == CursorLockMode.Locked))
					{
						if (controlCursorLock) Cursor.lockState = CursorLockMode.Locked;
						if (allowRotation) yRot += plyInput.GetAxis(Key_RotateAxis) * rotationSpeed;
						if (allowTilting) xRot += plyInput.GetAxis(Key_TiltAxis) * tiltSpeed;
					}
					else if (false == GamepadUpdate())
					{
						if (controlCursorLock) Cursor.lockState = CursorLockMode.None;
					}
#else
					if (plyInput.GetButton(Key_HoldToControl) && (!requireCursorLock || controlCursorLock || Screen.lockCursor))
					{
						if (controlCursorLock) Screen.lockCursor = true;
						if (allowRotation) yRot += plyInput.GetAxis(Key_RotateAxis) * rotationSpeed;
						if (allowTilting) xRot += plyInput.GetAxis(Key_TiltAxis) * tiltSpeed;
					}
					else if (false == GamepadUpdate())
					{
						if (controlCursorLock) Screen.lockCursor = false;
					}
#endif
				}

				if (allowZooming)
				{
					zAxis = plyInput.GetAxis(Key_Zoom);
					if (zAxis != 0.0f)
					{
						optimalDistance = Mathf.Clamp(optimalDistance + zAxis * -zoomSpeed, minZoomDistance, maxZoomDistance);
					}
					else
					{
						zAxis = plyInput.GetAxis(Key_GamepadZoom);
						if (zAxis != 0.0f)
						{
							zAxis *= gamepadZoomMulti;
							optimalDistance = Mathf.Clamp(optimalDistance + zAxis * -zoomSpeed, minZoomDistance, maxZoomDistance);
						}
					}
				}
			}

		}

		protected void LateUpdate()
		{
			if (GameGlobal.Paused) return;
			Vector3 d = (Quaternion.Euler(0f, yRot, 0f) * new Vector3(0f, 0f, targetDistance)).normalized;
			targetPosition = targetObject.position + (camTr.right * targetOffset.x + targetObject.up * targetOffset.y + d * targetOffset.z);
			posSmooth = Vector3.SmoothDamp(posSmooth, targetPosition, ref posVelocity, followDamping);
			distanceSmooth = Mathf.Lerp(distanceSmooth, targetDistance, Time.deltaTime * zoomSmoothing);

			if (allowRotation)
			{
				if (limitedRotAngle != 0.0f) yRot = Mathf.Clamp(yRot, minRotAngle, maxRotAngle);
				yRotSmooth = Mathf.SmoothDamp(yRotSmooth, yRot, ref xVelocity, rotationDamping);
			}

			if (allowTilting)
			{
				xRot = Mathf.Clamp(xRot, minTiltAngle, maxTiltAngle);
				xRotSmooth = Mathf.SmoothDamp(xRotSmooth, xRot, ref yVelocity, tiltDamping);
			}

			rot = Quaternion.Euler(xRotSmooth, yRotSmooth, 0f);

			camTr.rotation = rot;
			camTr.position = rot * new Vector3(0f, 0f, -distanceSmooth) + posSmooth;
		}

		private bool GamepadUpdate()
		{
			bool res = false;
			if (allowRotation && plyInput.IsActive(Key_GamepadRotate))
			{
				hAxis = plyInput.GetAxis(Key_GamepadRotate);
				if (hAxis <= -0.1f || hAxis >= 0.1f)
				{
					yRot += hAxis * rotationSpeed * gamepadRotateMulti;
					res = true;
				}
			}
			if (allowTilting && plyInput.IsActive(Key_GamepadTilt))
			{
				vAxis = plyInput.GetAxis(Key_GamepadTilt);
				if (vAxis <= -0.1f || vAxis >= 0.1f)
				{
					xRot += vAxis * tiltSpeed * gamepadRotateMulti;
					res = true;
				}
			}
			return res;
		}

		private float ViewRadius
		{
			get
			{
				// The minimum clear radius between the camera and the target
				// Half the width of the field of view of the camera at the position of the target
				fieldOfViewRadius = (optimalDistance / Mathf.Sin(90.0f - targetCamera.fieldOfView / 2.0f)) * Mathf.Sin(targetCamera.fieldOfView / 2.0f);
				characterRadius = Mathf.Max(targetCollider.bounds.extents.x, targetCollider.bounds.extents.z);// * 2f;
				return Mathf.Min(characterRadius, fieldOfViewRadius);
			}
		}

		#endregion
		// ============================================================================================================
	}
}