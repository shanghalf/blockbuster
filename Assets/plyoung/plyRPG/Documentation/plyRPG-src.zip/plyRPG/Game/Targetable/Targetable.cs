﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	/// <summary> base class for Targetable objects like character, item and object </summary>
	[AddComponentMenu("")]
	//[SelectionBase]
	public class Targetable : MonoBehaviour
	{
		/// <summary> The targetable types </summary>
		public enum Type 
		{
			Character = 1,  //!< Character
			Object = 2,		//!< Interactable Object
			Item = 4,		//!< Item
			Unknown	= 1024	//!< Unknown
		}

		[System.NonSerialized, HideInInspector]
		public GeneralCallback onDestroy; //!< Assign to this a delegate to respond to this object being destroyed

		// ============================================================================================================

		protected void OnDestroy()
		{
			if (onDestroy != null) onDestroy(this, null);
		}

		/// <summary> Override to identify what kind of Targetable this is. </summary>
		public virtual Type TargetableType()
		{
			return Type.Unknown;
		}

		/// <summary> Override to to specify when facing the object is not needed 
		/// to interact with it. Default is True. </summary>
		public virtual bool MustFaceToInteract()
		{
			return true;
		}

		/// <summary> This should return the object that contains the "data". The data includes some or all of 
		/// the following public fields being present in the object: 
		/// public string ident;
		/// public string screenName;
		/// public string shortName;
		/// public string meta;
		/// public string description;
		/// public Texture2D[] images = new Texture2D[3];
		/// </summary>
		public virtual object DataObject()
		{
			return this;
		}

		// ============================================================================================================
	}
}