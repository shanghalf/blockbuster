﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Status towards other, used by NPC or Factions to determine 
	/// their status towards each other and the player. </summary>
	public enum StatusTowardsOther
	{
		Friendly = 0,   //!< Friendly
		Neutral = 1,	//!< Neutral
		Hostile = 2		//!< Hostile
	}

	/// <summary> An Item Type. </summary>
	[System.Serializable]
	public class ItemType
	{
		public string name = string.Empty;					//!< category name: Armour, Weapon, etc
		public List<string> subTypes = new List<string>(0); //!< sub-type/name: Light, Medium, Heavy, Axe, Sword, etc
		public override string ToString()
		{
			return name;
		}
	}

	/// <summary> Variables used in Faction variable lists. </summary>
	[System.Serializable]
	public class FactionVarList
	{
		public string name;				//!< variable name
		public VariableType varType;	//!< variable type
		public List<plyVar> vars;		//!< the vars related to each faction in same order as what factions are defined

		public FactionVarList Copy()
		{
			FactionVarList o = new FactionVarList();
			o.name = this.name;
			o.varType = this.varType;
			o.vars = new List<plyVar>();
			for (int i = 0; i < this.vars.Count; i++) o.vars.Add(this.vars[i].Copy());
			return o;
		}
	}

	// ================================================================================================================
}